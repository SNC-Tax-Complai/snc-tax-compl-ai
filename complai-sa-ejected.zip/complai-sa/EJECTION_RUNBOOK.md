# Compl-Ai SA — Base44 Ejection & Self-Hosting Runbook

This is the **ComplAi-SA™ Base44 application**, ejected from Base44 and running
on your own Docker stack, published at `https://www.complai-sa.cloud` through a
Cloudflare Tunnel. No Base44 SDK, no Base44 CDN, no Base44 account required.

---

## 1. What changed vs. the Base44 export

| Area | Before | After |
|---|---|---|
| SDK | `@base44/sdk` → app.base44.com | `src/api/apiClient.js` → your API |
| Build plugin | `@base44/vite-plugin` (HMR notifier, analytics tracker, visual-edit agent) | removed |
| Auth | Base44 hosted auth + app registry | JWT against your `users` table |
| Entities | Base44 hosted entity store | PostgreSQL `records` table (JSONB) |
| Realtime | Base44 websockets | Server-Sent Events (`/api/events`) |
| Backend functions | 8 Deno edge functions | 8 Express handlers, same names |
| LLM | Base44 `Core.InvokeLLM` | OpenRouter **free-model router** |
| Email / WhatsApp | Base44 integrations | nodemailer / WhatsApp Graph API |
| Logos & QR | hotlinked `media.base44.com` | vendored in `public/brand/` |

**Only three files in the app imported the SDK directly.** Every other file
imports `{ api } from '@/api/apiClient'`, so replacing that one module
ejected 44 of the 47 coupled files without touching them. Pages and components
are byte-for-byte unchanged.

---

## 2. Prerequisites

- Docker Engine 24+ with the Compose v2 plugin
- Cloudflare account with `complai-sa.cloud` as a zone
- OpenRouter API key — <https://openrouter.ai/keys> (free, no card)
- ~4 GB RAM, ~10 GB disk

---

## 3. Configure

```bash
cp .env.example .env
```

Generate the secrets:

```bash
echo "DATABASE_PASSWORD=$(openssl rand -base64 24)"
echo "JWT_SECRET=$(openssl rand -hex 32)"
```

Fill in `.env`:

```ini
DATABASE_PASSWORD=<generated>
JWT_SECRET=<generated>
ADMIN_EMAIL=you@yourdomain.co.za
ADMIN_PASSWORD=<at least 12 characters>
OPENROUTER_API_KEY=sk-or-v1-...
OPENROUTER_MODEL=                      # blank = auto free-model router
FRONTEND_URL=https://www.complai-sa.cloud
```

The stack **refuses to start** if `JWT_SECRET` or `DATABASE_PASSWORD` is empty.
That is deliberate — a default JWT secret is an authentication bypass.

---

## 4. Run locally

```bash
docker compose up -d --build
docker compose exec backend npm run migrate     # schema + admin user
docker compose ps                                # all healthy
```

```bash
curl -sS http://localhost:5000/api/health
# {"status":"healthy","database":"connected","ai":"configured",...}
```

Open `http://localhost` and sign in with `ADMIN_EMAIL` / `ADMIN_PASSWORD`.
**Change that password immediately** (Settings → change password).

---

## 5. Publish via Cloudflare Tunnel

Full walkthrough in [`cloudflare/README.md`](cloudflare/README.md). Summary:

1. Zero Trust → Networks → Tunnels → **Create a tunnel** (Cloudflared).
2. Copy the token into `CLOUDFLARE_TUNNEL_TOKEN` in `.env`.
3. Public hostname: `www` . `complai-sa.cloud` → **HTTP** → `frontend:80`.
   One hostname only. nginx proxies `/api/` internally; the backend is bound to
   `127.0.0.1` and is never exposed.
4. `docker compose --profile tunnel up -d --build`
5. SSL/TLS mode **Full**, Always Use HTTPS **on**, and a cache-bypass rule for
   `/api/` and `/config.js`.

**SSE and Cloudflare:** `/api/events` and the agent stream are long-lived
Server-Sent Events. `nginx.conf` already disables buffering and sets a 24h read
timeout for those two paths. Do not put a Cloudflare cache rule in front of
them.

---

## 6. The AI layer

`server/src/services/freeModelRouter.js`

Free OpenRouter models are rate-limited and get retired without notice, so a
single hardcoded model ID is a guaranteed future outage. The router holds an
ordered pool of **text-only reasoning** models and walks it until one answers.

| # | Model | Context |
|---|---|---|
| 1 | `z-ai/glm-5.2:free` | 256k |
| 2 | `nvidia/nemotron-3-super-120b-a12b:free` | 262k |
| 3 | `minimax/minimax-m2.7:free` | 197k |
| 4 | `minimax/minimax-m3:free` | 1.05M |
| 5 | `google/gemma-4-31b-it:free` | 262k |
| 6 | `nvidia/nemotron-3.5-lightning:free` | 1.00M |
| 7 | `inclusionai/ling-3.0-flash-fin:free` | 262k |

- Fails over on `402 403 404 408 413 429 500 502 503 504`.
- Honours OpenRouter's `retry_after_seconds` once before moving on.
- **`401` is terminal** — a bad key fails immediately instead of hammering all seven.
- Strips ` ```json ` fences, leading prose and `<think>…</think>` blocks before
  `JSON.parse`. Free reasoning models emit all three constantly.

`Core.InvokeLLM` keeps the Base44 contract exactly: a bare `prompt` returns a
**string**; adding `response_json_schema` returns a **parsed object**. The
pages that rely on that (FilingWorkflows, ComplianceChat, RiskAnalytics,
AuditReport) work unmodified.

Refresh the pool when free models start 404ing:

```bash
curl -s https://openrouter.ai/api/v1/models \
 | python3 -c "import json,sys;[print(m['id']) for m in json.load(sys.stdin)['data'] if m['id'].endswith(':free')]"
```

Set `OPENROUTER_FREE_POOL` in `.env` (no rebuild needed) or edit
`DEFAULT_FREE_POOL` in the router.

---

## 7. Data migration from Base44

The self-hosted store is a JSONB `records` table keyed by entity name, which
mirrors Base44's schemaless model — so export and import is a straight copy.

1. In the Base44 dashboard, export each entity to JSON:
   `BusinessProfile`, `ComplianceDocument`, `AuditLog`,
   `AdminApprovalRequest`, `SageConnection`.
2. Create the users first (Base44 user IDs will not match new ones).
3. Import with the bulk endpoint, remapping `user_id`:

```bash
TOKEN=$(curl -sS -X POST http://localhost:5000/api/auth/login \
  -H 'Content-Type: application/json' \
  -d "{\"email\":\"$ADMIN_EMAIL\",\"password\":\"$ADMIN_PASSWORD\"}" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["token"])')

curl -sS -X POST http://localhost:5000/api/entities/BusinessProfile/bulk \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d @business_profiles.json     # {"rows":[ ... ]}
```

Max 500 rows per call. **Verify counts before decommissioning the Base44 app**,
and revoke the Base44 CLI session used during extraction.

---

## 8. Verification status

`server/test/integration.mjs` — **43/43 passing** against an in-process
Postgres. Covers auth, the full entity CRUD contract with Base44 call
signatures, cross-tenant isolation, SQL injection through the sort parameter,
path traversal on file serving, all eight functions, role enforcement, and
password-hash leakage.

```bash
cd server && npm install && node test/integration.mjs
```

Frontend build: **2746 modules, clean**, with zero `@base44` packages installed.

### Known gaps — read before go-live

| Item | Status | Action |
|---|---|---|
| **Sage Business Cloud** | **Not ported.** The Base44 `sageReadBooks` function depended on OAuth credentials that were not in the export. It returns an honest `not_configured` rather than pretending to work. | Register a Sage OAuth app and implement the exchange in `server/src/routes/functions.js`. The Integrations page will show it as disconnected until then. |
| Document text extraction | `.txt` and `.csv` only. The free model pool is text-only, so scanned PDFs and images are not OCR'd. | Add an OCR step, or pin a vision-capable model, if PDF extraction is required. |
| Agent streaming | Replays stored messages by polling every 1.5s rather than streaming tokens. Token streaming is inconsistent across free models. | Fine as-is. Switch to true streaming if you move to a paid model. |
| SSE hub | Single-node in-process. | Swap `emit()` for Redis pub/sub before scaling the backend horizontally. |
| Rate limiting | None on the backend. | Add a Cloudflare WAF rate-limit rule on `/api/auth/login`. |
| SARS eFiling | Not present in this codebase. | Separate workstream; ISV registration still pending. |

---

## 9. Operations

```bash
docker compose logs -f backend
docker compose restart backend
docker compose down                 # stop, data preserved
docker compose down -v              # stop AND DELETE the database
```

**Repoint the API without rebuilding:** edit `public/config.js`, then
`docker compose restart frontend`, then purge the Cloudflare cache for
`/config.js`.

**Backup:**

```bash
docker compose exec -T database pg_dump -U postgres complai_sa \
  | gzip > backups/complai_$(date +%F).sql.gz
```

**Restore:**

```bash
gunzip -c backups/complai_2026-09-01.sql.gz \
  | docker compose exec -T database psql -U postgres complai_sa
```

POPIA note: keep the `postgres_data` volume on SA-resident hardware. Cloudflare
terminates TLS at the edge, but the data at rest — which is where Section 72
actually bites — stays on your origin.

---

## 10. Layout

```
├── docker-compose.yml       # database, backend, frontend, cloudflared
├── .env.example
├── nginx.conf               # SPA fallback, /api proxy, SSE-aware locations
├── public/
│   ├── config.js            # runtime API URL — edit, don't rebuild
│   └── brand/               # logos + QR, vendored off the Base44 CDN
├── src/                     # UNCHANGED Base44 app: 34 pages, 40+ components
│   └── api/base44Client.js  # ← the entire ejection lives here
├── server/                  # self-hosted API
│   ├── src/
│   │   ├── server.js  db.js  auth.js  migrate.js
│   │   ├── migrations/001_init.sql
│   │   ├── routes/          # auth entities functions integrations
│   │   │                    # agents users misc
│   │   └── services/        # freeModelRouter llm notify events
│   └── test/integration.mjs # 43 tests
├── cloudflare/README.md
└── Ai-Dev-Engine/           # original Base44 definitions, kept for reference
```
