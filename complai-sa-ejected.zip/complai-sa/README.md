# Compl-Ai™ SA

South African SMME compliance management platform with the Emma-i™ AI
assistant. Progressive web app, self-hosted, no platform dependencies.

Covers ten compliance modules — CIPC, SARS, Labour, OHS, POPIA, B-BBEE, FICA,
Municipal, Industry/Sector, and the Tax Engine — with a document vault,
compliance calendar, risk analytics, maturity roadmap, auditor view, and
WhatsApp/email deadline reminders.

---

## Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite 6, React Router 6, Tailwind, shadcn/ui + Radix, Recharts, Framer Motion |
| Backend | Node 20, Express 4 (ESM) |
| Database | PostgreSQL 15 (JSONB entity store) |
| AI | OpenRouter free-model router — see [`EJECTION_RUNBOOK.md`](EJECTION_RUNBOOK.md) section 6 |
| Realtime | Server-Sent Events |
| Ingress | nginx + Cloudflare Tunnel |

No paid platform subscription is required to run this. The only recurring cost
is hosting; the AI runs on OpenRouter's free tier.

---

## Quick start

```bash
cp .env.example .env      # fill in DATABASE_PASSWORD, JWT_SECRET,
                          # ADMIN_EMAIL, ADMIN_PASSWORD, OPENROUTER_API_KEY

docker compose up -d --build
docker compose exec backend npm run migrate

# http://localhost   — sign in with ADMIN_EMAIL / ADMIN_PASSWORD
```

Generate the two required secrets:

```bash
echo "DATABASE_PASSWORD=$(openssl rand -base64 24)"
echo "JWT_SECRET=$(openssl rand -hex 32)"
```

Publish at `https://www.complai-sa.cloud`:

```bash
docker compose --profile tunnel up -d --build
```

Tunnel and DNS setup: [`cloudflare/README.md`](cloudflare/README.md).

---

## Local development

```bash
# Terminal 1 — API on :5000
cd server && npm install && npm run migrate && npm run dev

# Terminal 2 — Vite dev server on :5173, proxying /api to :5000
npm install && npm run dev
```

Requires a PostgreSQL 15 instance; point `DATABASE_*` in `.env` at it, or run
just the database with `docker compose up -d database`.

---

## Tests

```bash
cd server && npm install && node test/integration.mjs
```

43 integration tests covering auth, the entity CRUD contract, cross-tenant
isolation, SQL injection through the sort parameter, path traversal on file
serving, all eight backend functions, and role enforcement.

---

## Architecture notes

**One integration point.** Every page and component reaches the backend through
`src/api/apiClient.js`. Nothing else in `src/` makes network calls. To repoint
the app at a different API, change that module — or, at runtime, edit
`public/config.js` and restart the frontend container. No rebuild needed.

**Entity store.** The six entities (`BusinessProfile`, `ComplianceDocument`,
`AuditLog`, `AdminApprovalRequest`, `SageConnection`, `User`) live in a single
JSONB `records` table. Frequently-filtered keys are lifted into indexed
generated columns, so `filter()` stays fast without a rigid schema.

**Roles.** `user` sees only its own records; `admin` and `auditor` see all;
`sudo` additionally manages roles. Enforced server-side in
`server/src/routes/entities.js` — never trust the client.

---

## Documentation

| Document | Contents |
|---|---|
| [`EJECTION_RUNBOOK.md`](EJECTION_RUNBOOK.md) | Self-hosting runbook, AI configuration, data migration, known gaps |
| [`cloudflare/README.md`](cloudflare/README.md) | Tunnel, DNS, TLS and cache rules |
| [`docs/base44-original-export/`](docs/base44-original-export/) | Original platform export, reference only — does not build or deploy |

---

(c) SA-iLabs(TM) Holdings. Proprietary.
