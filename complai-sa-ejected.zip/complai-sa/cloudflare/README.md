# Cloudflare Tunnel — www.complai-sa.cloud

The tunnel is how the self-hosted stack reaches the public internet. It makes an
**outbound** connection to Cloudflare, so you need **no port forwarding, no static
IP, and no open inbound firewall ports**. The origin server is never directly
addressable.

```
Browser → Cloudflare edge → encrypted tunnel → cloudflared container → frontend:80 → nginx
                                                                                      └── /api/ → backend:5000 → postgres
```

## Why this shape

`nginx.conf` already proxies `/api/` to the backend container, and
`public/config.js` is set to the same-origin value `/api`. That means the tunnel
only ever needs to publish **one** hostname pointing at **one** service
(`frontend:80`). The backend is bound to `127.0.0.1` in `docker-compose.yml` and
is not exposed publicly at all.

Do not create a second tunnel route for the API. It is not needed and it would
expose the backend directly.

---

## Setup (dashboard method — recommended, ~5 minutes)

1. Point the domain's nameservers at Cloudflare
   Cloudflare Dashboard → **Add a site** → `complai-sa.cloud` → follow the
   nameserver instructions at your registrar. Wait for the zone to go **Active**.

2. Create the tunnel
   **Zero Trust** → **Networks** → **Tunnels** → **Create a tunnel**
   - Type: **Cloudflared**
   - Name: `complai-sa-prod`
   - Save, then **copy the tunnel token** (a long `eyJ...` string).

3. Add the token to `.env` in the repo root:
   ```
   CLOUDFLARE_TUNNEL_TOKEN=eyJhIjoiXXXXXXXX...
   ```

4. Add the public hostname (still in the tunnel's dashboard page)
   | Field | Value |
   |---|---|
   | Subdomain | `www` |
   | Domain | `complai-sa.cloud` |
   | Path | *(leave blank)* |
   | Service type | `HTTP` |
   | URL | `frontend:80` |

   `frontend` is the Docker Compose service name — the `cloudflared` container
   resolves it on the shared Compose network. Do not use `localhost` here.

5. Start the stack with the tunnel profile:
   ```bash
   docker compose --profile tunnel up -d --build
   ```

6. Redirect the apex to www
   **Rules** → **Redirect Rules** → Create:
   - When: `Hostname equals complai-sa.cloud`
   - Then: Dynamic redirect `301` → `concat("https://www.complai-sa.cloud", http.request.uri.path)`

---

## Recommended Cloudflare settings

| Setting | Where | Value | Why |
|---|---|---|---|
| SSL/TLS mode | SSL/TLS → Overview | **Full** | Edge terminates TLS; tunnel leg is already encrypted. Do **not** use Flexible. |
| Always Use HTTPS | SSL/TLS → Edge Certificates | **On** | Forces `https://`. |
| Min TLS Version | SSL/TLS → Edge Certificates | **1.2** | POPIA-appropriate baseline. |
| HSTS | SSL/TLS → Edge Certificates | **On**, 6 months | Enable only once HTTPS is confirmed working. |
| Brotli | Speed → Optimization | **On** | Smaller JS bundles. |
| Browser Cache TTL | Caching | **Respect existing headers** | `nginx.conf` already sets 1-year immutable caching on hashed assets. |
| Proxy status (orange cloud) | DNS | **Proxied** | Required — tunnel routes do this automatically. |

### Do not cache the API or runtime config
**Caching → Cache Rules** → create a rule:
- When: `(http.request.uri.path contains "/api/") or (http.request.uri.path eq "/config.js")`
- Then: **Bypass cache**

`/config.js` must never be cached at the edge — it is the file you edit to
repoint the frontend at a different backend without rebuilding.

### POPIA note
Cloudflare terminates TLS at the nearest edge PoP (Johannesburg / Cape Town for
SA traffic), but requests may transit other PoPs. Application data at rest stays
on your origin, which is where the Section 72 cross-border obligation actually
bites. Keep the Postgres volume on SA-resident hardware. Consider enabling
**Regional Services** (Data Localisation Suite, paid add-on) if you need to
contractually guarantee that TLS termination itself never leaves South Africa.

---

## Verifying

```bash
docker compose --profile tunnel logs -f cloudflared    # look for "Registered tunnel connection"
curl -I  https://www.complai-sa.cloud                  # expect 200
curl -sS https://www.complai-sa.cloud/api/health       # expect {"status":"healthy",...}
curl -sS https://www.complai-sa.cloud/config.js        # expect apiUrl: "/api"
```

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Error 1033 | Tunnel not connected | `docker compose --profile tunnel logs cloudflared`; check the token in `.env` |
| Error 502 | `frontend` container unhealthy | `docker compose ps`; `docker compose logs frontend` |
| Site loads, API 404 | Public hostname points at `backend:5000` instead of `frontend:80` | Fix the tunnel route to `frontend:80` |
| API calls hit the old Vercel URL | Stale cached `config.js` | Add the cache-bypass rule above, then purge cache |
| Redirect loop | SSL/TLS mode set to Flexible | Change to **Full** |
