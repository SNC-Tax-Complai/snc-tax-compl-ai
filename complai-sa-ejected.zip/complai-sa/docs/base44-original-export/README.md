# Base44 original export — REFERENCE ONLY. DO NOT DEPLOY.

This directory is the untouched Base44 platform definition from the original
export. **Nothing in here runs.** It is not compiled, linted, bundled or
deployed — `jsconfig.json`, `eslint.config.js` and the Vite build all scope to
`src/` only, and the Docker images copy only `src/`, `public/` and `server/`.

It is kept solely as the specification the self-hosted implementation was
ported against, and as evidence of provenance for the IP handover.

The `.ts` files under `functions/` still contain
`import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31'`. That is
Deno-only syntax against the Base44 SDK and it will not resolve in this
project. It is inert.

## Where each piece now lives

| Base44 artefact | Self-hosted implementation |
|---|---|
| `entities/*.jsonc` (6 schemas) | `server/src/migrations/001_init.sql` — `records` table (JSONB) |
| `functions/checkDeadlineReminders` | `server/src/routes/functions.js` |
| `functions/generateAuditorSummary` | `server/src/routes/functions.js` |
| `functions/generateMonthlyReport` | `server/src/routes/functions.js` |
| `functions/logApprovalAction` | `server/src/routes/functions.js` |
| `functions/onDocumentStatusChange` | `server/src/routes/functions.js` |
| `functions/sageReadBooks` | `server/src/routes/functions.js` — **not ported**, returns `not_configured` |
| `functions/sendDeadlineEmailReminders` | `server/src/routes/functions.js` |
| `functions/sendWhatsAppNotification` | `server/src/routes/functions.js` |
| `workflows/*.jsonc` (4 cron workflows) | `server/src/server.js` — node-cron, 08:00 Africa/Johannesburg |
| `agents/*.jsonc` | `server/src/services/llm.js` — system prompt + OpenRouter free router |
| `config.jsonc` | `docker-compose.yml` + `.env.example` |

If you no longer need the provenance record, this whole directory can be
deleted without affecting the build.
