import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden — admin only' }, { status: 403 });

    const token = Deno.env.get('WHATSAPP_ACCESS_TOKEN');
    const phoneNumberId = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID');
    if (!token || !phoneNumberId) {
      return Response.json({ error: 'WhatsApp credentials not configured' }, { status: 500 });
    }

    const today = new Date();
    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(today.getDate() + 7);

    // Fetch all business profiles with a WhatsApp number set
    const profiles = await base44.asServiceRole.entities.BusinessProfile.filter({});
    const eligible = profiles.filter(p => p.whatsapp_number && p.whatsapp_number.trim().length > 0);

    const notifications = [];

    for (const profile of eligible) {
      let deadlines = [];
      try {
        deadlines = JSON.parse(profile.upcoming_deadlines || '[]');
      } catch (_) { continue; }

      const dueSoon = deadlines.filter(d => {
        const deadlineDate = new Date(d.date);
        return deadlineDate >= today && deadlineDate <= sevenDaysFromNow;
      });

      if (dueSoon.length === 0) continue;

      // Normalize phone number
      let phone = String(profile.whatsapp_number).replace(/[\s\-()]/g, '');
      if (phone.startsWith('0')) phone = '27' + phone.substring(1);

      // Build message
      const deadlineLines = dueSoon.map(d => `• ${d.label} — ${d.date}${d.urgent ? ' (URGENT)' : ''}`).join('\n');
      const messageText = `🇿🇦 Compl-Ai™ SA — Filing Reminder\n\nHello ${profile.director_name || profile.entity_name},\n\nYou have ${dueSoon.length} upcoming compliance deadline(s) within 7 days:\n\n${deadlineLines}\n\nPlease log in to your Compl-Ai™ dashboard to action these.\n\n— Compl-i Assistant™`;

      // Send via WhatsApp Cloud API
      const url = `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`;
      const payload = {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: phone.replace('+', ''),
        type: 'text',
        text: { body: messageText },
      };

      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await resp.json();
      notifications.push({
        profile_id: profile.id,
        entity_name: profile.entity_name,
        phone,
        sent: resp.ok,
        deadlines_count: dueSoon.length,
        error: resp.ok ? null : (data.error?.message || 'Unknown error'),
      });
    }

    return Response.json({
      success: true,
      checked: eligible.length,
      notified: notifications.filter(n => n.sent).length,
      failed: notifications.filter(n => !n.sent).length,
      details: notifications,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});