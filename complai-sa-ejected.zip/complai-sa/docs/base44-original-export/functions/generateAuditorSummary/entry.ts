import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import { jsPDF } from 'npm:jspdf@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin' && user.role !== 'sudo') {
      return Response.json({ error: 'Forbidden — admin access required' }, { status: 403 });
    }

    // Fetch all onboarded business profiles
    const profiles = await base44.asServiceRole.entities.BusinessProfile.list('-created_date', 500);
    const onboarded = profiles.filter(p => p.onboarding_complete);

    if (onboarded.length === 0) {
      return Response.json({ error: 'No onboarded business profiles found' }, { status: 404 });
    }

    // Fetch all documents
    let allDocs = [];
    try {
      allDocs = await base44.asServiceRole.entities.ComplianceDocument.list('-created_date', 1000);
    } catch (_) {}

    // Aggregate stats
    const scores = onboarded.map(p => p.compliance_score || 0).filter(Boolean);
    const avgScore = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
    const highRisk = onboarded.filter(p => p.risk_level === 'High').length;
    const mediumRisk = onboarded.filter(p => p.risk_level === 'Medium').length;
    const lowRisk = onboarded.filter(p => p.risk_level === 'Low').length;
    const totalPendingFilings = onboarded.reduce((sum, p) => sum + (p.pending_filings || 0), 0);
    const totalUrgentAlerts = onboarded.reduce((sum, p) => sum + (p.urgent_alerts || 0), 0);
    const verifiedDocs = allDocs.filter(d => d.status === 'verified').length;
    const needsActionDocs = allDocs.filter(d => d.status === 'needs_action').length;

    // Module averages
    const moduleAvg = (field) => {
      const vals = onboarded.map(p => p[field]).filter(v => v != null && !isNaN(v));
      return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : 0;
    };

    const modules = [
      ['Overall', avgScore, [13, 42, 94]],
      ['CIPC', moduleAvg('cipc_score'), [0, 150, 180]],
      ['SARS', moduleAvg('sars_score'), [60, 181, 74]],
      ['Labour', moduleAvg('labour_score'), [245, 158, 11]],
      ['OHS', moduleAvg('ohs_score'), [239, 68, 68]],
      ['POPIA', moduleAvg('popia_score'), [139, 92, 246]],
      ['B-BBEE', moduleAvg('bbbee_score'), [236, 72, 153]],
      ['FICA', moduleAvg('fica_score'), [20, 184, 166]],
    ];

    const now = new Date();
    const monthName = now.toLocaleString('en-ZA', { month: 'long', year: 'numeric' });

    const doc = new jsPDF({ unit: 'pt', format: 'a4' });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 40;
    const contentW = pageW - margin * 2;
    let y = 0;

    // ── Header ──
    doc.setFillColor(13, 42, 94);
    doc.rect(0, 0, pageW, 80, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    doc.text('Compl-Ai\u2122 SA', margin, 35);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(200, 220, 255);
    doc.text('Monthly Compliance Summary — All Clients', margin, 55);
    doc.setFontSize(9);
    doc.text(monthName, pageW - margin, 55, { align: 'right' });

    // ── Summary KPIs ──
    y = 110;
    doc.setTextColor(13, 42, 94);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text('Portfolio Overview', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.setLineWidth(2);
    doc.line(margin, y + 5, margin + 120, y + 5);

    y += 24;
    const kpiData = [
      ['Total Clients', String(onboarded.length), [13, 42, 94]],
      ['Avg Compliance', `${avgScore}%`, [60, 181, 74]],
      ['High Risk', String(highRisk), [239, 68, 68]],
      ['Medium Risk', String(mediumRisk), [245, 158, 11]],
      ['Low Risk', String(lowRisk), [60, 181, 74]],
      ['Total Documents', String(allDocs.length), [0, 150, 180]],
      ['Verified Docs', String(verifiedDocs), [60, 181, 74]],
      ['Needs Action', String(needsActionDocs), [239, 68, 68]],
      ['Pending Filings', String(totalPendingFilings), [245, 158, 11]],
      ['Urgent Alerts', String(totalUrgentAlerts), [239, 68, 68]],
    ];

    const kpiW = (contentW - 20) / 5;
    const kpiH = 50;
    kpiData.forEach(([label, val, color], i) => {
      const col = i % 5;
      const row = Math.floor(i / 5);
      const x = margin + col * (kpiW + 5);
      const ky = y + row * (kpiH + 8);
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(220, 225, 230);
      doc.roundedRect(x, ky, kpiW, kpiH, 4, 4, 'FD');
      doc.setTextColor(120, 120, 120);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.text(label, x + 6, ky + 12);
      doc.setTextColor(color[0], color[1], color[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.text(val, x + 6, ky + 34);
    });
    y += Math.ceil(kpiData.length / 5) * (kpiH + 8) + 10;

    // ── Average Module Scores ──
    y += 12;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(13, 42, 94);
    doc.text('Average Module Compliance Scores', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.line(margin, y + 5, margin + 200, y + 5);

    y += 24;
    const barH = 14;
    const barW = contentW - 80;
    modules.forEach(([label, score, color]) => {
      const pct = Math.max(0, Math.min(100, score || 0));
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(50, 50, 50);
      doc.text(label, margin, y + barH - 4);
      doc.setFillColor(230, 235, 240);
      doc.roundedRect(margin + 60, y, barW, barH, 3, 3, 'F');
      doc.setFillColor(color[0], color[1], color[2]);
      const fillW = Math.max(2, (pct / 100) * barW);
      doc.roundedRect(margin + 60, y, fillW, barH, 3, 3, 'F');
      doc.setTextColor(30, 30, 30);
      doc.text(`${pct}%`, margin + 60 + barW + 5, y + barH - 4);
      y += barH + 6;
    });

    // ── Per-Client Breakdown Table ──
    y += 14;
    if (y > pageH - 120) { doc.addPage(); y = margin; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(13, 42, 94);
    doc.text('Per-Client Compliance Breakdown', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.line(margin, y + 5, margin + 200, y + 5);
    y += 18;

    // Table header
    doc.setFillColor(13, 42, 94);
    doc.rect(margin, y, contentW, 20, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'bold');
    const cols = [
      { label: 'Business', x: margin + 6, w: 120 },
      { label: 'Type', x: margin + 128, w: 60 },
      { label: 'Industry', x: margin + 192, w: 70 },
      { label: 'Score', x: margin + 266, w: 35 },
      { label: 'Risk', x: margin + 305, w: 40 },
      { label: 'Filings', x: margin + 349, w: 35 },
      { label: 'Alerts', x: margin + 386, w: 35 },
      { label: 'Docs', x: margin + 423, w: 30 },
    ];
    cols.forEach(c => doc.text(c.label, c.x, y + 13));
    y += 22;

    // Table rows
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    onboarded.forEach((p, i) => {
      if (y > pageH - 60) {
        // Footer
        doc.setDrawColor(220, 225, 230);
        doc.line(margin, pageH - 40, pageW - margin, pageH - 40);
        doc.setFontSize(6);
        doc.setTextColor(150, 150, 150);
        doc.text(`Generated ${now.toLocaleString('en-ZA')} for ${user.email || 'auditor'}`, margin, pageH - 28);
        doc.text(`Page ${doc.getNumberOfPages()}`, pageW - margin, pageH - 28, { align: 'right' });
        doc.addPage();
        y = margin;
        // Repeat header
        doc.setFillColor(13, 42, 94);
        doc.rect(margin, y, contentW, 20, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'bold');
        cols.forEach(c => doc.text(c.label, c.x, y + 13));
        y += 22;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7);
      }

      if (i % 2 === 0) {
        doc.setFillColor(248, 250, 252);
        doc.rect(margin, y - 2, contentW, 18, 'F');
      }
      const pDocs = allDocs.filter(d => d.business_profile_id === p.id).length;
      const riskColor = p.risk_level === 'High' ? [239, 68, 68] : p.risk_level === 'Medium' ? [245, 158, 11] : [60, 181, 74];
      doc.setTextColor(30, 30, 30);
      doc.text((p.entity_name || 'N/A').substring(0, 28), cols[0].x, y + 10);
      doc.setTextColor(100, 100, 100);
      doc.text((p.entity_type || '—').substring(0, 14), cols[1].x, y + 10);
      doc.text((p.industry || '—').substring(0, 16), cols[2].x, y + 10);
      doc.setTextColor(13, 42, 94);
      doc.setFont('helvetica', 'bold');
      doc.text(`${p.compliance_score ?? '—'}%`, cols[3].x, y + 10);
      doc.setTextColor(riskColor[0], riskColor[1], riskColor[2]);
      doc.text(p.risk_level || '—', cols[4].x, y + 10);
      doc.setTextColor(100, 100, 100);
      doc.setFont('helvetica', 'normal');
      doc.text(String(p.pending_filings ?? '0'), cols[5].x, y + 10);
      doc.text(String(p.urgent_alerts ?? '0'), cols[6].x, y + 10);
      doc.text(String(pDocs), cols[7].x, y + 10);
      y += 18;
    });

    // ── Footer on every page ──
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setDrawColor(220, 225, 230);
      doc.line(margin, pageH - 40, pageW - margin, pageH - 40);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.setTextColor(150, 150, 150);
      doc.text('Compl-Ai\u2122 SA  \u00B7  Auditor Monthly Summary  \u00B7  A SNC-TAX Product  \u00B7  SA-iLabs\u00AE\u2122', margin, pageH - 28);
      doc.text(`Page ${i} of ${pageCount}`, pageW - margin, pageH - 28, { align: 'right' });
      doc.text(`Generated ${now.toLocaleString('en-ZA')} for ${user.email || user.full_name || 'auditor'}`, margin, pageH - 18);
    }

    const pdfBytes = doc.output('arraybuffer');
    const filename = `ComplAi-Auditor-Summary-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}.pdf`;
    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});