import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import { jsPDF } from 'npm:jspdf@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const profileId = body?.profile_id;

    let profile;
    if (profileId) {
      profile = await base44.entities.BusinessProfile.get(profileId);
    } else {
      const profiles = await base44.entities.BusinessProfile.filter({ user_id: user.id });
      profile = profiles.find(p => p.onboarding_complete) || profiles[0];
    }

    if (!profile) return Response.json({ error: 'No business profile found' }, { status: 404 });

    let documents = [];
    try {
      documents = await base44.entities.ComplianceDocument.filter({ business_profile_id: profile.id });
    } catch (_) {}

    let deadlines = [];
    try { deadlines = JSON.parse(profile.upcoming_deadlines || '[]'); } catch (_) {}

    const recommendations = (profile.ai_recommendations || '').split('|').filter(Boolean);

    const now = new Date();
    const monthName = now.toLocaleString('en-ZA', { month: 'long', year: 'numeric' });

    const doc = new jsPDF({ unit: 'pt', format: 'a4' });
    const pageW = doc.internal.pageSize.getWidth();
    const margin = 40;
    const contentW = pageW - margin * 2;
    let y = 0;

    // ── Header bar ──
    doc.setFillColor(13, 42, 94); // navy
    doc.rect(0, 0, pageW, 80, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    doc.text('Compl-Ai\u2122 SA', margin, 35);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(200, 220, 255);
    doc.text('Monthly Compliance Summary Report', margin, 55);
    doc.setFontSize(9);
    doc.text(monthName, pageW - margin, 55, { align: 'right' });

    // ── Business info ──
    y = 110;
    doc.setTextColor(13, 42, 94);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text('Business Overview', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.setLineWidth(2);
    doc.line(margin, y + 5, margin + 100, y + 5);

    y += 22;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 60, 60);
    const bizRows = [
      ['Entity Name', profile.entity_name || 'N/A'],
      ['Entity Type', profile.entity_type || 'N/A'],
      ['Industry', profile.industry || 'N/A'],
      ['Province', profile.province || 'N/A'],
      ['Registration No.', profile.reg_number || 'N/A'],
      ['VAT Registered', profile.vat_registered === 'Yes' ? `Yes (${profile.vat_number || 'N/A'})` : 'No'],
      ['Employees', profile.employee_count || 'N/A'],
      ['Report Date', now.toLocaleDateString('en-ZA')],
    ];
    bizRows.forEach(([label, val]) => {
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 100, 100);
      doc.text(label + ':', margin, y);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(30, 30, 30);
      doc.text(String(val), margin + 110, y);
      y += 15;
    });

    // ── Compliance Scores ──
    y += 12;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(13, 42, 94);
    doc.text('Compliance Health Scores', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.line(margin, y + 5, margin + 140, y + 5);

    y += 24;
    const modules = [
      ['Overall', profile.compliance_score, [13, 42, 94]],
      ['CIPC', profile.cipc_score, [0, 150, 180]],
      ['SARS', profile.sars_score, [60, 181, 74]],
      ['Labour', profile.labour_score, [245, 158, 11]],
      ['OHS', profile.ohs_score, [239, 68, 68]],
      ['POPIA', profile.popia_score, [139, 92, 246]],
      ['B-BBEE', profile.bbbee_score, [236, 72, 153]],
      ['FICA', profile.fica_score, [20, 184, 166]],
    ];

    const barH = 14;
    const barW = contentW - 80;
    modules.forEach(([label, score, color]) => {
      const pct = Math.max(0, Math.min(100, score || 0));
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(50, 50, 50);
      doc.text(label, margin, y + barH - 4);

      // track
      doc.setFillColor(230, 235, 240);
      doc.roundedRect(margin + 60, y, barW, barH, 3, 3, 'F');
      // fill
      doc.setFillColor(color[0], color[1], color[2]);
      const fillW = Math.max(2, (pct / 100) * barW);
      doc.roundedRect(margin + 60, y, fillW, barH, 3, 3, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 30, 30);
      doc.text(`${pct}%`, margin + 60 + barW + 5, y + barH - 4);
      y += barH + 6;
    });

    // ── KPI summary ──
    y += 8;
    const kpiY = y;
    const kpiW = (contentW - 20) / 3;
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(80, 80, 80);
    const kpis = [
      ['Risk Level', profile.risk_level || 'N/A', [239, 68, 68]],
      ['Pending Filings', String(profile.pending_filings ?? 'N/A'), [245, 158, 11]],
      ['Urgent Alerts', String(profile.urgent_alerts ?? 'N/A'), [239, 68, 68]],
      ['Vault Documents', String(documents.length), [60, 181, 74]],
    ];
    kpis.forEach(([label, val, color], i) => {
      const col = i % 3;
      const row = Math.floor(i / 3);
      const x = margin + col * (kpiW + 10);
      const ky = kpiY + row * 50;
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(220, 225, 230);
      doc.roundedRect(x, ky, kpiW, 42, 4, 4, 'FD');
      doc.setTextColor(120, 120, 120);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.text(label, x + 8, ky + 12);
      doc.setTextColor(color[0], color[1], color[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text(val, x + 8, ky + 32);
    });
    y = kpiY + Math.ceil(kpis.length / 3) * 50 + 10;

    // ── AI Analysis Summary ──
    if (y > 650) { doc.addPage(); y = margin; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(13, 42, 94);
    doc.text('AI Analysis Summary', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.line(margin, y + 5, margin + 130, y + 5);
    y += 20;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(50, 50, 50);
    if (profile.ai_analysis_summary) {
      const lines = doc.splitTextToSize(profile.ai_analysis_summary, contentW);
      lines.forEach(line => {
        if (y > 770) { doc.addPage(); y = margin; }
        doc.text(line, margin, y);
        y += 13;
      });
    } else {
      doc.text('Not Available — complete onboarding or upload documents for AI analysis.', margin, y);
      y += 15;
    }

    // ── Upcoming Deadlines ──
    y += 10;
    if (y > 680) { doc.addPage(); y = margin; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(13, 42, 94);
    doc.text('Upcoming Deadlines', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.line(margin, y + 5, margin + 120, y + 5);
    y += 20;

    if (deadlines.length > 0) {
      doc.setFontSize(9);
      deadlines.forEach((d, i) => {
        if (y > 760) { doc.addPage(); y = margin; }
        const isUrgent = d.urgent;
        doc.setFillColor(isUrgent ? 254 : 248, isUrgent ? 226 : 250, isUrgent ? 226 : 252);
        doc.setDrawColor(isUrgent ? 239 : 220, isUrgent ? 68 : 225, isUrgent ? 68 : 230);
        doc.roundedRect(margin, y - 10, contentW, 22, 3, 3, 'FD');
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(30, 30, 30);
        doc.text(d.label || 'Deadline', margin + 8, y + 4);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(100, 100, 100);
        doc.text(d.type || '', margin + 200, y + 4);
        doc.setTextColor(isUrgent ? 180 : 30, isUrgent ? 40 : 30, isUrgent ? 40 : 30);
        doc.setFont('helvetica', 'bold');
        doc.text(d.date || '', pageW - margin - 8, y + 4, { align: 'right' });
        y += 28;
      });
    } else {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(100, 100, 100);
      doc.text('No deadlines extracted. Upload compliance documents for AI deadline detection.', margin, y);
      y += 15;
    }

    // ── Recommendations ──
    y += 10;
    if (y > 680) { doc.addPage(); y = margin; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(13, 42, 94);
    doc.text('Compl-i Assistant Recommendations', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.line(margin, y + 5, margin + 200, y + 5);
    y += 20;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    if (recommendations.length > 0) {
      recommendations.forEach((rec) => {
        const lines = doc.splitTextToSize('\u2022  ' + rec.trim(), contentW);
        lines.forEach(line => {
          if (y > 770) { doc.addPage(); y = margin; }
          doc.setTextColor(50, 50, 50);
          doc.text(line, margin, y);
          y += 13;
        });
      });
    } else {
      doc.setTextColor(100, 100, 100);
      doc.text('No recommendations available.', margin, y);
    }

    // ── Document Vault Summary ──
    y += 15;
    if (y > 660) { doc.addPage(); y = margin; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(13, 42, 94);
    doc.text('Document Vault Summary', margin, y);
    doc.setDrawColor(60, 181, 74);
    doc.line(margin, y + 5, margin + 150, y + 5);
    y += 22;
    doc.setFontSize(9);
    if (documents.length > 0) {
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 100, 100);
      doc.text('Document', margin, y);
      doc.text('Type', margin + 250, y);
      doc.text('Status', margin + 350, y);
      y += 5;
      doc.setDrawColor(220, 225, 230);
      doc.line(margin, y, pageW - margin, y);
      y += 12;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(50, 50, 50);
      documents.forEach((d) => {
        if (y > 770) { doc.addPage(); y = margin; }
        const name = (d.document_name || 'Untitled').substring(0, 40);
        doc.text(name, margin, y);
        doc.text((d.document_type || 'Other').substring(0, 18), margin + 250, y);
        doc.text(d.status || 'pending', margin + 350, y);
        y += 15;
      });
    } else {
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 100, 100);
      doc.text('No documents uploaded yet.', margin, y);
    }

    // ── Footer on every page ──
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setDrawColor(220, 225, 230);
      doc.line(margin, 800, pageW - margin, 800);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.setTextColor(150, 150, 150);
      doc.text('Compl-Ai\u2122 SA  \u00B7  A SNC-TAX Product  \u00B7  Developed by SA-iLabs\u00AE\u2122  \u00B7  MAICP Protocol', margin, 815);
      doc.text(`Page ${i} of ${pageCount}`, pageW - margin, 815, { align: 'right' });
      doc.text(`Generated ${now.toLocaleString('en-ZA')} for ${user.email || user.full_name || 'user'}`, margin, 827);
    }

    const pdfBytes = doc.output('arraybuffer');
    const filename = `ComplAi-Monthly-Report-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}.pdf`;
    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});