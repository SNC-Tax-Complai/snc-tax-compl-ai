import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { event, data, old_data, changed_fields } = body;

    if (!data || !data.id) {
      return Response.json({ skipped: true, reason: 'no data' });
    }

    // Re-fetch the authoritative record from the database — never trust
    // client-supplied field values (email, full_name, approved_by, status)
    // for what gets written to the audit trail.
    let record = null;
    try {
      record = await base44.asServiceRole.entities.AdminApprovalRequest.get(data.id);
    } catch (_) {
      // record no longer exists or id is invalid
    }
    if (!record) {
      return Response.json({ skipped: true, reason: 'record not found' });
    }

    let actionType = null;
    let previousStatus = null;
    let newStatus = record.status;
    let details = '';

    if (event?.type === 'create') {
      actionType = 'created';
      details = `New admin access request submitted by ${record.email} (${record.full_name || 'Unknown'})`;
    } else if (event?.type === 'update' && changed_fields && changed_fields.includes('status')) {
      previousStatus = old_data?.status || 'pending';
      newStatus = record.status;
      if (previousStatus === newStatus) {
        return Response.json({ skipped: true, reason: 'status unchanged' });
      }
      actionType = newStatus; // 'approved' or 'rejected'
      const actorEmail = record.approved_by || 'unknown';
      details = `Admin ${actorEmail} ${newStatus} access request for ${record.email} (${record.full_name || 'Unknown'})`;
    }

    if (!actionType) {
      return Response.json({ skipped: true, reason: 'not a relevant change' });
    }

    await base44.asServiceRole.entities.AuditLog.create({
      action_type: actionType,
      actor_email: record.approved_by || record.email || 'unknown',
      target_email: record.email || '',
      target_name: record.full_name || '',
      previous_status: previousStatus,
      new_status: newStatus,
      details,
    });

    return Response.json({ success: true, action_type: actionType });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});