import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { data, changed_fields } = body;

    // Only fire on status changes
    if (!changed_fields || !changed_fields.includes('status')) {
      return Response.json({ success: true, message: 'Status not changed — skipping' });
    }

    if (!data || !data.id) return Response.json({ error: 'No document data' }, { status: 400 });

    // Re-fetch the authoritative document from the database — never trust
    // client-supplied user_id/document_name to decide who receives a message
    // or what it says.
    const doc = await base44.asServiceRole.entities.ComplianceDocument.get(data.id);
    if (!doc) return Response.json({ success: true, message: 'Document not found' });

    const newStatus = doc.status;
    if (newStatus !== 'analyzed' && newStatus !== 'error') {
      return Response.json({ success: true, message: `Status is "${newStatus}" — no notification needed` });
    }

    // Fetch the business profile to get the WhatsApp number
    const profiles = await base44.asServiceRole.entities.BusinessProfile.filter({ user_id: doc.user_id });
    if (profiles.length === 0) return Response.json({ success: true, message: 'No business profile found' });

    const profile = profiles[0];
    if (!profile.whatsapp_number || !profile.whatsapp_number.trim()) {
      return Response.json({ success: true, message: 'No WhatsApp number on file — skipping' });
    }

    const token = Deno.env.get('WHATSAPP_ACCESS_TOKEN');
    const phoneNumberId = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID');
    if (!token || !phoneNumberId) {
      return Response.json({ error: 'WhatsApp credentials not configured' }, { status: 500 });
    }

    let phone = String(profile.whatsapp_number).replace(/[\s\-()]/g, '');
    if (phone.startsWith('0')) phone = '27' + phone.substring(1);

    let messageText;
    if (newStatus === 'analyzed') {
      messageText = `🇿🇦 Compl-Ai™ SA — Document Update\n\nHello ${profile.director_name || profile.entity_name},\n\nYour document "${doc.document_name}" has been analysed by Compl-i Assistant™.\n\nLog in to your dashboard to view the extracted compliance data.\n\n— Compl-i Assistant™`;
    } else {
      messageText = `🇿🇦 Compl-Ai™ SA — Document Alert\n\nHello ${profile.director_name || profile.entity_name},\n\nThere was an issue analysing your document "${doc.document_name}". Please re-upload it or contact support.\n\n— Compl-i Assistant™`;
    }

    const url = `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`;
    const payload = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: phone.replace('+', ''),
      type: 'text',
      text: { body: messageText },
    };

    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const result = await resp.json();

    return Response.json({
      success: resp.ok,
      message_id: result.messages?.[0]?.id,
      sent_to: phone,
      document: doc.document_name,
      status: newStatus,
      error: resp.ok ? null : (result.error?.message || 'Unknown error'),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});