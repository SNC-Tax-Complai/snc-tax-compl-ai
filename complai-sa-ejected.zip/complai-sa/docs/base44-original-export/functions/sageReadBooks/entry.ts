import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const SAGE_API_BASE = 'https://api.accounting.sage.com/v3.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const action = body?.action || 'fetch';

    // ── CONNECT: save token and verify ──
    if (action === 'connect') {
      const { access_token, country_region } = body;
      if (!access_token) return Response.json({ error: 'Access token required' }, { status: 400 });

      // Verify token by fetching financial settings
      const sageRes = await fetch(`${SAGE_API_BASE}/financial_settings`, {
        headers: { 'Authorization': `Bearer ${access_token}`, 'Accept': 'application/json' },
      });

      if (!sageRes.ok) {
        const errText = await sageRes.text();
        return Response.json({ error: `Sage authentication failed (${sageRes.status}): ${errText.substring(0, 200)}` }, { status: 400 });
      }

      const settings = await sageRes.json();
      const companyName = settings?.legal_name || settings?.company_name || 'Unknown Company';

      // Upsert connection
      const existing = await base44.entities.SageConnection.filter({ user_id: user.id });
      let conn;
      if (existing.length > 0) {
        conn = await base44.entities.SageConnection.update(existing[0].id, {
          access_token,
          country_region: country_region || 'za',
          company_name: companyName,
          connection_status: 'connected',
          last_sync_date: new Date().toISOString(),
          last_error: '',
        });
      } else {
        conn = await base44.entities.SageConnection.create({
          user_id: user.id,
          access_token,
          country_region: country_region || 'za',
          company_name: companyName,
          connection_status: 'connected',
          last_sync_date: new Date().toISOString(),
        });
      }

      return Response.json({ status: 'connected', company_name: companyName, connection: conn });
    }

    // ── DISCONNECT ──
    if (action === 'disconnect') {
      const existing = await base44.entities.SageConnection.filter({ user_id: user.id });
      if (existing.length > 0) {
        await base44.entities.SageConnection.update(existing[0].id, {
          connection_status: 'disconnected',
          access_token: '',
        });
      }
      return Response.json({ status: 'disconnected' });
    }

    // ── STATUS: check current connection ──
    if (action === 'status') {
      const existing = await base44.entities.SageConnection.filter({ user_id: user.id });
      if (existing.length === 0 || existing[0].connection_status !== 'connected') {
        return Response.json({ connected: false });
      }
      return Response.json({
        connected: true,
        company_name: existing[0].company_name,
        last_sync_date: existing[0].last_sync_date,
        country_region: existing[0].country_region,
      });
    }

    // ── FETCH: read books from Sage ──
    if (action === 'fetch' || action === 'analyze') {
      const existing = await base44.entities.SageConnection.filter({ user_id: user.id });
      if (existing.length === 0 || existing[0].connection_status !== 'connected') {
        return Response.json({ error: 'Sage not connected. Please connect your account first.' }, { status: 400 });
      }

      const conn = existing[0];
      const token = conn.access_token;
      const headers = { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' };

      // Fetch key financial data (read-only)
      const sections = body?.sections || ['financial_settings', 'ledger_accounts', 'contacts', 'sales_invoices', 'purchase_invoices', 'bank_accounts'];
      const results = {};

      for (const section of sections) {
        const endpoint = section === 'financial_settings' ? 'financial_settings' : section;
        try {
          const res = await fetch(`${SAGE_API_BASE}/${endpoint}?$top=50`, { headers });
          if (res.ok) {
            const data = await res.json();
            results[section] = data;
          } else {
            results[section] = { error: `HTTP ${res.status}` };
          }
        } catch (e) {
          results[section] = { error: e.message };
        }
      }

      // Update last sync
      await base44.entities.SageConnection.update(conn.id, {
        last_sync_date: new Date().toISOString(),
      });

      // ── AI ANALYSIS ──
      if (action === 'analyze') {
        const businessProfiles = await base44.entities.BusinessProfile.filter({ user_id: user.id });
        const profile = businessProfiles.find(p => p.onboarding_complete) || businessProfiles[0];

        const businessContext = profile ? `
Business Name: ${profile.entity_name}
Entity Type: ${profile.entity_type}
Industry: ${profile.industry}
VAT Registered: ${profile.vat_registered}
Employees: ${profile.employee_count}` : '';

        // Summarize financial data for AI (avoid sending too much raw data)
        const financialSummary = {
          company: results.financial_settings?.legal_name || results.financial_settings?.company_name || 'Unknown',
          vat_number: results.financial_settings?.vat_number || 'N/A',
          base_currency: results.financial_settings?.base_currency || 'N/A',
          ledger_accounts: (results.ledger_accounts?.$items || []).map(a => ({
            name: a.name,
            code: a.nominal_code,
            balance: a.balance,
            category: a.ledger_account_type?.name || a.category,
          })),
          contacts_count: results.contacts?.$total || 0,
          contacts_sample: (results.contacts?.$items || []).slice(0, 10).map(c => ({
            name: c.name,
            type: c.contact_type_ids?.length > 0 ? 'Customer/Supplier' : 'Contact',
            balance: c.balance,
          })),
          sales_invoices: (results.sales_invoices?.$items || []).slice(0, 20).map(inv => ({
            reference: inv.reference,
            contact: inv.contact_name,
            net_amount: inv.net_amount,
            tax_amount: inv.tax_amount,
            total: inv.total_amount,
            status: inv.status?.name,
            due_date: inv.due_date,
          })),
          purchase_invoices: (results.purchase_invoices?.$items || []).slice(0, 20).map(inv => ({
            reference: inv.reference,
            contact: inv.contact_name,
            net_amount: inv.net_amount,
            tax_amount: inv.tax_amount,
            total: inv.total_amount,
            status: inv.status?.name,
            due_date: inv.due_date,
          })),
          bank_accounts: (results.bank_accounts?.$items || []).map(b => ({
            name: b.bank_account_name,
            balance: b.balance,
            account_number: b.account_number ? b.account_number.substring(0, 4) + '****' : 'N/A',
          })),
        };

        const aiResult = await base44.integrations.Core.InvokeLLM({
          prompt: `You are Compl-i Assistant, the AI compliance engine for Compl-Ai™ SA, a South African compliance platform.

A user has connected their Sage Business Cloud Accounting books. Analyse the following financial data and provide compliance insights.

BUSINESS CONTEXT:
${businessContext}

SAGE FINANCIAL DATA (read-only, fetched via Sage Business Cloud Accounting API):
${JSON.stringify(financialSummary, null, 2)}

Provide a compliance-focused financial analysis. Return JSON with:
- vat_status: string (assessment of VAT registration and filing status based on invoices)
- revenue_estimate: string (estimated revenue range based on sales invoices)
- tax_compliance_notes: string (2-3 sentences on tax compliance observations: VAT on invoices, deductible expenses, etc.)
- risk_flags: array of strings (compliance risk flags detected in the financial data, e.g. "Missing VAT numbers on invoices", "Outstanding supplier payments affecting tax deductions")
- recommendations: array of strings (3-5 actionable compliance recommendations based on the financial data)
- financial_health: string (1-2 sentence financial health summary)
- sars_relevance: string (how this financial data impacts SARS compliance: provisional tax, VAT201, etc.)`,
          response_json_schema: {
            type: 'object',
            properties: {
              vat_status: { type: 'string' },
              revenue_estimate: { type: 'string' },
              tax_compliance_notes: { type: 'string' },
              risk_flags: { type: 'array', items: { type: 'string' } },
              recommendations: { type: 'array', items: { type: 'string' } },
              financial_health: { type: 'string' },
              sars_relevance: { type: 'string' },
            },
          },
        });

        return Response.json({
          raw_data: results,
          ai_analysis: aiResult,
          company_name: conn.company_name,
          sync_date: new Date().toISOString(),
        });
      }

      return Response.json({
        raw_data: results,
        company_name: conn.company_name,
        sync_date: new Date().toISOString(),
      });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});