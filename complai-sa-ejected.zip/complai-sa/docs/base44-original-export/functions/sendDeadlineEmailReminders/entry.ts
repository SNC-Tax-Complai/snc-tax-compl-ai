import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden — admin only' }, { status: 403 });

    const today = new Date();
    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(today.getDate() + 7);

    const profiles = await base44.asServiceRole.entities.BusinessProfile.filter({});

    const notifications = [];

    for (const profile of profiles) {
      if (!profile.onboarding_complete) continue;
      if (!profile.director_email || !profile.director_email.trim()) continue;

      let deadlines = [];
      try {
        deadlines = JSON.parse(profile.upcoming_deadlines || '[]');
      } catch (_) { continue; }

      // Filter to SARS and CIPC deadlines due within 7 days
      const dueSoon = deadlines.filter(d => {
        if (!d.date || !d.type) return false;
        const isRelevant = ['SARS', 'CIPC'].includes(d.type);
        if (!isRelevant) return false;
        const deadlineDate = new Date(d.date);
        if (isNaN(deadlineDate.getTime())) return false;
        return deadlineDate >= today && deadlineDate <= sevenDaysFromNow;
      });

      if (dueSoon.length === 0) continue;

      const deadlineLines = dueSoon.map(d =>
        `• ${d.label} (${d.type}) — ${d.date}${d.urgent ? ' — ⚠️ URGENT' : ''}`
      ).join('\n');

      const subject = `⚠️ Upcoming SARS/CIPC Filing Reminder — ${profile.entity_name || 'Your Business'}`;
      const body = `Dear ${profile.director_name || 'Director'},

This is an automated reminder from Compl-Ai™ SA. You have the following upcoming SARS and/or CIPC compliance deadline(s) within the next 7 days:

${deadlineLines}

Filing Type Summary:
${dueSoon.map(d => `  - ${d.type}: ${d.label} due ${d.date}`).join('\n')}

Please log in to your Compl-Ai™ SA dashboard to action these filings before the due dates to maintain compliance.

Dashboard: ${req.headers.get('origin') || 'https://your-app.com'}

This is an automated reminder. If you have already filed, please disregard this email.

— Compl-i Assistant™
Compl-Ai™ SA · SNC-TAX · SA-iLabs®™`;

      try {
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: profile.director_email,
          subject,
          body,
          from_name: 'Compl-Ai™ SA Reminders',
        });
        notifications.push({
          profile_id: profile.id,
          entity_name: profile.entity_name,
          email: profile.director_email,
          deadlines_count: dueSoon.length,
          sent: true,
        });
      } catch (e) {
        notifications.push({
          profile_id: profile.id,
          entity_name: profile.entity_name,
          email: profile.director_email,
          deadlines_count: dueSoon.length,
          sent: false,
          error: e.message,
        });
      }
    }

    return Response.json({
      success: true,
      checked: profiles.length,
      notified: notifications.filter(n => n.sent).length,
      failed: notifications.filter(n => !n.sent).length,
      details: notifications,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});