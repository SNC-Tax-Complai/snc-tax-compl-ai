import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

function normalizePhone(raw) {
  let phone = String(raw || '').replace(/[\s\-()]/g, '');
  if (phone.startsWith('0')) phone = '27' + phone.substring(1);
  return phone.replace('+', '');
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { to, messageText } = body;

    if (!to || !messageText) {
      return Response.json({ error: 'Missing "to" (phone number) or "messageText"' }, { status: 400 });
    }

    const phone = normalizePhone(to);

    // Authorization: non-admins may only send a notification to their own
    // registered WhatsApp number — never to an arbitrary recipient.
    if (user.role !== 'admin') {
      const profiles = await base44.entities.BusinessProfile.filter({ user_id: user.id });
      const ownPhone = profiles[0]?.whatsapp_number ? normalizePhone(profiles[0].whatsapp_number) : null;
      if (!ownPhone || ownPhone !== phone) {
        return Response.json({ error: 'You may only send notifications to your own registered WhatsApp number' }, { status: 403 });
      }
    }

    const token = Deno.env.get('WHATSAPP_ACCESS_TOKEN');
    const phoneNumberId = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID');

    if (!token || !phoneNumberId) {
      return Response.json({ error: 'WhatsApp credentials not configured' }, { status: 500 });
    }

    const url = `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`;
    const payload = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: phone,
      type: 'text',
      text: { body: messageText },
    };

    const resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await resp.json();

    if (!resp.ok) {
      return Response.json({ error: data.error?.message || 'WhatsApp API error', details: data }, { status: resp.status });
    }

    return Response.json({ success: true, message_id: data.messages?.[0]?.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});