// Compl-Ai SA — runtime API config.
// Loaded before React boots. Change apiUrl to repoint the backend WITHOUT
// rebuilding the frontend, then restart the frontend container.
// "/api" = same-origin; nginx proxies it to the backend. Correct for local
// Docker and for https://www.complai-sa.cloud via Cloudflare Tunnel.
window.COMPL_AI_CONFIG = {
  apiUrl: "/api"
};
