import jwt from 'jsonwebtoken';
import db from './db.js';

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 32) {
  console.error('FATAL: JWT_SECRET must be set and at least 32 characters.');
  process.exit(1);
}

export const signToken = (user) =>
  jwt.sign({ sub: user.id, email: user.email, role: user.role }, SECRET, {
    expiresIn: process.env.JWT_EXPIRY || '24h',
  });

export const verifyToken = (token) => jwt.verify(token, SECRET);

/** Bearer header, or ?token= for EventSource (which cannot set headers). */
export const extractToken = (req) => {
  const h = req.headers.authorization;
  if (h && h.startsWith('Bearer ')) return h.slice(7);
  if (req.query && typeof req.query.token === 'string') return req.query.token;
  return null;
};

export const requireAuth = async (req, res, next) => {
  const token = extractToken(req);
  if (!token) return res.status(401).json({ message: 'Authentication required' });
  try {
    const payload = verifyToken(token);
    const user = await db.one(
      'SELECT id, email, full_name, role, is_active, created_date FROM users WHERE id = $1',
      [payload.sub]
    );
    if (!user || !user.is_active) return res.status(401).json({ message: 'User inactive or not found' });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};

export const requireRole = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ message: 'Authentication required' });
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ message: `Requires role: ${roles.join(' or ')}` });
  }
  next();
};
