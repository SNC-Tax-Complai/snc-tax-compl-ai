import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';
import db from './db.js';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), 'migrations');

const run = async () => {
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
  for (const f of files) {
    process.stdout.write(`  applying ${f} ... `);
    await db.query(fs.readFileSync(path.join(dir, f), 'utf8'));
    console.log('ok');
  }

  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';

  if (email && password) {
    if (password.length < 12) {
      console.error('\n  ADMIN_PASSWORD must be at least 12 characters. Admin not created.');
    } else {
      const hash = await bcrypt.hash(password, 12);
      await db.query(
        `INSERT INTO users (email, password_hash, full_name, role)
         VALUES ($1,$2,$3,'sudo')
         ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, role = 'sudo'`,
        [email, hash, process.env.ADMIN_NAME || 'Administrator']
      );
      console.log(`  admin user ready: ${email}`);
    }
  } else {
    console.log('  no ADMIN_EMAIL/ADMIN_PASSWORD set — skipping admin seed');
  }

  console.log('\nMigrations complete.');
  await db.pool.end();
};

run().catch((e) => { console.error('\nMigration failed:', e.message); process.exit(1); });
