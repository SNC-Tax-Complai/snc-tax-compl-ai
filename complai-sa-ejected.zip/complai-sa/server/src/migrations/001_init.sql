-- Compl-Ai SA — self-hosted schema.
-- Entities are stored schemalessly, so records live in a JSONB column.
-- Frequently-filtered keys (user_id, business_profile_id, status) are lifted
-- into generated columns and indexed, which keeps filter() fast without
-- forcing a rigid schema onto the six entity types.

-- gen_random_uuid() is built into PostgreSQL 13+; pgcrypto is not needed.

CREATE TABLE IF NOT EXISTS users (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email          TEXT UNIQUE NOT NULL,
  password_hash  TEXT NOT NULL,
  full_name      TEXT,
  role           TEXT NOT NULL DEFAULT 'user'
                 CHECK (role IN ('admin','user','auditor','sudo')),
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_date   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_date   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS records (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity        TEXT NOT NULL,
  data          JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by    UUID REFERENCES users(id) ON DELETE SET NULL,
  created_date  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_date  TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id             TEXT GENERATED ALWAYS AS (data->>'user_id') STORED,
  business_profile_id TEXT GENERATED ALWAYS AS (data->>'business_profile_id') STORED,
  status              TEXT GENERATED ALWAYS AS (data->>'status') STORED
);

CREATE INDEX IF NOT EXISTS idx_records_entity        ON records (entity);
CREATE INDEX IF NOT EXISTS idx_records_entity_user   ON records (entity, user_id);
CREATE INDEX IF NOT EXISTS idx_records_entity_bp     ON records (entity, business_profile_id);
CREATE INDEX IF NOT EXISTS idx_records_entity_status ON records (entity, status);
CREATE INDEX IF NOT EXISTS idx_records_created       ON records (entity, created_date DESC);
CREATE INDEX IF NOT EXISTS idx_records_data_gin      ON records USING GIN (data jsonb_path_ops);

CREATE TABLE IF NOT EXISTS conversations (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  agent_name    TEXT NOT NULL DEFAULT 'compliance_assistant',
  title         TEXT,
  metadata      JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_date  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_date  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations (user_id, updated_date DESC);

CREATE TABLE IF NOT EXISTS messages (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id  UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role             TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
  content          TEXT NOT NULL,
  model            TEXT,
  created_date     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages (conversation_id, created_date);

CREATE TABLE IF NOT EXISTS app_settings (
  key    TEXT PRIMARY KEY,
  value  JSONB NOT NULL DEFAULT '{}'::jsonb,
  public BOOLEAN NOT NULL DEFAULT FALSE
);

INSERT INTO app_settings (key, value, public) VALUES
  ('branding', '{"app_name":"Compl-Ai SA","primary_color":"#0ea5e9","logo_url":"/brand/snc-logo.png"}'::jsonb, TRUE)
ON CONFLICT (key) DO NOTHING;
