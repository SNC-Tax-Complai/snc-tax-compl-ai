import express from 'express';
import db from '../db.js';
import { requireAuth } from '../auth.js';
import { chat } from '../services/llm.js';

const router = express.Router();
router.use(requireAuth);

router.post('/conversations', async (req, res, next) => {
  try {
    const { agent_name = 'compliance_assistant', metadata = {} } = req.body || {};
    const conv = await db.one(
      `INSERT INTO conversations (user_id, agent_name, metadata) VALUES ($1,$2,$3) RETURNING *`,
      [req.user.id, agent_name, JSON.stringify(metadata)]
    );
    res.status(201).json(conv);
  } catch (e) { next(e); }
});

router.get('/conversations', async (req, res, next) => {
  try {
    const rows = req.query.agent_name
      ? await db.many(
          `SELECT * FROM conversations WHERE user_id = $1 AND agent_name = $2
           ORDER BY updated_date DESC LIMIT 100`, [req.user.id, req.query.agent_name])
      : await db.many(
          `SELECT * FROM conversations WHERE user_id = $1
           ORDER BY updated_date DESC LIMIT 100`, [req.user.id]);
    res.json(rows);
  } catch (e) { next(e); }
});

const ownConversation = async (id, userId) =>
  db.one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [id, userId]);

router.get('/conversations/:id', async (req, res, next) => {
  try {
    const conv = await ownConversation(req.params.id, req.user.id);
    if (!conv) return res.status(404).json({ message: 'Conversation not found' });
    const messages = await db.many(
      'SELECT * FROM messages WHERE conversation_id = $1 ORDER BY created_date', [conv.id]);
    res.json({ ...conv, messages });
  } catch (e) { next(e); }
});

/**
 * Adds a user message and synchronously produces the assistant reply.
 * Returns both so callers that do not use the SSE stream still work.
 */
router.post('/conversations/:id/messages', async (req, res, next) => {
  try {
    const conv = await ownConversation(req.params.id, req.user.id);
    if (!conv) return res.status(404).json({ message: 'Conversation not found' });

    const { role = 'user', content } = req.body || {};
    if (!content || typeof content !== 'string') {
      return res.status(400).json({ message: 'content is required' });
    }

    const userMsg = await db.one(
      `INSERT INTO messages (conversation_id, role, content) VALUES ($1,$2,$3) RETURNING *`,
      [conv.id, role, content]
    );

    if (role !== 'user') return res.status(201).json({ message: userMsg });

    const history = await db.many(
      `SELECT role, content FROM messages WHERE conversation_id = $1
       ORDER BY created_date DESC LIMIT 20`, [conv.id]);
    history.reverse();

    const reply = await chat(history);

    const assistantMsg = await db.one(
      `INSERT INTO messages (conversation_id, role, content, model)
       VALUES ($1,'assistant',$2,$3) RETURNING *`,
      [conv.id, reply.text, reply.model]
    );

    await db.query('UPDATE conversations SET updated_date = now() WHERE id = $1', [conv.id]);
    res.status(201).json({ message: userMsg, reply: assistantMsg });
  } catch (e) { next(e); }
});

/**
 * SSE stream for a conversation. The free OpenRouter pool is used
 * non-streaming (token streaming is inconsistent across free models), so this
 * replays stored messages and then polls for new ones. The client receives an
 * unsubscribe function and JSON events.
 */
router.get('/conversations/:id/stream', async (req, res, next) => {
  try {
    const conv = await ownConversation(req.params.id, req.user.id);
    if (!conv) return res.status(404).json({ message: 'Conversation not found' });

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });

    const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);
    let lastSeen = new Date(0).toISOString();

    const poll = async () => {
      try {
        const rows = await db.many(
          `SELECT * FROM messages WHERE conversation_id = $1 AND created_date > $2
           ORDER BY created_date`, [conv.id, lastSeen]);
        for (const m of rows) {
          lastSeen = m.created_date.toISOString();
          send({ type: 'message', data: m });
        }
      } catch { /* transient db error — next tick retries */ }
    };

    await poll();
    const pollTimer = setInterval(poll, 1500);
    const pingTimer = setInterval(() => send({ type: 'ping' }), 25000);

    req.on('close', () => { clearInterval(pollTimer); clearInterval(pingTimer); });
  } catch (e) { next(e); }
});

export default router;
