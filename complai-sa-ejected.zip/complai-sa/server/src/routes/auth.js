import express from 'express';
import bcrypt from 'bcryptjs';
import db from '../db.js';
import { signToken, requireAuth } from '../auth.js';

const router = express.Router();

const shape = (u) => ({
  id: u.id, email: u.email, full_name: u.full_name,
  role: u.role, created_date: u.created_date,
});

router.post('/register', async (req, res, next) => {
  try {
    const { email, password, full_name } = req.body || {};
    if (!email || !password) return res.status(400).json({ message: 'email and password are required' });
    if (String(password).length < 8) return res.status(400).json({ message: 'Password must be at least 8 characters' });

    const existing = await db.one('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existing) return res.status(409).json({ message: 'An account with that email already exists' });

    const hash = await bcrypt.hash(password, 12);
    const user = await db.one(
      `INSERT INTO users (email, password_hash, full_name, role)
       VALUES ($1,$2,$3,'user')
       RETURNING id, email, full_name, role, created_date`,
      [email.toLowerCase(), hash, full_name || null]
    );
    res.status(201).json({ token: signToken(user), user: shape(user) });
  } catch (e) { next(e); }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ message: 'email and password are required' });

    const user = await db.one('SELECT * FROM users WHERE email = $1', [String(email).toLowerCase()]);
    // Same response for unknown email and wrong password — no user enumeration.
    if (!user || !user.is_active || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    res.json({ token: signToken(user), user: shape(user) });
  } catch (e) { next(e); }
});

// api.auth.me() — returns the user object directly (not wrapped).
router.get('/me', requireAuth, (req, res) => res.json(shape(req.user)));

router.post('/change-password', requireAuth, async (req, res, next) => {
  try {
    const { current_password, new_password } = req.body || {};
    if (!new_password || String(new_password).length < 8) {
      return res.status(400).json({ message: 'New password must be at least 8 characters' });
    }
    const full = await db.one('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
    if (!(await bcrypt.compare(current_password || '', full.password_hash))) {
      return res.status(401).json({ message: 'Current password is incorrect' });
    }
    await db.query('UPDATE users SET password_hash = $1, updated_date = now() WHERE id = $2',
      [await bcrypt.hash(new_password, 12), req.user.id]);
    res.json({ status: 'ok' });
  } catch (e) { next(e); }
});

export default router;
