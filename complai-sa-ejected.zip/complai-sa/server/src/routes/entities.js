import express from 'express';
import db from '../db.js';
import { requireAuth } from '../auth.js';
import { emit } from '../services/events.js';

const router = express.Router();
router.use(requireAuth);

/** Only these six entities exist — anything else is rejected, not created. */
const ENTITIES = new Set([
  'User', 'BusinessProfile', 'ComplianceDocument',
  'AuditLog', 'AdminApprovalRequest', 'SageConnection',
]);

/** Entities only an admin/sudo may write. */
const ADMIN_WRITE = new Set(['AuditLog']);

const guard = (req, res, next) => {
  if (!ENTITIES.has(req.params.entity)) {
    return res.status(404).json({ message: `Unknown entity: ${req.params.entity}` });
  }
  next();
};

const isPrivileged = (u) => ['admin', 'sudo', 'auditor'].includes(u.role);

const shape = (r) => ({
  id: r.id,
  ...r.data,
  created_by: r.created_by,
  created_date: r.created_date,
  updated_date: r.updated_date,
});

/**
 * Sort strings arrive as 'created_date' or '-created_date'.
 * Only whitelisted columns are interpolated — never raw user input.
 */
const SORTABLE = new Set(['created_date', 'updated_date', 'id']);
const JSON_KEY = /^[A-Za-z0-9_]{1,64}$/;

function orderBy(sort) {
  if (!sort) return 'created_date DESC';
  const desc = sort.startsWith('-');
  const col = desc ? sort.slice(1) : sort;
  const dir = desc ? 'DESC' : 'ASC';

  if (SORTABLE.has(col)) return `${col} ${dir}`;

  // Unknown column -> sort inside the JSONB document. The key is validated
  // against a strict character class rather than escaped, so nothing that is
  // not [A-Za-z0-9_] can ever reach the SQL string.
  if (JSON_KEY.test(col)) return `data->>'${col}' ${dir}`;

  return 'created_date DESC';
}

// GET /api/entities/:entity?q={...}&sort=-created_date&limit=200
router.get('/:entity', guard, async (req, res, next) => {
  try {
    const { entity } = req.params;
    const limit = Math.min(Number(req.query.limit) || 500, 1000);

    let query = {};
    if (req.query.q) {
      try { query = JSON.parse(req.query.q); }
      catch { return res.status(400).json({ message: 'q must be valid JSON' }); }
    }

    const params = [entity];
    const where = ['entity = $1'];

    // Non-privileged users only ever see their own rows.
    if (!isPrivileged(req.user)) {
      params.push(req.user.id);
      where.push(`(created_by = $${params.length} OR user_id = $${params.length}::text)`);
    }

    // JSONB containment for the filter object — one indexed operation.
    if (Object.keys(query).length) {
      params.push(JSON.stringify(query));
      where.push(`data @> $${params.length}::jsonb`);
    }

    params.push(limit);
    const rows = await db.many(
      `SELECT * FROM records WHERE ${where.join(' AND ')}
       ORDER BY ${orderBy(req.query.sort)} LIMIT $${params.length}`,
      params
    );
    res.json(rows.map(shape));
  } catch (e) { next(e); }
});

router.get('/:entity/:id', guard, async (req, res, next) => {
  try {
    const row = await db.one('SELECT * FROM records WHERE id = $1 AND entity = $2',
      [req.params.id, req.params.entity]);
    if (!row) return res.status(404).json({ message: 'Not found' });
    if (!isPrivileged(req.user) && row.created_by !== req.user.id && row.user_id !== req.user.id) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    res.json(shape(row));
  } catch (e) { next(e); }
});

router.post('/:entity', guard, async (req, res, next) => {
  try {
    const { entity } = req.params;
    if (ADMIN_WRITE.has(entity) && !isPrivileged(req.user)) {
      return res.status(403).json({ message: `${entity} is written by the server only` });
    }
    const data = { ...(req.body || {}) };
    delete data.id; delete data.created_date; delete data.updated_date; delete data.created_by;

    const row = await db.one(
      'INSERT INTO records (entity, data, created_by) VALUES ($1,$2,$3) RETURNING *',
      [entity, JSON.stringify(data), req.user.id]
    );
    const out = shape(row);
    emit(entity, 'create', out);
    res.status(201).json(out);
  } catch (e) { next(e); }
});

router.post('/:entity/bulk', guard, async (req, res, next) => {
  try {
    const rows = req.body?.rows;
    if (!Array.isArray(rows) || !rows.length) return res.status(400).json({ message: 'rows[] required' });
    if (rows.length > 500) return res.status(400).json({ message: 'Max 500 rows per bulk insert' });

    const out = [];
    for (const r of rows) {
      const data = { ...r };
      delete data.id; delete data.created_date; delete data.updated_date; delete data.created_by;
      const row = await db.one(
        'INSERT INTO records (entity, data, created_by) VALUES ($1,$2,$3) RETURNING *',
        [req.params.entity, JSON.stringify(data), req.user.id]
      );
      out.push(shape(row));
    }
    emit(req.params.entity, 'bulk_create', { count: out.length });
    res.status(201).json(out);
  } catch (e) { next(e); }
});

router.put('/:entity/:id', guard, async (req, res, next) => {
  try {
    const existing = await db.one('SELECT * FROM records WHERE id = $1 AND entity = $2',
      [req.params.id, req.params.entity]);
    if (!existing) return res.status(404).json({ message: 'Not found' });
    if (!isPrivileged(req.user) && existing.created_by !== req.user.id && existing.user_id !== req.user.id) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    const patch = { ...(req.body || {}) };
    delete patch.id; delete patch.created_date; delete patch.updated_date; delete patch.created_by;

    // Shallow merge — matches api.entities.<E>.update() semantics.
    const row = await db.one(
      `UPDATE records SET data = data || $1::jsonb, updated_date = now()
       WHERE id = $2 RETURNING *`,
      [JSON.stringify(patch), req.params.id]
    );
    const out = shape(row);
    emit(req.params.entity, 'update', out);
    res.json(out);
  } catch (e) { next(e); }
});

router.delete('/:entity/:id', guard, async (req, res, next) => {
  try {
    const existing = await db.one('SELECT * FROM records WHERE id = $1 AND entity = $2',
      [req.params.id, req.params.entity]);
    if (!existing) return res.status(404).json({ message: 'Not found' });
    if (!isPrivileged(req.user) && existing.created_by !== req.user.id && existing.user_id !== req.user.id) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    await db.query('DELETE FROM records WHERE id = $1', [req.params.id]);
    emit(req.params.entity, 'delete', { id: req.params.id });
    res.status(204).end();
  } catch (e) { next(e); }
});

export default router;
