import express from 'express';
import db from '../db.js';
import { requireAuth, requireRole } from '../auth.js';
import { invokeLLM } from '../services/llm.js';
import { sendEmail, sendWhatsApp } from '../services/notify.js';
import { emit } from '../services/events.js';

/**
 * The eight server-side jobs, invoked from the frontend via
 * api.functions.invoke('<name>', payload).
 */
const router = express.Router();
router.use(requireAuth);

const audit = (userId, action, details) =>
  db.query(
    `INSERT INTO records (entity, data, created_by)
     VALUES ('AuditLog', $1::jsonb, $2)`,
    [JSON.stringify({ action, details, actor_id: userId, timestamp: new Date().toISOString() }), userId]
  );

const profileFor = async (user, profileId) => {
  if (profileId) {
    return db.one(`SELECT * FROM records WHERE id = $1 AND entity = 'BusinessProfile'`, [profileId]);
  }
  return db.one(
    `SELECT * FROM records WHERE entity = 'BusinessProfile'
     AND (created_by = $1 OR user_id = $1::text) ORDER BY created_date LIMIT 1`,
    [user.id]
  );
};

const docsFor = (profileId) =>
  db.many(
    `SELECT * FROM records WHERE entity = 'ComplianceDocument'
     AND business_profile_id = $1::text ORDER BY created_date DESC LIMIT 500`,
    [profileId]
  );

const handlers = {
  /** Deadlines falling due inside `days` (default 30). */
  async checkDeadlineReminders(req) {
    const days = Number(req.body?.days || 30);
    const profile = await profileFor(req.user, req.body?.profile_id);
    if (!profile) return { status: 'no_profile', due: [] };

    const docs = await docsFor(profile.id);
    const now = Date.now();
    const horizon = now + days * 86400000;

    const due = docs
      .map((d) => ({ id: d.id, ...d.data }))
      .filter((d) => {
        if (!d.due_date) return false;
        const t = Date.parse(d.due_date);
        return !Number.isNaN(t) && t <= horizon && d.status !== 'verified';
      })
      .map((d) => ({
        ...d,
        days_remaining: Math.ceil((Date.parse(d.due_date) - now) / 86400000),
        overdue: Date.parse(d.due_date) < now,
      }))
      .sort((a, b) => a.days_remaining - b.days_remaining);

    return { status: 'ok', profile_id: profile.id, count: due.length, due };
  },

  async generateAuditorSummary(req) {
    const profile = await profileFor(req.user, req.body?.profile_id);
    if (!profile) return { status: 'no_profile' };
    const docs = await docsFor(profile.id);

    const counts = docs.reduce((a, d) => {
      const s = d.data.status || 'unknown';
      a[s] = (a[s] || 0) + 1;
      return a;
    }, {});

    const result = await invokeLLM({
      prompt: `Produce an independent auditor's compliance summary for this South African entity.

Entity: ${profile.data.entity_name || 'Unknown'}
Type: ${profile.data.entity_type || 'Pty Ltd'}
Registration: ${profile.data.reg_number || 'n/a'}
Industry: ${profile.data.industry || 'General'}
Province: ${profile.data.province || 'n/a'}
Employees: ${profile.data.employee_count || 'n/a'}
Overall compliance score: ${profile.data.compliance_score ?? 'n/a'}%
Document status counts: ${JSON.stringify(counts)}
Total documents on file: ${docs.length}`,
      response_json_schema: {
        type: 'object',
        properties: {
          overall_opinion: { type: 'string' },
          risk_rating: { type: 'string', enum: ['low', 'medium', 'high', 'critical'] },
          key_findings: { type: 'array', items: { type: 'string' } },
          material_gaps: { type: 'array', items: { type: 'string' } },
          recommendations: { type: 'array', items: { type: 'string' } },
        },
        required: ['overall_opinion', 'risk_rating', 'key_findings', 'recommendations'],
      },
    });

    await audit(req.user.id, 'auditor_summary_generated', { profile_id: profile.id });
    return { status: 'ok', model: result.model, summary: result.data, document_counts: counts };
  },

  async generateMonthlyReport(req) {
    const profile = await profileFor(req.user, req.body?.profile_id);
    if (!profile) return { status: 'no_profile' };
    const docs = await docsFor(profile.id);

    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const thisMonth = docs.filter((d) => new Date(d.created_date) >= monthStart);

    const result = await invokeLLM({
      prompt: `Write the monthly compliance report for ${profile.data.entity_name || 'the entity'}
covering ${monthStart.toISOString().slice(0, 7)}.

Compliance score: ${profile.data.compliance_score ?? 'n/a'}%
Module scores — CIPC: ${profile.data.cipc_score ?? 'n/a'}, SARS: ${profile.data.sars_score ?? 'n/a'}
Documents added this month: ${thisMonth.length}
Total documents: ${docs.length}
Statuses: ${JSON.stringify(docs.reduce((a, d) => { const s = d.data.status || 'unknown'; a[s] = (a[s] || 0) + 1; return a; }, {}))}`,
      response_json_schema: {
        type: 'object',
        properties: {
          executive_summary: { type: 'string' },
          highlights: { type: 'array', items: { type: 'string' } },
          concerns: { type: 'array', items: { type: 'string' } },
          next_month_priorities: { type: 'array', items: { type: 'string' } },
        },
        required: ['executive_summary', 'highlights', 'next_month_priorities'],
      },
    });

    return {
      status: 'ok',
      model: result.model,
      period: monthStart.toISOString().slice(0, 7),
      report: result.data,
      stats: { documents_this_month: thisMonth.length, total_documents: docs.length },
    };
  },

  async logApprovalAction(req) {
    const { request_id, action, reason } = req.body || {};
    if (!request_id || !['approved', 'rejected'].includes(action)) {
      const e = new Error("request_id and action ('approved'|'rejected') are required");
      e.status = 400;
      throw e;
    }
    if (!['admin', 'sudo'].includes(req.user.role)) {
      const e = new Error('Only admin or sudo may approve or reject');
      e.status = 403;
      throw e;
    }

    const updated = await db.one(
      `UPDATE records SET data = data || $1::jsonb, updated_date = now()
       WHERE id = $2 AND entity = 'AdminApprovalRequest' RETURNING *`,
      [JSON.stringify({
        status: action,
        reviewed_by: req.user.email,
        reviewed_at: new Date().toISOString(),
        review_reason: reason || null,
      }), request_id]
    );
    if (!updated) { const e = new Error('Approval request not found'); e.status = 404; throw e; }

    await audit(req.user.id, `approval_${action}`, { request_id, reason: reason || null });
    emit('AdminApprovalRequest', 'update', { id: updated.id, ...updated.data });
    emit('AuditLog', 'create', { action: `approval_${action}` });
    return { status: 'ok', request: { id: updated.id, ...updated.data } };
  },

  async onDocumentStatusChange(req) {
    const { document_id, new_status } = req.body || {};
    if (!document_id || !new_status) {
      const e = new Error('document_id and new_status are required');
      e.status = 400;
      throw e;
    }

    const doc = await db.one(
      `UPDATE records SET data = data || $1::jsonb, updated_date = now()
       WHERE id = $2 AND entity = 'ComplianceDocument' RETURNING *`,
      [JSON.stringify({ status: new_status, status_changed_at: new Date().toISOString() }), document_id]
    );
    if (!doc) { const e = new Error('Document not found'); e.status = 404; throw e; }

    await audit(req.user.id, 'document_status_changed', { document_id, new_status });
    emit('ComplianceDocument', 'update', { id: doc.id, ...doc.data });

    let notified = null;
    const profile = await profileFor(req.user, doc.data.business_profile_id);
    if (profile?.data?.whatsapp_number) {
      notified = await sendWhatsApp({
        to: profile.data.whatsapp_number,
        message: `Compl-Ai SA: "${doc.data.name || 'Document'}" is now ${new_status}.`,
      }).catch((e) => ({ status: 'error', reason: e.message }));
    }
    return { status: 'ok', document: { id: doc.id, ...doc.data }, notification: notified };
  },

  /**
   * Sage Business Cloud. Deliberately unimplemented: this requires a Sage
   * OAuth app whose credentials are not part of this codebase. Returns a
   * clear, actionable status instead of pretending to work.
   */
  async sageReadBooks(req) {
    const action = req.body?.action || 'status';
    const configured = !!(process.env.SAGE_CLIENT_ID && process.env.SAGE_CLIENT_SECRET);

    if (!configured) {
      return {
        status: 'not_configured',
        action,
        connected: false,
        message:
          'Sage integration is not configured. Register a Sage Business Cloud OAuth app, set ' +
          'SAGE_CLIENT_ID, SAGE_CLIENT_SECRET and SAGE_REDIRECT_URI, then implement the token ' +
          'exchange in server/src/routes/functions.js.',
      };
    }
    return { status: 'not_implemented', action, connected: false,
      message: 'Sage credentials are present but the OAuth flow has not been ported yet.' };
  },

  async sendDeadlineEmailReminders(req) {
    const result = await handlers.checkDeadlineReminders(req);
    if (result.status !== 'ok' || !result.due.length) {
      return { status: 'ok', sent: 0, reason: 'nothing due' };
    }
    const profile = await profileFor(req.user, req.body?.profile_id);
    const to = req.body?.to || profile?.data?.director_email;
    if (!to) return { status: 'skipped', reason: 'no recipient email on the business profile' };

    const rows = result.due.slice(0, 25)
      .map((d) => `<li><strong>${d.name || 'Requirement'}</strong> — due ${d.due_date}` +
                  `${d.overdue ? ' <span style="color:#dc2626">(OVERDUE)</span>' : ` (${d.days_remaining} days)`}</li>`)
      .join('');

    const sent = await sendEmail({
      to,
      subject: `Compl-Ai SA — ${result.due.length} compliance deadline(s) approaching`,
      from_name: 'Compl-Ai SA',
      body: `<p>Hello,</p><p>The following items need attention:</p><ul>${rows}</ul>
             <p>Sign in to Compl-Ai SA to action them.</p>`,
    });
    return { status: 'ok', sent: sent.status === 'sent' ? result.due.length : 0, mail: sent };
  },

  async sendWhatsAppNotification(req) {
    const { to, message, template, params } = req.body || {};
    if (!to || (!message && !template)) {
      const e = new Error('to, and either message or template, are required');
      e.status = 400;
      throw e;
    }
    const r = await sendWhatsApp({ to, message, template, params });
    await audit(req.user.id, 'whatsapp_sent', { to, status: r.status });
    return r;
  },
};

router.post('/:name', async (req, res, next) => {
  const fn = handlers[req.params.name];
  if (!fn) {
    return res.status(404).json({
      message: `Unknown function: ${req.params.name}`,
      available: Object.keys(handlers),
    });
  }
  try {
    res.json(await fn(req));
  } catch (e) { next(e); }
});

router.get('/', requireRole('admin', 'sudo'), (req, res) =>
  res.json({ functions: Object.keys(handlers) }));

export default router;
