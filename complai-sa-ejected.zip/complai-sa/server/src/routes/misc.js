import express from 'express';
import db from '../db.js';
import { requireAuth } from '../auth.js';
import { addClient } from '../services/events.js';
import { isConfigured as llmConfigured } from '../services/llm.js';

export const publicRouter = express.Router();

/** Branding / white-label settings. Deliberately unauthenticated. */
publicRouter.get('/settings/public', async (req, res, next) => {
  try {
    const rows = await db.many('SELECT key, value FROM app_settings WHERE public = TRUE');
    const public_settings = rows.reduce((a, r) => ({ ...a, [r.key]: r.value }), {});
    res.json({ id: 'complai-sa', public_settings });
  } catch (e) { next(e); }
});

publicRouter.get('/health', async (req, res) => {
  let database = 'disconnected';
  try { await db.query('SELECT 1'); database = 'connected'; } catch { /* reported below */ }
  res.status(database === 'connected' ? 200 : 503).json({
    status: database === 'connected' ? 'healthy' : 'degraded',
    database,
    ai: llmConfigured() ? 'configured' : 'unconfigured',
    uptime_seconds: Math.round(process.uptime()),
  });
});

export const eventsRouter = express.Router();

/** SSE entity-change stream backing api.entities.<E>.subscribe(). */
eventsRouter.get('/events', requireAuth, (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write(`data: ${JSON.stringify({ type: 'connected' })}\n\n`);

  const remove = addClient(res, req.user.id);
  const ping = setInterval(() => {
    try { res.write(`data: ${JSON.stringify({ type: 'ping' })}\n\n`); } catch { /* closing */ }
  }, 25000);

  req.on('close', () => { clearInterval(ping); remove(); });
});
