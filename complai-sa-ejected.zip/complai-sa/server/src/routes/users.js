import express from 'express';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import db from '../db.js';
import { requireAuth, requireRole } from '../auth.js';
import { sendEmail } from '../services/notify.js';

const router = express.Router();
router.use(requireAuth);

const shape = (u) => ({
  id: u.id, email: u.email, full_name: u.full_name,
  role: u.role, is_active: u.is_active, created_date: u.created_date,
});

router.get('/', requireRole('admin', 'sudo', 'auditor'), async (req, res, next) => {
  try {
    res.json((await db.many(
      'SELECT id, email, full_name, role, is_active, created_date FROM users ORDER BY created_date DESC LIMIT 500'
    )).map(shape));
  } catch (e) { next(e); }
});

router.post('/invite', requireRole('admin', 'sudo'), async (req, res, next) => {
  try {
    const { email, role = 'user' } = req.body || {};
    if (!email) return res.status(400).json({ message: 'email is required' });
    if (!['admin', 'user', 'auditor'].includes(role)) {
      return res.status(400).json({ message: "role must be 'admin', 'user' or 'auditor'" });
    }
    const addr = String(email).toLowerCase();
    if (await db.one('SELECT id FROM users WHERE email = $1', [addr])) {
      return res.status(409).json({ message: 'That user already exists' });
    }

    // Create with a random password; the invitee sets their own via the link.
    const temp = crypto.randomBytes(24).toString('base64url');
    const user = await db.one(
      `INSERT INTO users (email, password_hash, role) VALUES ($1,$2,$3)
       RETURNING id, email, full_name, role, is_active, created_date`,
      [addr, await bcrypt.hash(temp, 12), role]
    );

    const appUrl = process.env.FRONTEND_URL || 'http://localhost';
    const mail = await sendEmail({
      to: addr,
      subject: 'You have been invited to Compl-Ai SA',
      from_name: 'Compl-Ai SA',
      body: `<p>You have been invited to Compl-Ai SA as <strong>${role}</strong>.</p>
             <p>Temporary password: <code>${temp}</code></p>
             <p><a href="${appUrl}/login">Sign in</a> and change it immediately.</p>`,
    }).catch((e) => ({ status: 'error', reason: e.message }));

    // If SMTP is not wired up the admin still needs a way to pass the password on.
    res.status(201).json({
      user: shape(user),
      email: mail,
      temporary_password: mail.status === 'sent' ? undefined : temp,
    });
  } catch (e) { next(e); }
});

router.put('/:id/role', requireRole('sudo'), async (req, res, next) => {
  try {
    const { role } = req.body || {};
    if (!['admin', 'user', 'auditor', 'sudo'].includes(role)) {
      return res.status(400).json({ message: 'Invalid role' });
    }
    if (req.params.id === req.user.id && role !== 'sudo') {
      return res.status(400).json({ message: 'You cannot demote yourself' });
    }
    const u = await db.one(
      `UPDATE users SET role = $1, updated_date = now() WHERE id = $2
       RETURNING id, email, full_name, role, is_active, created_date`,
      [role, req.params.id]
    );
    if (!u) return res.status(404).json({ message: 'User not found' });
    res.json(shape(u));
  } catch (e) { next(e); }
});

export default router;
