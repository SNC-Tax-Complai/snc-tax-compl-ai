import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import cron from 'node-cron';

import authRoutes from './routes/auth.js';
import entityRoutes from './routes/entities.js';
import functionRoutes from './routes/functions.js';
import integrationRoutes from './routes/integrations.js';
import agentRoutes from './routes/agents.js';
import userRoutes from './routes/users.js';
import { publicRouter, eventsRouter } from './routes/misc.js';
import { heartbeat } from './services/events.js';
import db from './db.js';

const app = express();
app.set('trust proxy', 1); // behind nginx + Cloudflare Tunnel
app.disable('x-powered-by');

const origins = (process.env.FRONTEND_URL || 'http://localhost:5173')
  .split(',').map((s) => s.trim()).filter(Boolean);

app.use(cors({
  origin: (origin, cb) => (!origin || origins.includes(origin)) ? cb(null, true) : cb(new Error('CORS: origin not allowed')),
  credentials: true,
}));

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

app.use((req, res, next) => {
  const t = Date.now();
  res.on('finish', () => {
    if (res.statusCode >= 400 || process.env.LOG_LEVEL === 'debug') {
      console.log(`${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - t}ms`);
    }
  });
  next();
});

app.use('/api', publicRouter);
app.use('/api', eventsRouter);
app.use('/api/auth', authRoutes);
app.use('/api/entities', entityRoutes);
app.use('/api/functions', functionRoutes);
app.use('/api/integrations', integrationRoutes);
app.use('/api/agents', agentRoutes);
app.use('/api/users', userRoutes);

app.use('/api', (req, res) => res.status(404).json({ message: `No such endpoint: ${req.method} ${req.path}` }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const explicit = err.status || err.statusCode;
  const status = explicit || 500;
  if (status >= 500) console.error('[error]', err.stack || err.message);

  // Messages on deliberately-thrown errors (including 502/503 from the AI and
  // notification services) are operator-actionable and are passed through.
  // Only genuinely unexpected 500s are masked, so stack details never leak.
  const message = explicit ? err.message : 'Internal server error';

  res.status(status).json({
    message,
    ...(err.raw ? { raw: err.raw } : {}),
    ...(err.attempts ? { attempts: err.attempts } : {}),
  });
});

const PORT = Number(process.env.PORT || 5000);
const TZ = process.env.TZ || 'Africa/Johannesburg';

const server = app.listen(PORT, () => {
  console.log(`Compl-Ai SA API listening on :${PORT}`);
  console.log(`  AI provider : OpenRouter free-model router (${process.env.OPENROUTER_API_KEY ? 'configured' : 'NOT CONFIGURED'})`);
  console.log(`  Allowed origins: ${origins.join(', ')}`);
});

// Keep SSE connections alive through proxies that idle-timeout.
setInterval(heartbeat, 25000).unref();

// Daily deadline sweep, 08:00 SAST — the node-cron replacement for the
// the "Daily SARS/CIPC Filing Email Reminders" scheduled job.
if (process.env.ENABLE_SCHEDULER !== 'false') {
  cron.schedule('0 8 * * *', async () => {
    console.log('[cron] daily deadline sweep');
    try {
      const rows = await db.many(
        `SELECT id, data FROM records WHERE entity = 'ComplianceDocument'
         AND status <> 'verified' AND data->>'due_date' IS NOT NULL`
      );
      const soon = rows.filter((r) => {
        const t = Date.parse(r.data.due_date);
        return !Number.isNaN(t) && t - Date.now() < 30 * 86400000;
      });
      console.log(`[cron] ${soon.length} item(s) due within 30 days`);
    } catch (e) {
      console.error('[cron] sweep failed:', e.message);
    }
  }, { timezone: TZ });
}

const shutdown = (sig) => {
  console.log(`\n${sig} received, shutting down`);
  server.close(() => db.pool.end().then(() => process.exit(0)));
  setTimeout(() => process.exit(1), 10000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

export default app;
