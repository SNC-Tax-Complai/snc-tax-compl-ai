/**
 * In-process SSE hub backing the client's entity-change subscriptions.
 * Single-node by design; if you scale the backend horizontally, swap the
 * emit() body for a Redis pub/sub publish and have each node relay.
 */
const clients = new Set();

export const addClient = (res, userId) => {
  const client = { res, userId };
  clients.add(client);
  return () => clients.delete(client);
};

/** Broadcast an entity change. `data` is the affected record. */
export const emit = (entity, action, data) => {
  const payload = `data: ${JSON.stringify({ entity, action, data })}\n\n`;
  for (const c of clients) {
    try { c.res.write(payload); } catch { clients.delete(c); }
  }
};

export const heartbeat = () => {
  const payload = `data: ${JSON.stringify({ type: 'ping' })}\n\n`;
  for (const c of clients) {
    try { c.res.write(payload); } catch { clients.delete(c); }
  }
};

export const clientCount = () => clients.size;
