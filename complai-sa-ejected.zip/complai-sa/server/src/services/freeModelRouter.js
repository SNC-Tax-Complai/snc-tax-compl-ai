/**
 * OpenRouter Free-Model Router
 * ---------------------------------------------------------------------------
 * Free-tier models on OpenRouter are aggressively rate-limited and are
 * occasionally retired without notice. This router:
 *
 *   1. Holds an ordered pool of TEXT-ONLY reasoning models (no vision needed).
 *   2. On 429 / 402 / 404 / 5xx it fails over to the next model in the pool.
 *   3. Honours `retry_after_seconds` when OpenRouter sends it.
 *   4. Repairs JSON responses (free models love wrapping JSON in ``` fences
 *      and prefixing it with "Here is the JSON:").
 *   5. Strips <think>...</think> reasoning blocks that some free reasoning
 *      models emit inline.
 *
 * Override the pool with OPENROUTER_FREE_POOL (comma-separated model ids).
 * Pin a single model with OPENROUTER_MODEL.
 */

import axios from 'axios';

export const OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1';

/**
 * Ordered free-tier pool. Verified live against
 * GET https://openrouter.ai/api/v1/models — all are text->text or accept
 * text-only input, all support reasoning, all are :free.
 */
export const DEFAULT_FREE_POOL = [
  'z-ai/glm-5.2:free',                      // 256k  · structured output · primary
  'nvidia/nemotron-3-super-120b-a12b:free', // 262k  · structured output
  'minimax/minimax-m2.7:free',              // 196k  · structured output
  'minimax/minimax-m3:free',                // 1.04M · structured output
  'google/gemma-4-31b-it:free',             // 262k  · structured output
  'nvidia/nemotron-3.5-lightning:free',     // 1.00M · long-context fallback
  'inclusionai/ling-3.0-flash-fin:free',    // 262k  · finance-tuned fallback
];

/** HTTP statuses worth failing over to the next model for. */
const FAILOVER_STATUSES = new Set([402, 403, 404, 408, 413, 429, 500, 502, 503, 504]);

export function getFreePool() {
  const pinned = (process.env.OPENROUTER_MODEL || '').trim();
  if (pinned) {
    // Pinned model first, remaining pool kept as safety net.
    return [pinned, ...DEFAULT_FREE_POOL.filter((m) => m !== pinned)];
  }
  const custom = (process.env.OPENROUTER_FREE_POOL || '').trim();
  if (custom) {
    const list = custom.split(',').map((s) => s.trim()).filter(Boolean);
    if (list.length) return list;
  }
  return [...DEFAULT_FREE_POOL];
}

/**
 * Remove inline reasoning blocks, markdown fences and leading prose so that
 * JSON.parse has a chance of succeeding on free-model output.
 */
export function extractJson(raw) {
  if (raw == null) return null;
  let text = String(raw);

  // Drop <think> / <reasoning> blocks emitted by reasoning models.
  text = text.replace(/<(think|thinking|reasoning)>[\s\S]*?<\/\1>/gi, '');

  // Prefer the contents of a fenced block if one exists.
  const fence = text.match(/```(?:json|JSON)?\s*([\s\S]*?)```/);
  if (fence) text = fence[1];

  text = text.trim();

  try {
    return JSON.parse(text);
  } catch {
    // Fall back to the outermost balanced {...} or [...] span.
    const firstObj = text.indexOf('{');
    const firstArr = text.indexOf('[');
    const candidates = [firstObj, firstArr].filter((i) => i !== -1);
    if (!candidates.length) return null;
    const start = Math.min(...candidates);
    const open = text[start];
    const close = open === '{' ? '}' : ']';
    const end = text.lastIndexOf(close);
    if (end <= start) return null;
    try {
      return JSON.parse(text.slice(start, end + 1));
    } catch {
      return null;
    }
  }
}

/** Strip reasoning blocks from a plain-text (non-JSON) chat reply. */
export function cleanText(raw) {
  if (raw == null) return '';
  return String(raw)
    .replace(/<(think|thinking|reasoning)>[\s\S]*?<\/\1>/gi, '')
    .trim();
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Call OpenRouter, walking the free pool until one model answers.
 *
 * @param {Object}  opts
 * @param {string}  opts.apiKey
 * @param {Array}   opts.messages          Full messages array (system included).
 * @param {number}  opts.temperature
 * @param {number}  opts.maxTokens
 * @param {string[]} [opts.pool]           Model pool override.
 * @param {string}  [opts.baseUrl]
 * @param {number}  [opts.timeout]
 * @param {boolean} [opts.jsonMode]        Request response_format json_object.
 * @param {number}  [opts.retriesPerModel] Rate-limit retries before failover.
 * @returns {Promise<{ok:boolean, content?:string, model?:string, attempts:Array, error?:string}>}
 */
export async function routeCompletion({
  apiKey,
  messages,
  temperature = 0.5,
  maxTokens = 1500,
  pool,
  baseUrl = OPENROUTER_BASE_URL,
  timeout = 60000,
  jsonMode = false,
  retriesPerModel = 1,
}) {
  const models = (pool && pool.length ? pool : getFreePool());
  const attempts = [];

  const headers = {
    Authorization: `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
    'HTTP-Referer': process.env.FRONTEND_URL || 'http://localhost:5173',
    'X-Title': 'Compl-Ai SA',
  };

  for (const model of models) {
    for (let attempt = 0; attempt <= retriesPerModel; attempt++) {
      try {
        const body = {
          model,
          messages,
          temperature,
          max_tokens: maxTokens,
        };
        if (jsonMode) body.response_format = { type: 'json_object' };

        const res = await axios.post(`${baseUrl}/chat/completions`, body, { headers, timeout });

        const choice = res.data?.choices?.[0]?.message;
        const content = choice?.content ?? choice?.reasoning ?? '';

        if (!content || !String(content).trim()) {
          attempts.push({ model, status: 'empty' });
          break; // empty body — try next model
        }

        attempts.push({ model, status: 'success' });
        return { ok: true, content: String(content), model, attempts };
      } catch (error) {
        const status = error.response?.status;
        const apiErr = error.response?.data?.error;
        const meta = apiErr?.metadata;
        const message = meta?.raw || apiErr?.message || error.message;

        attempts.push({ model, status: status || 'network', message });

        // Rate-limited with an explicit backoff hint — wait once, then retry.
        if (status === 429 && meta?.retry_after_seconds && attempt < retriesPerModel) {
          const wait = Math.min(Number(meta.retry_after_seconds) + 1, 15);
          await sleep(wait * 1000);
          continue;
        }

        // Auth failures are terminal — no other free model will fix a bad key.
        if (status === 401) {
          return { ok: false, error: `OpenRouter rejected the API key: ${message}`, attempts };
        }

        if (status && !FAILOVER_STATUSES.has(status)) {
          return { ok: false, error: message, attempts };
        }

        break; // fail over to the next model
      }
    }
  }

  const last = attempts[attempts.length - 1];
  return {
    ok: false,
    error: `All ${models.length} free models failed. Last error: ${last?.message || last?.status || 'unknown'}`,
    attempts,
  };
}

export default { routeCompletion, getFreePool, extractJson, cleanText, DEFAULT_FREE_POOL, OPENROUTER_BASE_URL };
