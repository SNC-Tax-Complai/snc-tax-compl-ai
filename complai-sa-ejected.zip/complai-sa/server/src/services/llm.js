import { routeCompletion, extractJson, cleanText } from './freeModelRouter.js';

export const SYSTEM_PROMPT = `You are Emma-i™, an AI compliance assistant specialising in South African SMME compliance.
Expertise: CIPC, SARS, Labour Law (BCEA/LRA/EE), OHS Act, POPIA & PAIA, B-BBEE,
FICA, municipal licensing, and industry-specific regulation.

When advising:
1. Cite specific South African legislation and section numbers.
2. Give practical, actionable steps for small business owners.
3. Flag deadlines and the penalties for missing them.
4. Weight advice by the company's size, sector and turnover.
5. Prioritise by risk (penalty size × likelihood).

Write plainly for business owners without legal training.`;

const apiKey = () => process.env.OPENROUTER_API_KEY;

export const isConfigured = () => !!apiKey();

/**
 * InvokeLLM contract:
 *   no schema  -> returns a string
 *   schema     -> returns a parsed object
 */
export async function invokeLLM({ prompt, response_json_schema, system, temperature, maxTokens }) {
  if (!isConfigured()) {
    const e = new Error('OPENROUTER_API_KEY is not set — AI features are disabled');
    e.status = 503;
    throw e;
  }

  const wantsJson = !!response_json_schema;
  const messages = [
    { role: 'system', content: system || SYSTEM_PROMPT },
    {
      role: 'user',
      content: wantsJson
        ? `${prompt}\n\nRespond with ONLY a JSON object matching this schema, no prose, no code fences:\n${JSON.stringify(response_json_schema)}`
        : prompt,
    },
  ];

  const result = await routeCompletion({
    apiKey: apiKey(),
    messages,
    temperature: temperature ?? (wantsJson ? 0.3 : 0.5),
    maxTokens: maxTokens ?? 1800,
    jsonMode: wantsJson,
  });

  if (!result.ok) {
    const e = new Error(result.error);
    e.status = 502;
    e.attempts = result.attempts;
    throw e;
  }

  if (!wantsJson) return { text: cleanText(result.content), model: result.model };

  const data = extractJson(result.content);
  if (!data) {
    const e = new Error('Model did not return parseable JSON');
    e.status = 502;
    e.raw = cleanText(result.content).slice(0, 1000);
    throw e;
  }
  return { data, model: result.model };
}

/** Plain chat turn used by the agents endpoints. */
export async function chat(history, { system } = {}) {
  if (!isConfigured()) {
    const e = new Error('OPENROUTER_API_KEY is not set — AI features are disabled');
    e.status = 503;
    throw e;
  }
  const result = await routeCompletion({
    apiKey: apiKey(),
    messages: [{ role: 'system', content: system || SYSTEM_PROMPT }, ...history],
    temperature: 0.5,
    maxTokens: 1800,
  });
  if (!result.ok) {
    const e = new Error(result.error);
    e.status = 502;
    throw e;
  }
  return { text: cleanText(result.content), model: result.model };
}
