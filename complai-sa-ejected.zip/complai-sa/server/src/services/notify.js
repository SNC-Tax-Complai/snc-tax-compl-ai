import nodemailer from 'nodemailer';
import axios from 'axios';

let transport = null;
const mailConfigured = () => !!(process.env.EMAIL_HOST && process.env.EMAIL_USER);

function getTransport() {
  if (transport) return transport;
  if (!mailConfigured()) return null;
  transport = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: Number(process.env.EMAIL_PORT || 587),
    secure: Number(process.env.EMAIL_PORT) === 465,
    auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASSWORD },
  });
  return transport;
}

export async function sendEmail({ to, subject, body, from_name }) {
  const t = getTransport();
  if (!t) return { status: 'skipped', reason: 'SMTP not configured' };
  const from = `"${from_name || 'Compl-Ai SA'}" <${process.env.EMAIL_FROM || process.env.EMAIL_USER}>`;
  const info = await t.sendMail({
    from, to, subject,
    html: body,
    text: String(body).replace(/<[^>]+>/g, ''),
  });
  return { status: 'sent', id: info.messageId };
}

export async function sendWhatsApp({ to, message, template, params }) {
  const token = process.env.WHATSAPP_API_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneId) return { status: 'skipped', reason: 'WhatsApp not configured' };

  const payload = template
    ? {
        messaging_product: 'whatsapp',
        to,
        type: 'template',
        template: {
          name: template,
          language: { code: 'en' },
          components: params ? [{ type: 'body', parameters: params.map((t) => ({ type: 'text', text: String(t) })) }] : undefined,
        },
      }
    : { messaging_product: 'whatsapp', to, type: 'text', text: { body: message } };

  const { data } = await axios.post(
    `https://graph.facebook.com/v21.0/${phoneId}/messages`,
    payload,
    { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, timeout: 20000 }
  );
  return { status: 'sent', id: data?.messages?.[0]?.id };
}
