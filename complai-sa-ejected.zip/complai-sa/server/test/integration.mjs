process.env.JWT_SECRET = 'a'.repeat(48);
process.env.PORT = '5099';
process.env.FRONTEND_URL = 'http://localhost:5173';
process.env.ENABLE_SCHEDULER = 'false';
process.env.ADMIN_EMAIL = 'admin@complai-sa.cloud';
process.env.ADMIN_PASSWORD = 'AdminPassw0rd!2026';

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const root = (p) => path.join(HERE, '..', p);
import bcrypt from 'bcryptjs';
import db from '../src/db.js';

// migrate
await (db.exec ? db.exec : db.query)(fs.readFileSync(root('src/migrations/001_init.sql'), 'utf8'));
await db.query(
  `INSERT INTO users (email, password_hash, full_name, role) VALUES ($1,$2,'Admin','sudo')`,
  [process.env.ADMIN_EMAIL, await bcrypt.hash(process.env.ADMIN_PASSWORD, 10)]
);
console.log('migrations + admin seed: OK\n');

await import('../src/server.js');
await new Promise(r => setTimeout(r, 700));

const B = 'http://127.0.0.1:5099/api';
let pass = 0, fail = 0;
const check = (name, cond, extra='') => {
  if (cond) { pass++; console.log(`  PASS  ${name}`); }
  else { fail++; console.log(`  FAIL  ${name} ${extra}`); }
};
const call = async (p, opt={}, tok) => {
  const h = { 'Content-Type':'application/json', ...(tok?{Authorization:`Bearer ${tok}`}:{}) };
  const r = await fetch(B+p, { ...opt, headers:h, body: opt.body?JSON.stringify(opt.body):undefined });
  const t = await r.text();
  let d=null; try{d=JSON.parse(t)}catch{d=t}
  return { status:r.status, data:d };
};

console.log('── public ──');
let r = await call('/health');
check('GET /health -> healthy', r.status===200 && r.data.status==='healthy', JSON.stringify(r.data));
r = await call('/settings/public');
check('GET /settings/public -> branding', r.status===200 && !!r.data.public_settings?.branding);

console.log('\n── auth ──');
r = await call('/auth/me');
check('GET /auth/me without token -> 401', r.status===401);
r = await call('/auth/login', {method:'POST', body:{email:process.env.ADMIN_EMAIL, password:'wrong'}});
check('login wrong password -> 401', r.status===401);
r = await call('/auth/login', {method:'POST', body:{email:'nobody@x.com', password:'wrong'}});
check('login unknown user -> 401 (no enumeration)', r.status===401 && r.data.message==='Invalid email or password');
r = await call('/auth/login', {method:'POST', body:{email:process.env.ADMIN_EMAIL, password:process.env.ADMIN_PASSWORD}});
check('login correct -> token', r.status===200 && !!r.data.token, JSON.stringify(r.data));
const admin = r.data.token;
r = await call('/auth/me', {}, admin);
check('GET /auth/me -> user object with role', r.status===200 && r.data.role==='sudo' && !!r.data.email);
check('auth/me does NOT leak password_hash', !('password_hash' in (r.data||{})));

r = await call('/auth/register', {method:'POST', body:{email:'sme@test.co.za', password:'SmePassw0rd!', full_name:'SME User'}});
check('register new user -> 201 + token', r.status===201 && !!r.data.token);
const userTok = r.data.token;
r = await call('/auth/register', {method:'POST', body:{email:'sme@test.co.za', password:'SmePassw0rd!'}});
check('register duplicate -> 409', r.status===409);
r = await call('/auth/register', {method:'POST', body:{email:'x@y.co.za', password:'short'}});
check('register weak password -> 400', r.status===400);

console.log('\n── entities (api.entities.*) ──');
r = await call('/entities/NotARealEntity', {}, admin);
check('unknown entity -> 404', r.status===404);

const me = (await call('/auth/me', {}, userTok)).data;
r = await call('/entities/BusinessProfile', {method:'POST', body:{
  user_id: me.id, entity_name:'Acme Trading (Pty) Ltd', reg_number:'2019/123456/07',
  entity_type:'pty_ltd', province:'Western Cape', industry:'Retail',
  onboarding_complete:true, compliance_score:72, cipc_score:80, sars_score:65,
}}, userTok);
check('create BusinessProfile -> 201 + flattened data', r.status===201 && r.data.entity_name==='Acme Trading (Pty) Ltd' && !!r.data.id);
const profileId = r.data.id;
check('create returns created_date', !!r.data.created_date);

r = await call(`/entities/BusinessProfile?q=${encodeURIComponent(JSON.stringify({user_id:me.id}))}`, {}, userTok);
check('filter({user_id}) -> 1 row (list/filter signature)', r.status===200 && Array.isArray(r.data) && r.data.length===1, JSON.stringify(r.data).slice(0,200));

for (const s of ['pending','pending','verified','needs_action']) {
  await call('/entities/ComplianceDocument', {method:'POST', body:{
    user_id: me.id, business_profile_id: profileId, name:`CIPC AR ${s}`, status:s,
    category:'CIPC', due_date:new Date(Date.now()+10*86400000).toISOString().slice(0,10),
  }}, userTok);
}
r = await call(`/entities/ComplianceDocument?q=${encodeURIComponent(JSON.stringify({business_profile_id:profileId, status:'pending'}))}`, {}, userTok);
check('filter({business_profile_id,status:pending}) -> 2', r.status===200 && r.data.length===2, `got ${r.data.length}`);

r = await call('/entities/ComplianceDocument?sort=-created_date&limit=3', {}, userTok);
check('list("-created_date", 3) honours sort+limit', r.status===200 && r.data.length===3);

r = await call(`/entities/ComplianceDocument?sort=${encodeURIComponent("-name; DROP TABLE users;--")}`, {}, userTok);
const usersAlive = (await db.query('SELECT count(*)::int AS c FROM users')).rows[0].c;
check('SQL injection via sort param is neutralised', r.status===200 && usersAlive>=2, `users=${usersAlive}`);

const docId = (await call(`/entities/ComplianceDocument?q=${encodeURIComponent(JSON.stringify({status:'needs_action'}))}`, {}, userTok)).data[0].id;
r = await call(`/entities/ComplianceDocument/${docId}`, {method:'PUT', body:{status:'verified', note:'reviewed'}}, userTok);
check('update() shallow-merges JSONB', r.status===200 && r.data.status==='verified' && r.data.name?.includes('needs_action') && r.data.note==='reviewed');

console.log('\n── tenant isolation ──');
r = await call('/auth/register', {method:'POST', body:{email:'other@test.co.za', password:'OtherPassw0rd!'}});
const otherTok = r.data.token;
r = await call('/entities/BusinessProfile', {}, otherTok);
check('other user sees 0 BusinessProfiles', r.status===200 && r.data.length===0, `got ${r.data.length}`);
r = await call(`/entities/BusinessProfile/${profileId}`, {}, otherTok);
check('other user cannot GET by id -> 403', r.status===403);
r = await call(`/entities/BusinessProfile/${profileId}`, {method:'PUT', body:{entity_name:'HIJACKED'}}, otherTok);
check('other user cannot PUT -> 403', r.status===403);
r = await call(`/entities/BusinessProfile/${profileId}`, {method:'DELETE'}, otherTok);
check('other user cannot DELETE -> 403', r.status===403);
r = await call('/entities/BusinessProfile', {}, admin);
check('sudo sees all BusinessProfiles', r.status===200 && r.data.length===1);
r = await call('/entities/AuditLog', {method:'POST', body:{action:'forged'}}, userTok);
check('normal user cannot write AuditLog -> 403', r.status===403);

console.log('\n── functions (api.functions.invoke) ──');
r = await call('/functions/doesNotExist', {method:'POST', body:{}}, userTok);
check('unknown function -> 404 + list', r.status===404 && Array.isArray(r.data.available));
r = await call('/functions/checkDeadlineReminders', {method:'POST', body:{profile_id:profileId, days:30}}, userTok);
check('checkDeadlineReminders returns due items', r.status===200 && r.data.status==='ok' && r.data.count>=1, JSON.stringify(r.data).slice(0,180));
check('  each due item has days_remaining', (r.data.due||[]).every(d=>typeof d.days_remaining==='number'));
r = await call('/functions/sageReadBooks', {method:'POST', body:{action:'status'}}, userTok);
check('sageReadBooks -> honest not_configured', r.status===200 && r.data.status==='not_configured' && r.data.connected===false);
r = await call('/functions/sendWhatsAppNotification', {method:'POST', body:{to:'+27820000000', message:'hi'}}, userTok);
check('sendWhatsAppNotification -> skipped (not configured)', r.status===200 && r.data.status==='skipped');
r = await call('/functions/logApprovalAction', {method:'POST', body:{request_id:'x', action:'approved'}}, userTok);
check('logApprovalAction by non-admin -> 403', r.status===403);

const appr = await call('/entities/AdminApprovalRequest', {method:'POST', body:{email:'pending@test.co.za', status:'pending'}}, admin);
r = await call('/functions/logApprovalAction', {method:'POST', body:{request_id:appr.data.id, action:'approved', reason:'ok'}}, admin);
check('logApprovalAction by sudo -> approved', r.status===200 && r.data.request.status==='approved');
const auditRows = (await call('/entities/AuditLog', {}, admin)).data;
check('  audit trail row written', auditRows.some(a=>a.action==='approval_approved'));

console.log('\n── integrations ──');
r = await call('/integrations/llm', {method:'POST', body:{}}, userTok);
check('InvokeLLM without prompt -> 400', r.status===400);
r = await call('/integrations/llm', {method:'POST', body:{prompt:'test'}}, userTok);
check('InvokeLLM without API key -> 503 (clear message)', r.status===503 && /OPENROUTER_API_KEY/.test(r.data.message));
r = await call('/integrations/email', {method:'POST', body:{to:'a@b.c', subject:'s', body:'b'}}, userTok);
check('SendEmail without SMTP -> skipped, not crash', r.status===200 && r.data.status==='skipped');
r = await call('/integrations/files/..%2F..%2Fetc%2Fpasswd', {}, userTok);
check('path traversal on file serve -> blocked', r.status===400 || r.status===404, `status ${r.status}`);

console.log('\n── agents ──');
r = await call('/agents/conversations', {method:'POST', body:{agent_name:'compliance_assistant'}}, userTok);
check('createConversation -> 201', r.status===201 && !!r.data.id);
const convId = r.data.id;
r = await call('/agents/conversations', {}, userTok);
check('listConversations -> 1', r.status===200 && r.data.length===1);
r = await call(`/agents/conversations/${convId}`, {}, otherTok);
check('other user cannot read conversation -> 404', r.status===404);

console.log('\n── users ──');
r = await call('/users/invite', {method:'POST', body:{email:'invitee@test.co.za'}}, userTok);
check('invite by normal user -> 403', r.status===403);
r = await call('/users/invite', {method:'POST', body:{email:'invitee@test.co.za', role:'auditor'}}, admin);
check('invite by sudo -> 201 + temp password returned when SMTP off', r.status===201 && !!r.data.temporary_password);
r = await call('/users', {}, admin);
check('list users -> no password_hash leaked', r.status===200 && r.data.every(u=>!('password_hash' in u)));

console.log(`\n${'─'.repeat(46)}\n  ${pass} passed, ${fail} failed\n${'─'.repeat(46)}`);
process.exit(fail ? 1 : 0);
