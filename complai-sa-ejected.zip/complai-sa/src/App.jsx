import { Toaster } from "@/components/ui/toaster"
import SplashScreen from './components/SplashScreen';
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import CIPCCompliance from './pages/CIPCCompliance';
import SARSCompliance from './pages/SARSCompliance';
import LabourCompliance from './pages/LabourCompliance';
import OHSCompliance from './pages/OHSCompliance';
import POPIACompliance from './pages/POPIACompliance';
import BBBEECompliance from './pages/BBBEECompliance';
import FICACompliance from './pages/FICACompliance';
import MunicipalCompliance from './pages/MunicipalCompliance';
import IndustrySectorCompliance from './pages/IndustrySectorCompliance';
import TaxEngine from './pages/TaxEngine';
import ComplianceVault from './pages/ComplianceVault';
import FilingWorkflows from './pages/FilingWorkflows';
import ComplianceCalendar from './pages/ComplianceCalendar';
import Integrations from './pages/Integrations';
import { RegisterPage, LoginPage } from './pages/AuthPages';
import Onboarding from './pages/Onboarding';
import ComplianceChat from './pages/ComplianceChat';
import IndustryDashboard from './pages/IndustryDashboard';
import AuditReport from './pages/AuditReport';
import WhatsAppReminders from './pages/WhatsAppReminders';
import ComplianceMaturity from './pages/ComplianceMaturity';
import AuditorView from './pages/AuditorView';
import RiskAnalytics from './pages/RiskAnalytics';
import SectorProfile from './pages/SectorProfile';
import FilingAutomation from './pages/FilingAutomation';
import WhiteLabelAdmin from './pages/WhiteLabelAdmin';
import LegalCompliance from './pages/LegalCompliance';
import SudoAdmin from './pages/SudoAdmin';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import AdminRegister from './pages/AdminRegister';
import CodingAgent from './pages/CodingAgent';
import RoleSelection from './components/RoleSelection';
import { DemoProvider, useDemo } from '@/lib/DemoContext';

const AuthenticatedApp = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [selectedRole, setSelectedRole] = useState(() => sessionStorage.getItem('selected_role'));
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const { isDemo, enterDemo } = useDemo();
  const navigate = useNavigate();

  if (showSplash) return <SplashScreen onComplete={() => setShowSplash(false)} />;

  // Demo mode: skip auth checks entirely
  if (!isDemo) {
    if (isLoadingPublicSettings || isLoadingAuth) {
      return (
        <div className="fixed inset-0 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
        </div>
      );
    }

    if (authError) {
      if (authError.type === 'user_not_registered') {
        return <UserNotRegisteredError />;
      } else if (authError.type === 'auth_required') {
        if (!selectedRole) {
          return (
            <RoleSelection
              onSelect={(role) => {
                if (role === 'demo') { enterDemo(); return; }
                sessionStorage.setItem('selected_role', role);
                setSelectedRole(role);
                if (role === 'admin') { navigate('/admin-login'); }
                else { navigateToLogin(); }
              }}
            />
          );
        }
        if (selectedRole === 'admin') { navigate('/admin-login'); }
        else { navigateToLogin(); }
        return null;
      }
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/cipc" element={<CIPCCompliance />} />
        <Route path="/sars" element={<SARSCompliance />} />
        <Route path="/labour" element={<LabourCompliance />} />
        <Route path="/ohs" element={<OHSCompliance />} />
        <Route path="/popia" element={<POPIACompliance />} />
        <Route path="/bbbee" element={<BBBEECompliance />} />
        <Route path="/fica" element={<FICACompliance />} />
        <Route path="/municipal" element={<MunicipalCompliance />} />
        <Route path="/industry" element={<IndustrySectorCompliance />} />
        <Route path="/tax-engine" element={<TaxEngine />} />
        <Route path="/vault" element={<ComplianceVault />} />
        <Route path="/filing" element={<FilingWorkflows />} />
        <Route path="/calendar" element={<ComplianceCalendar />} />
        <Route path="/integrations" element={<Integrations />} />
        <Route path="/chat" element={<ComplianceChat />} />
        <Route path="/industry-dashboard" element={<IndustryDashboard />} />
        <Route path="/audit-report" element={<AuditReport />} />
        <Route path="/whatsapp" element={<WhatsAppReminders />} />
        <Route path="/maturity" element={<ComplianceMaturity />} />
        <Route path="/auditor-view" element={<AuditorView />} />
        <Route path="/risk-analytics" element={<RiskAnalytics />} />
        <Route path="/sector-profile" element={<SectorProfile />} />
        <Route path="/filing-automation" element={<FilingAutomation />} />
        <Route path="/white-label" element={<WhiteLabelAdmin />} />
        <Route path="/legal" element={<LegalCompliance />} />
        <Route path="/sudo-admin" element={<SudoAdmin />} />
      </Route>
      <Route path="/onboarding" element={<Onboarding />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/admin-login" element={<AdminLogin />} />
      <Route path="/admin-register" element={<AdminRegister />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/coding-agent" element={<CodingAgent />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <DemoProvider>
          <Router>
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </DemoProvider>
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App