/**
 * apiClient.js — Compl-Ai SA platform client
 * ---------------------------------------------------------------------------
 * The single integration point between the React app and the self-hosted
 * Express + PostgreSQL API. Every page and component talks to the backend
 * exclusively through this module.
 *
 * Surface:
 *   api.auth.me / login / register / logout / isAuthenticated / redirectToLogin
 *   api.entities.<Name>.list / filter / get / create / update / delete / subscribe
 *   api.functions.invoke(name, payload)
 *   api.integrations.Core.InvokeLLM / SendEmail / UploadFile / ExtractDataFromUploadedFile
 *   api.agents.createConversation / listConversations / addMessage
 *              / subscribeToConversation
 *   api.users.inviteUser / list / updateRole
 *
 * Entities: User, BusinessProfile, ComplianceDocument, AuditLog,
 *           AdminApprovalRequest, SageConnection
 */

const API_BASE =
  (typeof window !== 'undefined' && window.COMPL_AI_CONFIG?.apiUrl) ||
  import.meta.env.VITE_API_URL ||
  '/api';

const TOKEN_KEY = 'complai_token';

/* ── token helpers ───────────────────────────────────────────────────────── */

export const getToken = () => {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(TOKEN_KEY);
};

const setToken = (t) => {
  if (typeof window === 'undefined') return;
  if (t) {
    localStorage.setItem(TOKEN_KEY, t);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
};

/* ── HTTP core ───────────────────────────────────────────────────────────── */

class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.name = 'ApiError';
    this.status = status; // AuthContext branches on error.status — keep it.
    this.data = data;
  }
}

async function request(path, { method = 'GET', body, isForm = false, signal } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (!isForm && body !== undefined) headers['Content-Type'] = 'application/json';

  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
      signal,
    });
  } catch (e) {
    throw new ApiError(`Network error contacting API: ${e.message}`, 0, null);
  }

  if (res.status === 204) return null;

  const text = await res.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }

  if (!res.ok) {
    if (res.status === 401) setToken(null);
    const msg = (data && (data.message || data.error)) || res.statusText || 'Request failed';
    throw new ApiError(msg, res.status, data);
  }
  return data;
}

/* ── auth ────────────────────────────────────────────────────────────────── */

const auth = {
  async me() {
    return request('/auth/me');
  },

  async login(email, password) {
    const r = await request('/auth/login', { method: 'POST', body: { email, password } });
    if (r?.token) setToken(r.token);
    return r;
  },

  async register(payload) {
    const r = await request('/auth/register', { method: 'POST', body: payload });
    if (r?.token) setToken(r.token);
    return r;
  },

  async isAuthenticated() {
    if (!getToken()) return false;
    try {
      await auth.me();
      return true;
    } catch {
      return false;
    }
  },

  logout(redirectTo) {
    setToken(null);
    if (typeof window === 'undefined') return;
    if (redirectTo !== undefined) window.location.href = '/login';
  },

  redirectToLogin(fromUrl) {
    if (typeof window === 'undefined') return;
    const next = fromUrl || window.location.href;
    sessionStorage.setItem('post_login_redirect', next);
    window.location.href = '/login';
  },
};

/* ── realtime (SSE) ──────────────────────────────────────────────────────── */
/**
 * Entity change events arrive over Server-Sent Events: survives the Cloudflare
 * Tunnel with no extra configuration, and reconnects natively.
 *
 * One shared stream is multiplexed to all subscribers.
 */
const realtime = (() => {
  let source = null;
  const listeners = new Map(); // entityName -> Set<fn>

  function ensureStream() {
    if (source || typeof window === 'undefined') return;
    const token = getToken();
    if (!token) return;

    source = new EventSource(`${API_BASE}/events?token=${encodeURIComponent(token)}`);

    source.onmessage = (e) => {
      let evt;
      try {
        evt = JSON.parse(e.data);
      } catch {
        return;
      }
      if (evt?.type === 'ping') return;
      const set = listeners.get(evt.entity);
      if (set) {
        for (const fn of set) {
          try {
            fn(evt);
          } catch (err) {
            console.error(err);
          }
        }
      }
    };

    source.onerror = () => {
      // EventSource reconnects on its own; drop the handle if it closed for good.
      if (source && source.readyState === EventSource.CLOSED) source = null;
    };
  }

  return {
    subscribe(entityName, callback) {
      if (!listeners.has(entityName)) listeners.set(entityName, new Set());
      listeners.get(entityName).add(callback);
      ensureStream();

      // Returns an unsubscribe function.
      return () => {
        const set = listeners.get(entityName);
        if (!set) return;
        set.delete(callback);
        if (set.size === 0) listeners.delete(entityName);
        if (listeners.size === 0 && source) {
          source.close();
          source = null;
        }
      };
    },
  };
})();

/* ── entities ────────────────────────────────────────────────────────────── */
/**
 *   list(sort, limit)           e.g. list('-created_date', 200)
 *   filter(query, sort, limit)  e.g. filter({ user_id: user.id })
 * A leading '-' on sort means descending.
 */
function makeEntity(name) {
  const base = `/entities/${name}`;

  const buildQuery = (query, sort, limit) => {
    const p = new URLSearchParams();
    if (query && Object.keys(query).length) p.set('q', JSON.stringify(query));
    if (sort) p.set('sort', sort);
    if (limit) p.set('limit', String(limit));
    const s = p.toString();
    return s ? `?${s}` : '';
  };

  return {
    name,
    list: (sort, limit) => request(`${base}${buildQuery(null, sort, limit)}`),
    filter: (query, sort, limit) => request(`${base}${buildQuery(query, sort, limit)}`),
    get: (id) => request(`${base}/${id}`),
    create: (data) => request(base, { method: 'POST', body: data }),
    update: (id, data) => request(`${base}/${id}`, { method: 'PUT', body: data }),
    delete: (id) => request(`${base}/${id}`, { method: 'DELETE' }),
    bulkCreate: (rows) => request(`${base}/bulk`, { method: 'POST', body: { rows } }),
    subscribe: (cb) => realtime.subscribe(name, cb),
  };
}

const ENTITY_NAMES = [
  'User',
  'BusinessProfile',
  'ComplianceDocument',
  'AuditLog',
  'AdminApprovalRequest',
  'SageConnection',
];

const entities = ENTITY_NAMES.reduce((acc, n) => {
  acc[n] = makeEntity(n);
  return acc;
}, {});

/* ── backend functions ───────────────────────────────────────────────────── */
/**
 * Server-side jobs, exposed as Express routes at /api/functions/:name:
 *   checkDeadlineReminders, generateAuditorSummary, generateMonthlyReport,
 *   logApprovalAction, onDocumentStatusChange, sageReadBooks,
 *   sendDeadlineEmailReminders, sendWhatsAppNotification
 */
const functions = {
  invoke: (name, payload = {}) => request(`/functions/${name}`, { method: 'POST', body: payload }),
};

/* ── integrations ────────────────────────────────────────────────────────── */

const Core = {
  /**
   * InvokeLLM — routed to the OpenRouter free-model router on the backend.
   * Returns a plain string when no schema is given, or a parsed object when
   * `response_json_schema` is supplied. FilingWorkflows / ComplianceChat /
   * RiskAnalytics depend on that distinction.
   */
  async InvokeLLM({ prompt, response_json_schema, add_context_from_internet, ...rest }) {
    const r = await request('/integrations/llm', {
      method: 'POST',
      body: { prompt, response_json_schema, add_context_from_internet, ...rest },
    });
    return response_json_schema ? r?.data : r?.text ?? '';
  },

  SendEmail: ({ to, subject, body, from_name }) =>
    request('/integrations/email', { method: 'POST', body: { to, subject, body, from_name } }),

  async UploadFile({ file }) {
    const form = new FormData();
    form.append('file', file);
    const r = await request('/integrations/upload', { method: 'POST', body: form, isForm: true });
    return { file_url: r.file_url, file_name: r.file_name, file_size: r.file_size };
  },

  ExtractDataFromUploadedFile: ({ file_url, json_schema }) =>
    request('/integrations/extract', { method: 'POST', body: { file_url, json_schema } }),
};

const integrations = { Core };

/* ── agents (Emma-i conversations) ───────────────────────────────────────── */

const agents = {
  createConversation: ({ agent_name, metadata } = {}) =>
    request('/agents/conversations', { method: 'POST', body: { agent_name, metadata } }),

  listConversations: ({ agent_name } = {}) =>
    request(
      `/agents/conversations${agent_name ? `?agent_name=${encodeURIComponent(agent_name)}` : ''}`
    ),

  getConversation: (id) => request(`/agents/conversations/${id}`),

  addMessage: ({ conversation_id, role = 'user', content }) =>
    request(`/agents/conversations/${conversation_id}/messages`, {
      method: 'POST',
      body: { role, content },
    }),

  /**
   * Streams assistant messages for a conversation. Returns an unsubscribe fn.
   * Used by CompliAssistant / AgentChat.
   */
  subscribeToConversation: (conversationId, callback) => {
    if (typeof window === 'undefined') return () => {};
    const token = getToken();
    const es = new EventSource(
      `${API_BASE}/agents/conversations/${conversationId}/stream?token=${encodeURIComponent(
        token || ''
      )}`
    );
    es.onmessage = (e) => {
      let data;
      try {
        data = JSON.parse(e.data);
      } catch {
        return;
      }
      if (data?.type === 'ping') return;
      try {
        callback(data);
      } catch (err) {
        console.error(err);
      }
    };
    es.onerror = () => {
      if (es.readyState === EventSource.CLOSED) es.close();
    };
    return () => es.close();
  },
};

/* ── users ───────────────────────────────────────────────────────────────── */

const users = {
  inviteUser: ({ email, role = 'user' }) =>
    request('/users/invite', { method: 'POST', body: { email, role } }),
  list: () => request('/users'),
  updateRole: (id, role) => request(`/users/${id}/role`, { method: 'PUT', body: { role } }),
};

/* ── export ──────────────────────────────────────────────────────────────── */

export const api = { auth, entities, functions, integrations, agents, users, request, ApiError };

export default api;
