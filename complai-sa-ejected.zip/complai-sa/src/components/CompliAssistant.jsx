import { useState, useEffect, useRef } from 'react';
import { Sparkles, X, Send, Loader2, Bot, User, RefreshCw, Minimize2, Globe, Shield } from 'lucide-react';
import { api } from '@/api/apiClient';
import ReactMarkdown from 'react-markdown';
import LoadingCheckmark from './LoadingCheckmark';

const AGENT_NAME = 'compliance_reminder';

const suggestedQuestions = [
  "What are my current compliance risks?",
  "When is my next SARS filing due?",
  "What are my POPIA obligations?",
  "How do I register for VAT?",
  "What are my UIF obligations?",
];

function MessageBubble({ message }) {
  const isUser = message.role === 'user';

  if (isUser) {
    return (
      <div className="flex justify-end mb-3">
        <div className="max-w-[85%] flex items-end gap-2">
          <div
            className="px-3 py-2 rounded-2xl rounded-br-sm text-sm leading-relaxed text-white"
            style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #1a3a6e 100%)' }}
          >
            {message.content}
          </div>
          <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
            <User className="w-3 h-3 text-primary" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start mb-3">
      <div className="max-w-[88%] flex items-end gap-2">
        <div
          className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0"
          style={{ background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' }}
        >
          <Sparkles className="w-3 h-3 text-white" />
        </div>
        <div className="flex-1">
          {message.content && (
            <div className="px-3 py-2 rounded-2xl rounded-bl-sm bg-white border border-gray-100 shadow-sm text-sm leading-relaxed text-gray-800 prose prose-sm max-w-none">
              <ReactMarkdown>{message.content}</ReactMarkdown>
            </div>
          )}
          {/* Tool call pills */}
          {message.tool_calls?.filter(tc => !tc.display_projection?.hide_details || !tc.display_projection?.details_redacted).map((tc, i) => (
            <div key={i} className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 bg-primary/5 border border-primary/15 rounded-full text-xs text-primary/70">
              <Loader2 className={`w-2.5 h-2.5 ${['pending','running','in_progress'].includes(tc.status) ? 'animate-spin' : ''}`} />
              {tc.display_projection?.label || tc.name}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function CompliAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [conversation, setConversation] = useState(null);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const unsubRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (open && !conversation) {
      startConversation();
    }
  }, [open]);

  // Cleanup subscription on unmount
  useEffect(() => {
    return () => { if (unsubRef.current) unsubRef.current(); };
  }, []);

  const startConversation = async () => {
    setLoading(true);
    try {
      const convo = await api.agents.createConversation({
        agent_name: AGENT_NAME,
        metadata: { name: 'Compliance Chat', description: 'In-app Compl-i Assistant session' }
      });
      setConversation(convo);

      // Set welcome message
      setMessages([{
        role: 'assistant',
        content: "Hello! I'm **Compl-i Assistant**, your Compl-Ai™ SA compliance expert. I can read your business profile and help with SARS, CIPC, Labour, OHS, POPIA, B-BBEE, and FICA compliance.\n\nWhat can I help you with today?",
      }]);

      // Subscribe to live updates
      unsubRef.current = api.agents.subscribeToConversation(convo.id, (data) => {
        setMessages(data.messages || []);
        setSending(false);
      });
    } catch (e) {
      console.error('Failed to start conversation', e);
      setMessages([{
        role: 'assistant',
        content: "Hi! I'm Compl-i Assistant. I'm having trouble connecting right now — please try again.",
      }]);
    }
    setLoading(false);
  };

  const sendMessage = async () => {
    const text = input.trim();
    if (!text || sending) return;
    setInput('');
    setSending(true);

    // Optimistically add user message
    setMessages(prev => [...prev, { role: 'user', content: text }]);

    try {
      await api.agents.addMessage(conversation, { role: 'user', content: text });
    } catch (e) {
      setSending(false);
    }
  };

  const resetChat = async () => {
    if (unsubRef.current) unsubRef.current();
    setConversation(null);
    setMessages([]);
    setSending(false);
    await startConversation();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const isTyping = sending && messages[messages.length - 1]?.role === 'user';

  return (
    <>
      {/* Floating bubble */}
      <button
        onClick={() => setOpen(o => !o)}
        title="Open Compl-i Assistant Compliance Chat"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform"
        style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #13b5ea 100%)' }}
      >
        {open
          ? <X className="w-6 h-6 text-white" />
          : <Sparkles className="w-6 h-6 text-white" />
        }
        {!open && (
          <span className="absolute top-1 right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white" />
        )}
      </button>

      {/* Chat panel */}
      {open && (
        <div
          className="fixed bottom-24 right-6 z-50 flex flex-col rounded-2xl overflow-hidden"
          style={{
            width: 380,
            height: 560,
            background: '#f8fafc',
            boxShadow: '0 24px 64px rgba(13,42,94,0.22), 0 4px 16px rgba(0,0,0,0.12)',
            border: '1px solid rgba(13,42,94,0.12)',
          }}
        >
          {/* Header */}
          <div
            className="flex items-center gap-3 px-4 py-3 flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #1a3a6e 100%)' }}
          >
            <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.15)' }}>
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-semibold text-sm leading-none">Compl-i Assistant</p>
              <p className="text-white/60 text-xs mt-0.5">Compl-Ai™ SA · SNC-TAX</p>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-white/60 text-xs">Online</span>
            </div>
            <button onClick={resetChat} title="New chat" className="p-1.5 rounded-lg text-white/50 hover:text-white hover:bg-white/10 transition-colors ml-1">
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            <button onClick={() => setOpen(false)} className="p-1.5 rounded-lg text-white/50 hover:text-white hover:bg-white/10 transition-colors">
              <Minimize2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-3 pt-4 pb-2">
            {loading ? (
              <div className="flex items-center justify-center h-full">
                <LoadingCheckmark
                  size="sm"
                  stepDuration={500}
                  title="Connecting to Compl-i Assistant…"
                  steps={[
                    { label: 'Establishing connection…', icon: Loader2 },
                    { label: 'Loading your compliance profile…', icon: Globe },
                    { label: 'AI preparing responses…', icon: Bot },
                    { label: 'Securing your session…', icon: Shield },
                  ]}
                />
              </div>
            ) : (
              <>
                {messages.map((m, i) => <MessageBubble key={i} message={m} />)}

                {/* Suggested questions — show only at start */}
                {messages.length <= 1 && !sending && (
                  <div className="mt-2 space-y-1.5">
                    {suggestedQuestions.map((q, i) => (
                      <button
                        key={i}
                        onClick={() => { setInput(q); setTimeout(() => inputRef.current?.focus(), 50); }}
                        className="w-full text-left text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white hover:border-primary/40 hover:text-primary text-gray-600 transition-colors shadow-sm"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                )}

                {/* Typing indicator */}
                {isTyping && (
                  <div className="flex justify-start mb-3">
                    <div className="flex items-end gap-2">
                      <div
                        className="w-6 h-6 rounded-full flex items-center justify-center"
                        style={{ background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' }}
                      >
                        <Sparkles className="w-3 h-3 text-white" />
                      </div>
                      <div className="px-3 py-2 rounded-2xl rounded-bl-sm bg-white border border-gray-100 shadow-sm">
                        <div className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                          <span className="text-xs text-muted-foreground ml-1">AI thinking…</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          {/* Input */}
          <div className="flex-shrink-0 px-3 pb-3 pt-2 border-t border-gray-100 bg-white">
            <div className="flex gap-2 items-end bg-gray-50 rounded-xl border border-gray-200 px-3 py-2">
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask Compl-i Assistant a compliance question…"
                rows={1}
                style={{ resize: 'none', maxHeight: 80 }}
                className="flex-1 bg-transparent text-sm text-gray-800 placeholder-gray-400 outline-none leading-relaxed"
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim() || sending || loading}
                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-all"
                style={{
                  background: !input.trim() || sending || loading
                    ? '#e2e8f0'
                    : 'linear-gradient(135deg, #0d2a5e, #13b5ea)',
                }}
              >
                {sending
                  ? <Loader2 className="w-3.5 h-3.5 text-gray-400 animate-spin" />
                  : <Send className="w-3.5 h-3.5 text-white" />
                }
              </button>
            </div>
            <p className="text-center text-xs text-gray-400 mt-1.5">Compl-i Assistant · Always verify with a registered professional</p>
          </div>
        </div>
      )}
    </>
  );
}