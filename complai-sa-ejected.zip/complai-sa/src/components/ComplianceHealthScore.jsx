import { Link } from 'react-router-dom';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { Shield, TrendingUp, AlertTriangle, ChevronRight, CheckCircle } from 'lucide-react';

const categories = [
  { label: 'CIPC', score: 90, path: '/cipc', color: '#3b82f6', fix: 'Annual return due May 2026' },
  { label: 'SARS', score: 75, path: '/sars', color: '#22c55e', fix: 'EMP201 overdue — file now' },
  { label: 'Labour', score: 60, path: '/labour', color: '#eab308', fix: 'COIDA return overdue' },
  { label: 'OHS', score: 45, path: '/ohs', color: '#ef4444', fix: 'Risk assessment not uploaded' },
  { label: 'POPIA', score: 80, path: '/popia', color: '#a855f7', fix: 'Privacy policy current' },
  { label: 'B-BBEE', score: 95, path: '/bbbee', color: '#06b6d4', fix: 'Affidavit valid' },
  { label: 'FICA', score: 70, path: '/fica', color: '#f97316', fix: 'KYC review due Nov 2026' },
  { label: 'Municipal', score: 55, path: '/municipal', color: '#ec4899', fix: 'CoA certificate expiring' },
];

const radarData = categories.map(c => ({ subject: c.label, score: c.score, fullMark: 100 }));

const overallScore = Math.round(categories.reduce((acc, c) => acc + c.score, 0) / categories.length);

const scoreColor = overallScore >= 75 ? '#22c55e' : overallScore >= 50 ? '#eab308' : '#ef4444';
const scoreLabel = overallScore >= 75 ? 'Good Standing' : overallScore >= 50 ? 'Needs Attention' : 'At Risk';

function ScoreRing({ score }) {
  const r = 52;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;
  const color = score >= 75 ? '#22c55e' : score >= 50 ? '#eab308' : '#ef4444';
  return (
    <div className="relative w-32 h-32 flex-shrink-0">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
        <circle cx="60" cy="60" r={r} fill="none" stroke="hsl(var(--secondary))" strokeWidth="10" />
        <circle cx="60" cy="60" r={r} fill="none" stroke={color} strokeWidth="10"
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          style={{ transition: 'stroke-dasharray 1s ease' }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold font-grotesk" style={{ color }}>{score}%</span>
        <span className="text-xs text-muted-foreground">{scoreLabel}</span>
      </div>
    </div>
  );
}

export default function ComplianceHealthScore() {
  const criticalItems = categories.filter(c => c.score < 70);

  return (
    <div className="glass-card rounded-xl p-5 border border-primary/10 space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="font-grotesk font-semibold text-foreground flex items-center gap-2">
          <Shield className="w-4 h-4 text-primary" />
          Compliance Health Score
        </h2>
        <Link to="/audit-report" className="text-xs text-primary hover:underline flex items-center gap-1">
          Full Report <ChevronRight className="w-3 h-3" />
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-6">
        {/* Score ring */}
        <ScoreRing score={overallScore} />

        {/* Radar chart */}
        <div className="flex-1 w-full" style={{ height: 180 }}>
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData} margin={{ top: 5, right: 20, bottom: 5, left: 20 }}>
              <PolarGrid stroke="hsl(var(--border))" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
              <Radar dataKey="score" stroke="#13b5ea" fill="#13b5ea" fillOpacity={0.15} strokeWidth={2} />
              <Tooltip
                contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: 12 }}
                formatter={(v) => [`${v}%`, 'Score']}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Category bars */}
      <div className="grid grid-cols-2 gap-2">
        {categories.map(c => (
          <Link key={c.label} to={c.path}
            className="flex items-center gap-2.5 p-2.5 rounded-lg bg-secondary/40 hover:bg-secondary/70 transition-colors group">
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-medium text-foreground">{c.label}</span>
                <span className="text-xs font-bold" style={{ color: c.score >= 75 ? '#22c55e' : c.score >= 50 ? '#eab308' : '#ef4444' }}>{c.score}%</span>
              </div>
              <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${c.score}%`, backgroundColor: c.score >= 75 ? '#22c55e' : c.score >= 50 ? '#eab308' : '#ef4444' }} />
              </div>
            </div>
            <ChevronRight className="w-3 h-3 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
          </Link>
        ))}
      </div>

      {/* Critical fixes */}
      {criticalItems.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-red-400" /> Requires Immediate Action
          </p>
          {criticalItems.map(c => (
            <Link key={c.label} to={c.path}
              className="flex items-center justify-between p-3 rounded-xl border border-red-400/20 bg-red-400/5 hover:bg-red-400/10 transition-colors group">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                <span className="text-xs font-medium text-foreground">{c.label}</span>
                <span className="text-xs text-muted-foreground">— {c.fix}</span>
              </div>
              <span className="text-xs text-primary flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                Fix now <ChevronRight className="w-3 h-3" />
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}