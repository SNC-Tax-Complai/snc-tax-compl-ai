import { useState, useEffect } from 'react';
import { Bell, X, Mail, AlertTriangle, Clock, FileText, CheckCircle, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

function toastIcon(type) {
  if (type === 'overdue') return <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />;
  if (type === 'expiring') return <Clock className="w-4 h-4 text-yellow-400 flex-shrink-0" />;
  return <FileText className="w-4 h-4 text-primary flex-shrink-0" />;
}

export default function ComplianceNotifications() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [toasts, setToasts] = useState([]);
  const [panelOpen, setPanelOpen] = useState(false);
  const [sendingEmail, setSendingEmail] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [emailInput, setEmailInput] = useState('');
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dismissed, setDismissed] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem('dismissed_notifs') || '[]'); } catch { return []; }
  });

  useEffect(() => {
    if (isDemo) { loadDemoAlerts(); return; }
    if (user?.id) loadAlerts();
  }, [user, isDemo]);

  const loadDemoAlerts = () => {
    setLoading(true);
    const profile = demoProfile;
    const realAlerts = [];
    const urgentCount = profile.urgent_alerts || 0;
    for (let i = 0; i < urgentCount; i++) {
      realAlerts.push({ id: `urgent_${i}`, type: 'overdue', title: `Urgent Compliance Alert #${i + 1}`, detail: 'Action required — see dashboard recommendations', category: 'AI Analysis', path: '/' });
    }
    let deadlines = [];
    try { deadlines = JSON.parse(profile.upcoming_deadlines || '[]'); } catch {}
    deadlines.forEach((d, i) => {
      realAlerts.push({ id: `deadline_${i}`, type: d.urgent ? 'overdue' : 'upcoming', title: d.urgent ? `Urgent: ${d.label || d.type}` : `Upcoming: ${d.label || d.type}`, detail: `Due: ${d.date || 'Date not specified'}`, category: d.type || 'Filing', path: '/calendar' });
    });
    const pendingCount = profile.pending_filings || 0;
    if (pendingCount > 0) {
      realAlerts.push({ id: 'pending_filings', type: 'upcoming', title: `${pendingCount} Pending Filing(s)`, detail: 'Filings due this period — see Filing Workflows', category: 'Filings', path: '/filing' });
    }
    if (demoDocuments.some(d => d.status === 'pending')) {
      realAlerts.push({ id: 'pending_docs', type: 'upcoming', title: 'Document(s) Pending Analysis', detail: 'Documents uploaded but not yet analysed', category: 'Vault', path: '/vault' });
    }
    const needsActionDemos = demoDocuments.filter(d => d.status === 'needs_action');
    needsActionDemos.forEach((doc, i) => {
      realAlerts.push({ id: `needs_action_${doc.id || i}`, type: 'overdue', title: `Document Needs Action: ${doc.document_name || 'Untitled'}`, detail: 'Compl-i Assistant flagged this document as incomplete, expired, or discrepant', category: doc.document_type || 'Vault', path: '/vault' });
    });
    const verifiedDemos = demoDocuments.filter(d => d.status === 'verified');
    if (verifiedDemos.length > 0) {
      realAlerts.push({ id: 'verified_docs', type: 'upcoming', title: `${verifiedDemos.length} Document(s) Verified ✓`, detail: 'Compl-i Assistant verified these documents as complete and valid', category: 'Vault', path: '/vault' });
    }
    if (profile.compliance_score != null && profile.compliance_score < 50) {
      realAlerts.push({ id: 'low_score', type: 'overdue', title: 'Low Compliance Score', detail: `Current score: ${profile.compliance_score}% — immediate action recommended`, category: 'Risk', path: '/risk-analytics' });
    }
    setAlerts(realAlerts);
    setLoading(false);
  };

  const loadAlerts = async () => {
    setLoading(true);
    try {
      const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
      if (profiles.length === 0) { setLoading(false); return; }
      const profile = profiles[0];

      // Build alerts from real profile data
      const realAlerts = [];

      // Urgent alerts count
      const urgentCount = profile.urgent_alerts || 0;
      for (let i = 0; i < urgentCount; i++) {
        realAlerts.push({
          id: `urgent_${i}`,
          type: 'overdue',
          title: `Urgent Compliance Alert #${i + 1}`,
          detail: 'Action required — see dashboard recommendations',
          category: 'AI Analysis',
          path: '/',
        });
      }

      // Upcoming deadlines from AI analysis
      let deadlines = [];
      try { deadlines = JSON.parse(profile.upcoming_deadlines || '[]'); } catch {}
      deadlines.forEach((d, i) => {
        realAlerts.push({
          id: `deadline_${i}`,
          type: d.urgent ? 'overdue' : 'upcoming',
          title: d.urgent ? `Urgent: ${d.label || d.type}` : `Upcoming: ${d.label || d.type}`,
          detail: `Due: ${d.date || 'Date not specified'}`,
          category: d.type || 'Filing',
          path: '/calendar',
        });
      });

      // Pending filings
      const pendingCount = profile.pending_filings || 0;
      if (pendingCount > 0) {
        realAlerts.push({
          id: 'pending_filings',
          type: 'upcoming',
          title: `${pendingCount} Pending Filing(s)`,
          detail: 'Filings due this period — see Filing Workflows',
          category: 'Filings',
          path: '/filing',
        });
      }

      // Documents pending analysis
      try {
        const docs = await api.entities.ComplianceDocument.filter({ business_profile_id: profile.id, status: 'pending' });
        if (docs.length > 0) {
          realAlerts.push({
            id: 'pending_docs',
            type: 'upcoming',
            title: `${docs.length} Document(s) Pending Analysis`,
            detail: 'Documents uploaded but not yet analysed by Compl-i Assistant',
            category: 'Vault',
            path: '/vault',
          });
        }
      } catch {}

      // Documents needing action (flagged by Compl-i Assistant)
      try {
        const needsActionDocs = await api.entities.ComplianceDocument.filter({ business_profile_id: profile.id, status: 'needs_action' });
        needsActionDocs.forEach((doc, i) => {
          realAlerts.push({
            id: `needs_action_${doc.id || i}`,
            type: 'overdue',
            title: `Document Needs Action: ${doc.document_name || 'Untitled'}`,
            detail: 'Compl-i Assistant flagged this document as incomplete, expired, or discrepant',
            category: doc.document_type || 'Vault',
            path: '/vault',
          });
        });
      } catch {}

      // Verified documents
      try {
        const verifiedDocs = await api.entities.ComplianceDocument.filter({ business_profile_id: profile.id, status: 'verified' });
        if (verifiedDocs.length > 0) {
          realAlerts.push({
            id: 'verified_docs',
            type: 'upcoming',
            title: `${verifiedDocs.length} Document(s) Verified ✓`,
            detail: 'Compl-i Assistant verified these documents as complete and valid',
            category: 'Vault',
            path: '/vault',
          });
        }
      } catch {}

      // Low compliance score alert
      if (profile.compliance_score != null && profile.compliance_score < 50) {
        realAlerts.push({
          id: 'low_score',
          type: 'overdue',
          title: 'Low Compliance Score',
          detail: `Current score: ${profile.compliance_score}% — immediate action recommended`,
          category: 'Risk',
          path: '/risk-analytics',
        });
      }

      setAlerts(realAlerts);
    } catch (e) {
      console.error('Failed to load notifications', e);
    }
    setLoading(false);
  };

  const activeAlerts = alerts.filter(a => !dismissed.includes(a.id));
  const urgentCount = activeAlerts.filter(a => a.type === 'overdue').length;

  const dismiss = (id) => {
    const updated = [...dismissed, id];
    setDismissed(updated);
    sessionStorage.setItem('dismissed_notifs', JSON.stringify(updated));
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  useEffect(() => {
    const urgent = activeAlerts.filter(a => a.type === 'overdue').slice(0, 3);
    setToasts(urgent);
    urgent.forEach(t => {
      setTimeout(() => setToasts(prev => prev.filter(x => x.id !== t.id)), 8000);
    });
  }, [loading]);

  const sendEmailSummary = async () => {
    if (!emailInput || sendingEmail) return;
    setSendingEmail(true);
    const list = activeAlerts.map(a => `• [${a.category}] ${a.title} — ${a.detail}`).join('\n') || 'No active alerts.';
    await api.integrations.Core.SendEmail({
      to: emailInput,
      subject: `⚠️ Compl-Ai™ SA — ${urgentCount} Urgent Item(s) + Compliance Notification Summary`,
      body: `Dear Compl-Ai™ SA User,

Your personalised compliance notification summary as at ${new Date().toLocaleDateString('en-ZA')}:

${list}

━━━━━━━━━━━━━━━━━━━━━━━━
Log in to resolve: ${window.location.origin}
━━━━━━━━━━━━━━━━━━━━━━━━

Powered by Compl-Ai™ SA · Compl-i Assistant · SA-iLabs®™
This is an automated notification. Always verify with a registered professional.`,
    });
    setSendingEmail(false);
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 4000);
  };

  return (
    <>
      {/* Floating toasts */}
      <div className="fixed top-20 left-4 right-4 sm:left-auto sm:right-4 z-50 space-y-2 sm:max-w-sm w-auto sm:w-full pointer-events-none">
        {toasts.map(t => (
          <div key={t.id} className="pointer-events-auto glass-card rounded-xl border border-red-400/30 bg-white shadow-lg p-3 flex items-start gap-3 animate-slide-up">
            {toastIcon(t.type)}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-foreground truncate">{t.title}</p>
              <p className="text-xs text-muted-foreground">{t.detail}</p>
            </div>
            <button onClick={() => dismiss(t.id)} className="text-muted-foreground hover:text-foreground flex-shrink-0">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Notification bell button */}
      <div className="relative">
        <button onClick={() => setPanelOpen(!panelOpen)}
          className="relative flex items-center gap-2 px-3 py-2 glass-card rounded-xl border border-border hover:border-primary/30 text-sm text-muted-foreground hover:text-foreground transition-all">
          <Bell className="w-4 h-4 text-primary" />
          <span className="hidden sm:inline text-xs">Notifications</span>
          {activeAlerts.length > 0 && (
            <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-400 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
              {activeAlerts.length}
            </span>
          )}
        </button>

        {panelOpen && (
          <div className="fixed inset-0 z-[60] flex items-start justify-center sm:justify-end p-4 sm:pt-20 sm:pr-6 bg-black/40" onClick={() => setPanelOpen(false)}>
          <div className="w-full max-w-sm bg-white rounded-2xl border border-primary/20 shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-primary" />
                <h3 className="font-grotesk font-semibold text-foreground text-sm">Compliance Alerts</h3>
              </div>
              <button onClick={() => setPanelOpen(false)}><X className="w-4 h-4 text-muted-foreground" /></button>
            </div>

            <div className="max-h-72 overflow-y-auto divide-y divide-border">
              {loading ? (
                <div className="p-6 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-primary animate-spin" />
                </div>
              ) : activeAlerts.length === 0 ? (
                <div className="p-6 text-center">
                  <CheckCircle className="w-6 h-6 text-green-400 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">All compliance items are up to date.</p>
                </div>
              ) : activeAlerts.map(a => (
                <Link key={a.id} to={a.path}
                  className="flex items-start gap-3 p-3 hover:bg-secondary/40 transition-colors">
                  {toastIcon(a.type)}
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-foreground">{a.title}</p>
                    <p className="text-xs text-muted-foreground">{a.detail} · {a.category}</p>
                  </div>
                  <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); dismiss(a.id); }}
                    className="text-muted-foreground hover:text-foreground flex-shrink-0 mt-0.5">
                    <X className="w-3 h-3" />
                  </button>
                </Link>
              ))}
            </div>

            {/* Email summary */}
            <div className="p-3 border-t border-border space-y-2">
              <p className="text-xs text-muted-foreground font-medium">Email summary to:</p>
              <div className="flex gap-2">
                <input value={emailInput} onChange={e => setEmailInput(e.target.value)}
                  placeholder="your@email.com" type="email"
                  className="flex-1 bg-secondary rounded-lg px-3 py-1.5 text-xs text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
                <button onClick={sendEmailSummary} disabled={sendingEmail || !emailInput || emailSent}
                  className="px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-medium disabled:opacity-50 flex items-center gap-1.5 whitespace-nowrap">
                  {sendingEmail ? <Loader2 className="w-3 h-3 animate-spin" /> : emailSent ? <CheckCircle className="w-3 h-3" /> : <Mail className="w-3 h-3" />}
                  {emailSent ? 'Sent!' : 'Send'}
                </button>
              </div>
            </div>
          </div>
          </div>
        )}
      </div>
    </>
  );
}