import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Cell, LabelList
} from 'recharts';

const SCORE_TIERS = [
  { threshold: 80, color: '#3cb54a', label: 'Healthy' },
  { threshold: 60, color: '#f59e0b', label: 'Needs Work' },
  { threshold: 0, color: '#ef4444', label: 'At Risk' },
];

function getTier(score) {
  return SCORE_TIERS.find(t => score >= t.threshold) || SCORE_TIERS[SCORE_TIERS.length - 1];
}

function CustomTooltip({ active, payload }) {
  if (!active || !payload?.length) return null;
  const { label, score } = payload[0].payload;
  const tier = getTier(score);
  return (
    <div className="bg-white rounded-lg shadow-lg border border-slate-200 p-3 text-xs">
      <p className="font-semibold text-foreground">{label}</p>
      <p className="text-muted-foreground mt-0.5">Score: <span className="font-bold" style={{ color: tier.color }}>{score}%</span></p>
      <p className="text-muted-foreground">Status: <span style={{ color: tier.color }}>{tier.label}</span></p>
    </div>
  );
}

export default function ComplianceProgressChart({ modules }) {
  const data = modules.map(m => ({ label: m.label, score: m.score, color: m.color }));
  const avg = modules.length
    ? Math.round(modules.reduce((a, m) => a + (m.score || 0), 0) / modules.length)
    : 0;
  const healthy = modules.filter(m => (m.score || 0) >= 80).length;
  const atRisk = modules.filter(m => (m.score || 0) < 60).length;

  return (
    <div className="bg-white rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.07)' }}>
      <div className="h-1" style={{ background: 'linear-gradient(90deg, #0d2a5e, #3cb54a, #13b5ea)' }} />
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div>
            <h2 className="font-grotesk font-semibold text-foreground text-sm">Compliance Health by Module</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Visual breakdown of your scores across all regulatory areas</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold font-grotesk text-primary">{avg}%</p>
              <p className="text-xs text-muted-foreground">Average</p>
            </div>
            <div className="h-8 w-px bg-border" />
            <div className="text-center">
              <p className="text-2xl font-bold font-grotesk text-green-500">{healthy}</p>
              <p className="text-xs text-muted-foreground">Healthy</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold font-grotesk text-red-500">{atRisk}</p>
              <p className="text-xs text-muted-foreground">At Risk</p>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 mb-4 flex-wrap">
          {SCORE_TIERS.map(t => (
            <div key={t.label} className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full" style={{ background: t.color }} />
              <span className="text-xs text-muted-foreground">{t.label} ({t.threshold === 0 ? `<60%` : t.threshold === 60 ? `60–79%` : `80%+`})</span>
            </div>
          ))}
        </div>

        {/* Chart */}
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} margin={{ top: 20, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={{ stroke: '#e2e8f0' }} tickLine={false} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} unit="%" />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(13,42,94,0.04)' }} />
            <Bar dataKey="score" radius={[6, 6, 0, 0]} maxBarSize={60}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={getTier(entry.score).color} />
              ))}
              <LabelList dataKey="score" position="top" formatter={(v) => `${v}%`} style={{ fontSize: 11, fontWeight: 600, fill: '#475569' }} />
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        {/* Module list below chart */}
        <div className="grid grid-cols-2 md:grid-cols-7 gap-3 mt-4 pt-4 border-t border-border">
          {modules.map(m => {
            const tier = getTier(m.score || 0);
            return (
              <div key={m.label} className="flex flex-col items-center gap-1">
                <div className="w-2 h-2 rounded-full" style={{ background: tier.color }} />
                <span className="text-xs font-medium text-foreground">{m.score || 0}%</span>
                <span className="text-xs text-muted-foreground">{m.label}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}