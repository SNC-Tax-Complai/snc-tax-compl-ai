import GaugeChart from './GaugeChart';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

const MODULE_GAUGES = [
  { label: 'CIPC', value: 90, color: '#3b82f6', path: '/cipc' },
  { label: 'SARS', value: 75, color: '#22c55e', path: '/sars' },
  { label: 'Labour', value: 60, color: '#eab308', path: '/labour' },
  { label: 'OHS', value: 45, color: '#ef4444', path: '/ohs' },
  { label: 'POPIA', value: 80, color: '#a855f7', path: '/popia' },
  { label: 'B-BBEE', value: 95, color: '#06b6d4', path: '/bbbee' },
];

export default function ComplianceScoreGauge() {
  const overall = Math.round(MODULE_GAUGES.reduce((a, m) => a + m.value, 0) / MODULE_GAUGES.length);

  return (
    <div className="glass-card rounded-xl p-5 border border-primary/10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-grotesk font-semibold text-foreground text-sm">Compliance Health — By Module</h2>
        <span className="text-xs font-bold text-primary">{overall}% Overall</span>
      </div>
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {MODULE_GAUGES.map((m, i) => (
          <Link key={i} to={m.path} className="flex flex-col items-center hover:opacity-80 transition-opacity">
            <GaugeChart value={m.value} color={m.color} size={90} />
            <span className="text-xs text-muted-foreground font-medium mt-0.5">{m.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}