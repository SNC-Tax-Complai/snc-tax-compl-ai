import { useState } from 'react';
import { ChevronDown, ChevronUp, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

const statusIcon = { done: CheckCircle, pending: Clock, urgent: AlertTriangle };
const statusColor = { done: 'text-green-400', pending: 'text-yellow-400', urgent: 'text-red-400' };

export function ChecklistItem({ label, status = 'pending', detail }) {
  const Icon = statusIcon[status];
  return (
    <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
      <Icon className={`w-4 h-4 mt-0.5 flex-shrink-0 ${statusColor[status]}`} />
      <div>
        <p className="text-sm text-foreground">{label}</p>
        {detail && <p className="text-xs text-muted-foreground mt-0.5">{detail}</p>}
      </div>
    </div>
  );
}

export function ExpandableSection({ title, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="glass-card rounded-xl border border-primary/10 overflow-hidden mb-4">
      <button onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-4 text-left hover:bg-primary/5 transition-colors">
        <span className="font-semibold text-foreground">{title}</span>
        {open ? <ChevronUp className="w-4 h-4 text-primary" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>
      {open && <div className="px-4 pb-4 space-y-2">{children}</div>}
    </div>
  );
}

export function DeadlineBadge({ label, date, urgent }) {
  return (
    <div className={`flex items-center justify-between p-3 rounded-lg border ${urgent ? 'border-red-400/30 bg-red-400/5' : 'border-primary/20 bg-primary/5'}`}>
      <span className="text-sm text-foreground">{label}</span>
      <span className={`text-xs font-medium px-2 py-1 rounded-full ${urgent ? 'bg-red-400/20 text-red-400' : 'bg-primary/20 text-primary'}`}>{date}</span>
    </div>
  );
}

export function PageHero({ title, subtitle, badge }) {
  return (
    <div className="relative overflow-hidden rounded-2xl mb-8 p-8 glass-card neon-glow">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
      {badge && (
        <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">
          {badge}
        </span>
      )}
      <h1 className="text-3xl md:text-4xl font-bold font-grotesk text-foreground mb-2">{title}</h1>
      <p className="text-muted-foreground max-w-2xl">{subtitle}</p>
    </div>
  );
}