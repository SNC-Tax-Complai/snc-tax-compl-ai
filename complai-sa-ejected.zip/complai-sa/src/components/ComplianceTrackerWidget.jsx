import { useState } from 'react';
import { AlertTriangle, Clock, CheckCircle, X, Bot, Loader2, Send, ChevronRight, Zap } from 'lucide-react';
import { api } from '@/api/apiClient';

// Safely renders **bold** + newline formatted text as React nodes — no raw HTML injection.
function FormattedText({ text }) {
  if (!text) return null;
  const lines = String(text).split('\n');
  return (
    <>
      {lines.map((line, li) => (
        <span key={li}>
          {line.split(/(\*\*[^*]+\*\*)/g).map((part, pi) =>
            part.startsWith('**') && part.endsWith('**')
              ? <strong key={pi}>{part.slice(2, -2)}</strong>
              : <span key={pi}>{part}</span>
          )}
          {li < lines.length - 1 && <br />}
        </span>
      ))}
    </>
  );
}

const filings = [
  { id: 1, name: 'EMP201 — PAYE/SDL/UIF', category: 'SARS', due: '2026-04-07', status: 'overdue' },
  { id: 2, name: 'VAT201 Bi-Monthly Return', category: 'SARS', due: '2026-04-25', status: 'upcoming' },
  { id: 3, name: 'IRP6 — 2nd Provisional Tax', category: 'SARS', due: '2027-02-28', status: 'pending' },
  { id: 4, name: 'EMP501 Annual Reconciliation', category: 'SARS', due: '2026-05-31', status: 'upcoming' },
  { id: 5, name: 'CIPC Annual Return', category: 'CIPC', due: '2026-05-15', status: 'upcoming' },
  { id: 6, name: 'COIDA Return of Earnings (W.As.8)', category: 'COIDA', due: '2026-03-31', status: 'overdue' },
  { id: 7, name: 'B-BBEE Affidavit Renewal', category: 'B-BBEE', due: '2026-06-30', status: 'pending' },
  { id: 8, name: 'ITR14 Company Income Tax', category: 'SARS', due: '2026-12-31', status: 'pending' },
];

const statusConfig = {
  overdue: {
    label: 'Overdue',
    color: 'text-red-400',
    bg: 'bg-red-400/10',
    border: 'border-red-400/30',
    dot: 'bg-red-400',
    icon: AlertTriangle,
    ring: 'ring-red-400/30',
  },
  upcoming: {
    label: 'Upcoming',
    color: 'text-yellow-400',
    bg: 'bg-yellow-400/10',
    border: 'border-yellow-400/30',
    dot: 'bg-yellow-400',
    icon: Clock,
    ring: 'ring-yellow-400/30',
  },
  pending: {
    label: 'Pending',
    color: 'text-blue-400',
    bg: 'bg-blue-400/10',
    border: 'border-blue-400/30',
    dot: 'bg-blue-400',
    icon: Clock,
    ring: 'ring-blue-400/30',
  },
  resolved: {
    label: 'Resolved',
    color: 'text-green-400',
    bg: 'bg-green-400/10',
    border: 'border-green-400/30',
    dot: 'bg-green-400',
    icon: CheckCircle,
    ring: 'ring-green-400/30',
  },
};

const categoryColor = {
  SARS: 'text-green-400 bg-green-400/10',
  CIPC: 'text-blue-400 bg-blue-400/10',
  COIDA: 'text-orange-400 bg-orange-400/10',
  'B-BBEE': 'text-purple-400 bg-purple-400/10',
};

function getDaysUntil(dateStr) {
  const now = new Date('2026-04-05');
  const due = new Date(dateStr);
  return Math.ceil((due - now) / (1000 * 60 * 60 * 24));
}

function ResolveModal({ filing, onClose, onResolved }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [input, setInput] = useState('');
  const [started, setStarted] = useState(false);

  const start = async () => {
    setStarted(true);
    setLoading(true);
    const result = await api.integrations.Core.InvokeLLM({
      prompt: `You are Emma-i™, a South African compliance expert. The user needs to resolve: "${filing.name}" (Category: ${filing.category}, Due: ${filing.due}).

Provide a structured response with:
1. A brief explanation of what this filing is and WHY it's important (cite the relevant Act and section)
2. Exactly 4-5 step-by-step actions to complete this filing immediately
3. What penalties apply for non-compliance (cite specific penalty sections)
4. Portal or contact details where to submit

Keep it concise, practical, and South African law-specific. Use markdown formatting with **bold** for key points.`,
      response_json_schema: {
        type: 'object',
        properties: {
          answer: { type: 'string' },
          steps: { type: 'array', items: { type: 'string' } },
          penalties: { type: 'string' },
          portal: { type: 'string' },
        }
      }
    });

    setMessages([{ role: 'assistant', data: result }]);
    setLoading(false);
  };

  const sendFollowUp = async () => {
    const msg = input.trim();
    if (!msg || loading) return;
    setInput('');
    const userMsg = { role: 'user', content: msg };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    const result = await api.integrations.Core.InvokeLLM({
      prompt: `You are Emma-i™. The user is resolving "${filing.name}" (${filing.category}). They ask: "${msg}". Answer concisely with South African compliance specifics. Use markdown.`,
    });

    setMessages(prev => [...prev, { role: 'assistant', content: result }]);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-lg glass-card rounded-2xl border border-primary/20 neon-glow flex flex-col max-h-[85vh] animate-slide-up">
        {/* Header */}
        <div className="flex items-start justify-between p-5 border-b border-primary/20 flex-shrink-0">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="font-grotesk font-semibold text-foreground text-sm">Emma-i™ Resolve Assistant</p>
              <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{filing.name}</p>
              <span className={`inline-block mt-1 text-xs px-2 py-0.5 rounded-full ${categoryColor[filing.category] || 'bg-secondary text-muted-foreground'}`}>{filing.category}</span>
            </div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1"><X className="w-4 h-4" /></button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {!started ? (
            <div className="text-center py-6 space-y-4">
              <div className={`w-14 h-14 rounded-2xl mx-auto flex items-center justify-center ${statusConfig[filing.status]?.bg} border ${statusConfig[filing.status]?.border}`}>
                {(() => { const Icon = statusConfig[filing.status]?.icon || AlertTriangle; return <Icon className={`w-6 h-6 ${statusConfig[filing.status]?.color}`} />; })()}
              </div>
              <div>
                <p className="text-foreground font-semibold">{filing.name}</p>
                <p className={`text-sm mt-1 ${statusConfig[filing.status]?.color}`}>
                  {filing.status === 'overdue' ? `Overdue by ${Math.abs(getDaysUntil(filing.due))} days` : `Due in ${getDaysUntil(filing.due)} days · ${filing.due}`}
                </p>
              </div>
              <p className="text-sm text-muted-foreground">Emma-i™ will guide you through resolving this filing with step-by-step instructions and relevant SA legislation.</p>
              <button onClick={start}
                className="mx-auto flex items-center gap-2 px-6 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium text-sm neon-glow hover:bg-primary/90 transition-colors">
                <Zap className="w-4 h-4" /> Get Resolution Steps
              </button>
            </div>
          ) : loading && messages.length === 0 ? (
            <div className="flex items-center gap-3 py-4">
              <Loader2 className="w-4 h-4 text-primary animate-spin" />
              <span className="text-sm text-muted-foreground">Emma-i™ is researching compliance requirements...</span>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((m, i) => (
                <div key={i}>
                  {m.role === 'user' ? (
                    <div className="flex justify-end">
                      <div className="max-w-[80%] bg-primary text-primary-foreground rounded-xl px-3 py-2 text-sm">{m.content}</div>
                    </div>
                  ) : m.data ? (
                    <div className="space-y-3">
                      {/* Main answer */}
                      <div className="glass-card rounded-xl p-4 border border-primary/10 text-sm text-foreground leading-relaxed">
                        <div className="prose prose-sm prose-invert max-w-none"><FormattedText text={m.data.answer} /></div>
                      </div>
                      {/* Steps */}
                      {m.data.steps?.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-xs text-muted-foreground font-medium">ACTION STEPS</p>
                          {m.data.steps.map((s, si) => (
                            <div key={si} className="flex items-start gap-2.5 p-2.5 bg-green-400/5 border border-green-400/20 rounded-lg">
                              <div className="w-5 h-5 rounded-full bg-green-400/20 text-green-400 text-xs flex items-center justify-center font-bold flex-shrink-0">{si + 1}</div>
                              <p className="text-xs text-foreground">{s}</p>
                            </div>
                          ))}
                        </div>
                      )}
                      {/* Penalties */}
                      {m.data.penalties && (
                        <div className="flex items-start gap-2 p-3 bg-red-400/5 border border-red-400/20 rounded-lg">
                          <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                          <p className="text-xs text-foreground">{m.data.penalties}</p>
                        </div>
                      )}
                      {/* Portal */}
                      {m.data.portal && (
                        <div className="flex items-start gap-2 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                          <ChevronRight className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                          <p className="text-xs text-foreground">{m.data.portal}</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="glass-card rounded-xl p-3 border border-primary/10 text-sm text-foreground"><FormattedText text={m.content} /></div>
                  )}
                </div>
              ))}
              {loading && (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 text-primary animate-spin" />
                  <span className="text-xs text-muted-foreground">Emma-i™ is responding...</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-primary/20 flex-shrink-0 space-y-3">
          {started && messages.length > 0 && (
            <div className="flex gap-2">
              <input value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendFollowUp()}
                placeholder="Ask a follow-up question..."
                className="flex-1 bg-secondary rounded-lg px-3 py-2 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
              <button onClick={sendFollowUp} disabled={loading || !input.trim()}
                className="px-3 py-2 bg-primary text-primary-foreground rounded-lg disabled:opacity-50 hover:bg-primary/90 transition-colors">
                <Send className="w-4 h-4" />
              </button>
            </div>
          )}
          <div className="flex gap-2">
            <button onClick={onClose} className="flex-1 py-2 text-sm border border-border text-muted-foreground rounded-lg hover:bg-secondary transition-colors">Close</button>
            <button onClick={() => { onResolved(filing.id); onClose(); }}
              className="flex-1 py-2 text-sm bg-green-400/10 border border-green-400/30 text-green-400 rounded-lg hover:bg-green-400/20 transition-colors font-medium">
              ✓ Mark as Resolved
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ComplianceTrackerWidget() {
  const [statuses, setStatuses] = useState(() => Object.fromEntries(filings.map(f => [f.id, f.status])));
  const [activeModal, setActiveModal] = useState(null);
  const [filter, setFilter] = useState('all');

  const handleResolved = (id) => setStatuses(prev => ({ ...prev, [id]: 'resolved' }));

  const counts = {
    overdue: filings.filter(f => statuses[f.id] === 'overdue').length,
    upcoming: filings.filter(f => statuses[f.id] === 'upcoming').length,
    pending: filings.filter(f => statuses[f.id] === 'pending').length,
    resolved: filings.filter(f => statuses[f.id] === 'resolved').length,
  };

  const displayed = filings.filter(f => filter === 'all' || statuses[f.id] === filter);

  return (
    <>
      {activeModal && (
        <ResolveModal
          filing={{ ...filings.find(f => f.id === activeModal), status: statuses[activeModal] }}
          onClose={() => setActiveModal(null)}
          onResolved={handleResolved}
        />
      )}

      <div className="glass-card rounded-xl p-5 border border-primary/10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-grotesk font-semibold text-foreground flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            Statutory Filing Tracker
          </h2>
          <span className="text-xs text-muted-foreground">{counts.resolved}/{filings.length} resolved</span>
        </div>

        {/* Status filter pills */}
        <div className="flex gap-2 mb-4 flex-wrap">
          {[
            { key: 'all', label: 'All', count: filings.length, color: 'text-foreground' },
            { key: 'overdue', label: 'Overdue', count: counts.overdue, color: 'text-red-400' },
            { key: 'upcoming', label: 'Upcoming', count: counts.upcoming, color: 'text-yellow-400' },
            { key: 'pending', label: 'Pending', count: counts.pending, color: 'text-blue-400' },
            { key: 'resolved', label: 'Resolved', count: counts.resolved, color: 'text-green-400' },
          ].map(tab => (
            <button key={tab.key} onClick={() => setFilter(tab.key)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium transition-all ${filter === tab.key ? 'bg-secondary border border-primary/30 text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              <span className={tab.color}>{tab.count}</span> {tab.label}
            </button>
          ))}
        </div>

        {/* Filing rows */}
        <div className="space-y-2">
          {displayed.map(filing => {
            const status = statuses[filing.id];
            const cfg = statusConfig[status];
            const Icon = cfg.icon;
            const days = getDaysUntil(filing.due);
            const isActionable = status !== 'resolved';

            return (
              <button key={filing.id} onClick={() => isActionable && setActiveModal(filing.id)}
                disabled={!isActionable}
                className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all text-left group ${cfg.border} ${cfg.bg} ${isActionable ? `hover:ring-2 ${cfg.ring} cursor-pointer` : 'opacity-60 cursor-default'}`}>
                {/* Status dot */}
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${cfg.dot} ${status === 'overdue' ? 'animate-pulse' : ''}`} />

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{filing.name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`text-xs px-1.5 py-0.5 rounded ${categoryColor[filing.category] || 'bg-secondary text-muted-foreground'}`}>{filing.category}</span>
                    <span className="text-xs text-muted-foreground">
                      {status === 'resolved' ? 'Resolved' : status === 'overdue' ? `${Math.abs(days)}d overdue` : `Due in ${days}d · ${filing.due}`}
                    </span>
                  </div>
                </div>

                {/* Status badge */}
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <span className={`flex items-center gap-1 text-xs font-medium ${cfg.color}`}>
                    <Icon className="w-3 h-3" /> {cfg.label}
                  </span>
                  {isActionable && <ChevronRight className="w-3 h-3 text-muted-foreground group-hover:text-primary transition-colors" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Progress bar */}
        <div className="mt-4 space-y-1.5">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Overall compliance progress</span>
            <span>{Math.round((counts.resolved / filings.length) * 100)}%</span>
          </div>
          <div className="h-1.5 bg-secondary rounded-full overflow-hidden flex">
            <div className="bg-green-400 transition-all duration-500" style={{ width: `${(counts.resolved / filings.length) * 100}%` }} />
            <div className="bg-yellow-400/70 transition-all duration-500" style={{ width: `${(counts.upcoming / filings.length) * 100}%` }} />
            <div className="bg-red-400/70 transition-all duration-500" style={{ width: `${(counts.overdue / filings.length) * 100}%` }} />
          </div>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-400 inline-block" />Resolved</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-400 inline-block" />Upcoming</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-400 inline-block" />Overdue</span>
          </div>
        </div>
      </div>
    </>
  );
}