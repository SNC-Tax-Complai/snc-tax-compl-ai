import { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar, AlertTriangle, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

// SA statutory deadlines (always present regardless of AI data)
const STATUTORY_DEADLINES = [
  // SARS
  { label: 'VAT201 Monthly Return', type: 'SARS', day: 25, monthly: true, color: '#3cb54a', urgent: false },
  { label: 'EMP201 PAYE / UIF / SDL', type: 'SARS', day: 7, monthly: true, color: '#3cb54a', urgent: false },
  { label: 'IRP6 Provisional Tax (1st)', type: 'SARS', month: 8, day: 31, color: '#3cb54a', urgent: false },
  { label: 'IRP6 Provisional Tax (2nd)', type: 'SARS', month: 2, day: 28, color: '#3cb54a', urgent: false },
  // CIPC
  { label: 'CIPC Annual Return', type: 'CIPC', month: 11, day: 30, color: '#0096b4', urgent: false },
  // Labour
  { label: 'EMP501 Employer Reconciliation', type: 'Labour', month: 5, day: 31, color: '#f59e0b', urgent: false },
  { label: 'EMP501 Interim Reconciliation', type: 'Labour', month: 10, day: 31, color: '#f59e0b', urgent: false },
];

function buildMonthDeadlines(year, month, aiDeadlines = []) {
  const result = [];

  // 1. Statutory recurring deadlines
  STATUTORY_DEADLINES.forEach(d => {
    if (d.monthly) {
      // Clamp to month-end
      const lastDay = new Date(year, month + 1, 0).getDate();
      const day = Math.min(d.day, lastDay);
      const date = new Date(year, month, day);
      const today = new Date(); today.setHours(0, 0, 0, 0);
      result.push({
        date,
        label: d.label,
        type: d.type,
        color: d.color,
        urgent: date <= new Date(today.getTime() + 7 * 86400000),
      });
    } else if (d.month !== undefined && d.month === month) {
      const lastDay = new Date(year, month + 1, 0).getDate();
      const day = Math.min(d.day, lastDay);
      const date = new Date(year, month, day);
      const today = new Date(); today.setHours(0, 0, 0, 0);
      result.push({
        date,
        label: d.label,
        type: d.type,
        color: d.color,
        urgent: date <= new Date(today.getTime() + 7 * 86400000),
      });
    }
  });

  // 2. AI-extracted deadlines
  aiDeadlines.forEach(d => {
    const parsed = new Date(d.date);
    if (!isNaN(parsed) && parsed.getFullYear() === year && parsed.getMonth() === month) {
      const today = new Date(); today.setHours(0, 0, 0, 0);
      result.push({
        date: parsed,
        label: d.label,
        type: d.type || 'AI',
        color: '#8b5cf6',
        urgent: d.urgent || parsed <= new Date(today.getTime() + 7 * 86400000),
        ai: true,
      });
    }
  });

  return result;
}

const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DAY_LABELS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

const typeColor = {
  SARS: '#3cb54a',
  CIPC: '#0096b4',
  Labour: '#f59e0b',
  AI: '#8b5cf6',
};

export default function DeadlineCalendar({ aiDeadlines = [] }) {
  const today = new Date();
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selected, setSelected] = useState(null);

  const deadlines = buildMonthDeadlines(viewYear, viewMonth, aiDeadlines);

  // Map day → deadlines
  const byDay = {};
  deadlines.forEach(d => {
    const key = d.date.getDate();
    if (!byDay[key]) byDay[key] = [];
    byDay[key].push(d);
  });

  // Calendar grid
  const firstDay = new Date(viewYear, viewMonth, 1).getDay();
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const prevMonth = () => {
    if (viewMonth === 0) { setViewYear(y => y - 1); setViewMonth(11); }
    else setViewMonth(m => m - 1);
    setSelected(null);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewYear(y => y + 1); setViewMonth(0); }
    else setViewMonth(m => m + 1);
    setSelected(null);
  };

  const selectedDeadlines = selected ? (byDay[selected] || []) : [];
  const urgentCount = deadlines.filter(d => d.urgent).length;

  return (
    <div className="bg-white rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.07)' }}>
      <div className="h-1" style={{ background: 'linear-gradient(90deg, #0d2a5e, #3cb54a, #13b5ea)' }} />

      <div className="p-5">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" />
            <h2 className="font-grotesk font-semibold text-foreground text-sm">Filing Deadline Calendar</h2>
            {urgentCount > 0 && (
              <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-red-400/10 text-red-500">
                {urgentCount} urgent
              </span>
            )}
          </div>
          <Link to="/calendar" className="text-xs text-primary hover:underline">Full Calendar →</Link>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-3 mb-4">
          {Object.entries(typeColor).map(([k, c]) => (
            <div key={k} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: c }} />
              {k === 'AI' ? 'Compl-i™ Extracted' : k}
            </div>
          ))}
        </div>

        {/* Month nav */}
        <div className="flex items-center justify-between mb-3">
          <button onClick={prevMonth} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
            <ChevronLeft className="w-4 h-4 text-muted-foreground" />
          </button>
          <p className="font-semibold text-foreground text-sm">{MONTH_NAMES[viewMonth]} {viewYear}</p>
          <button onClick={nextMonth} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Day labels */}
        <div className="grid grid-cols-7 mb-1">
          {DAY_LABELS.map(d => (
            <div key={d} className="text-center text-xs text-muted-foreground py-1 font-medium">{d}</div>
          ))}
        </div>

        {/* Calendar grid */}
        <div className="grid grid-cols-7 gap-0.5">
          {cells.map((day, i) => {
            if (!day) return <div key={`e-${i}`} />;
            const isToday = day === today.getDate() && viewMonth === today.getMonth() && viewYear === today.getFullYear();
            const items = byDay[day] || [];
            const hasUrgent = items.some(d => d.urgent);
            const isSelected = selected === day;

            return (
              <button
                key={day}
                onClick={() => setSelected(isSelected ? null : day)}
                className={`relative flex flex-col items-center rounded-lg py-1.5 transition-all text-xs ${
                  isSelected ? 'ring-2 ring-primary bg-primary/5' :
                  isToday ? 'bg-primary/10' :
                  items.length ? 'hover:bg-secondary' : 'hover:bg-secondary/50'
                }`}
              >
                <span className={`w-6 h-6 flex items-center justify-center rounded-full text-xs font-medium ${
                  isToday ? 'bg-primary text-white' : 'text-foreground'
                }`}>{day}</span>

                {/* Dot indicators */}
                {items.length > 0 && (
                  <div className="flex gap-0.5 mt-0.5 flex-wrap justify-center max-w-[28px]">
                    {items.slice(0, 3).map((item, idx) => (
                      <div key={idx} className="w-1.5 h-1.5 rounded-full" style={{ background: item.color }} />
                    ))}
                    {items.length > 3 && <div className="w-1.5 h-1.5 rounded-full bg-gray-300" />}
                  </div>
                )}

                {/* Urgent pulse */}
                {hasUrgent && (
                  <div className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
                )}
              </button>
            );
          })}
        </div>

        {/* Selected day detail */}
        {selected && (
          <div className="mt-4 border-t border-border pt-4 space-y-2">
            <p className="text-xs font-semibold text-foreground">
              {MONTH_NAMES[viewMonth]} {selected}, {viewYear}
            </p>
            {selectedDeadlines.length === 0 ? (
              <p className="text-xs text-muted-foreground">No deadlines on this day.</p>
            ) : selectedDeadlines.map((d, i) => (
              <div key={i} className={`flex items-start gap-2.5 p-2.5 rounded-lg ${d.urgent ? 'bg-red-50 border border-red-100' : 'bg-gray-50 border border-gray-100'}`}>
                <div className="w-2 h-2 rounded-full mt-1 flex-shrink-0" style={{ background: d.color }} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground">{d.label}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs text-muted-foreground">{d.type}</span>
                    {d.ai && <span className="text-xs px-1.5 py-0 rounded-full bg-purple-50 text-purple-600 border border-purple-100">Compl-i™</span>}
                    {d.urgent && <span className="flex items-center gap-0.5 text-xs text-red-500"><AlertTriangle className="w-3 h-3" /> Urgent</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* This month summary */}
        {deadlines.length > 0 && !selected && (
          <div className="mt-4 border-t border-border pt-3">
            <p className="text-xs text-muted-foreground mb-2">This month: <strong className="text-foreground">{deadlines.length} filing deadlines</strong></p>
            <div className="space-y-1.5 max-h-32 overflow-y-auto">
              {deadlines.sort((a, b) => a.date - b.date).map((d, i) => (
                <button key={i} onClick={() => setSelected(d.date.getDate())}
                  className="w-full flex items-center gap-2 text-left hover:bg-secondary/50 rounded-lg px-2 py-1.5 transition-colors">
                  <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: d.color }} />
                  <span className="text-xs text-foreground flex-1 truncate">{d.label}</span>
                  <span className="text-xs text-muted-foreground font-mono flex-shrink-0">
                    {d.date.getDate()} {MONTH_NAMES[d.date.getMonth()].slice(0, 3)}
                  </span>
                  {d.urgent && <AlertTriangle className="w-3 h-3 text-red-400 flex-shrink-0" />}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}