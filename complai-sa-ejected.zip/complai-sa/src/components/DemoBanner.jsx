import { useDemo } from '@/lib/DemoContext';
import { useNavigate } from 'react-router-dom';
import { X, Eye } from 'lucide-react';

export default function DemoBanner() {
  const { isDemo, exitDemo } = useDemo();
  const navigate = useNavigate();

  if (!isDemo) return null;

  const handleExit = () => {
    exitDemo();
    navigate('/');
  };

  return (
    <div className="sticky top-0 z-[60] flex items-center justify-between px-4 py-2"
      style={{ background: 'linear-gradient(90deg, #f59e0b 0%, #f97316 100%)' }}>
      <div className="flex items-center gap-2 text-white">
        <Eye className="w-4 h-4 flex-shrink-0" />
        <span className="text-sm font-bold">DEMO MODE</span>
        <span className="text-xs hidden sm:inline opacity-90">— You are viewing simulated data. No information is saved.</span>
      </div>
      <button onClick={handleExit}
        className="flex items-center gap-1 text-xs font-semibold bg-white/20 hover:bg-white/30 px-3 py-1 rounded-full transition-colors text-white">
        <X className="w-3 h-3" /> Exit Demo
      </button>
    </div>
  );
}