import { useState } from 'react';
import { ExternalLink, Lock, Eye, EyeOff, CheckCircle, Zap, X } from 'lucide-react';

const PLATFORMS = [
  {
    id: 'sars',
    name: 'SARS eFiling',
    url: 'https://efiling.sars.gov.za',
    logo: '🇿🇦',
    color: 'text-green-500',
    bg: 'bg-green-500/10 border-green-500/20',
    description: 'Submit VAT201, EMP201, IRP6, ITR12 and more directly via SARS eFiling.',
    fields: ['Username', 'Password'],
  },
  {
    id: 'cipc',
    name: 'CIPC e-Services',
    url: 'https://eservices.cipc.co.za',
    logo: '🏢',
    color: 'text-blue-500',
    bg: 'bg-blue-500/10 border-blue-500/20',
    description: 'Annual returns, name reservations, and company filings via CIPC.',
    fields: ['Customer Code', 'Password'],
  },
  {
    id: 'workmens',
    name: 'Compensation Fund (CF)',
    url: 'https://www.workmenscompensation.co.za',
    logo: '🛡️',
    color: 'text-orange-500',
    bg: 'bg-orange-500/10 border-orange-500/20',
    description: 'COIDA Return of Earnings (W.As.8) submission.',
    fields: ['Username', 'Password'],
  },
  {
    id: 'uif',
    name: 'UIF / u-Filing',
    url: 'https://ufiling.labour.gov.za',
    logo: '👷',
    color: 'text-yellow-500',
    bg: 'bg-yellow-500/10 border-yellow-500/20',
    description: 'UIF declarations and contributor submissions.',
    fields: ['Username', 'Password'],
  },
  {
    id: 'dol',
    name: 'Dept. of Employment & Labour',
    url: 'https://www.labour.gov.za',
    logo: '⚖️',
    color: 'text-purple-500',
    bg: 'bg-purple-500/10 border-purple-500/20',
    description: 'Employment Equity Reports (EEA2/EEA4), WSP/ATR submissions.',
    fields: ['Username', 'Password'],
  },
  {
    id: 'bbbeeverify',
    name: 'SANAS / B-BBEE Verification',
    url: 'https://www.sanas.co.za',
    logo: '📊',
    color: 'text-pink-500',
    bg: 'bg-pink-500/10 border-pink-500/20',
    description: 'Upload B-BBEE certificates and manage verification bodies.',
    fields: ['Reference No.', 'Access Code'],
  },
];

function LoginModal({ platform, onClose, onSave }) {
  const [creds, setCreds] = useState({});
  const [showPw, setShowPw] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    onSave(platform.id, creds);
    setTimeout(() => { setSaved(false); onClose(); }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="glass-card rounded-2xl border border-primary/30 max-w-sm w-full p-6 animate-slide-up">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{platform.logo}</span>
            <div>
              <p className="font-grotesk font-bold text-foreground text-sm">{platform.name}</p>
              <p className="text-xs text-muted-foreground">Secure credential store</p>
            </div>
          </div>
          <button onClick={onClose}><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>

        <div className="p-3 bg-yellow-400/5 border border-yellow-400/20 rounded-lg mb-4">
          <p className="text-xs text-yellow-600">⚠ Credentials are stored locally in your browser session only. Never shared with third parties.</p>
        </div>

        <div className="space-y-3">
          {platform.fields.map((field, i) => (
            <div key={i}>
              <label className="text-xs text-muted-foreground mb-1.5 block">{field}</label>
              <div className="relative">
                <input
                  type={i === 1 && !showPw ? 'password' : 'text'}
                  placeholder={field}
                  onChange={e => setCreds(p => ({ ...p, [field]: e.target.value }))}
                  className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none pr-9"
                />
                {i === 1 && (
                  <button onClick={() => setShowPw(!showPw)} className="absolute right-3 top-2.5 text-muted-foreground">
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-3 mt-5">
          <button onClick={onClose} className="flex-1 py-2 border border-border rounded-lg text-sm text-muted-foreground">Cancel</button>
          <button onClick={handleSave}
            className="flex-1 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium neon-glow flex items-center justify-center gap-2">
            {saved ? <><CheckCircle className="w-4 h-4" /> Saved!</> : <><Lock className="w-4 h-4" /> Save & Connect</>}
          </button>
        </div>

        <a href={platform.url} target="_blank" rel="noopener noreferrer"
          className="flex items-center justify-center gap-1.5 mt-3 text-xs text-primary hover:underline">
          <ExternalLink className="w-3 h-3" /> Open {platform.name} Portal
        </a>
      </div>
    </div>
  );
}

export default function FilingIntegrationCard({ compact = false }) {
  const [modal, setModal] = useState(null);
  const [connected, setConnected] = useState({});

  const handleSave = (id, creds) => {
    setConnected(p => ({ ...p, [id]: true }));
  };

  return (
    <>
      {modal && (
        <LoginModal
          platform={PLATFORMS.find(p => p.id === modal)}
          onClose={() => setModal(null)}
          onSave={handleSave}
        />
      )}

      <div className={compact ? 'grid grid-cols-2 sm:grid-cols-3 gap-3' : 'grid sm:grid-cols-2 lg:grid-cols-3 gap-4'}>
        {PLATFORMS.map(p => (
          <div key={p.id} className={`glass-card rounded-xl border p-4 flex flex-col gap-3 ${p.bg} hover:shadow-md transition-shadow`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">{p.logo}</span>
                <p className={`text-xs font-semibold ${p.color}`}>{p.name}</p>
              </div>
              {connected[p.id] && <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />}
            </div>
            {!compact && <p className="text-xs text-muted-foreground leading-relaxed">{p.description}</p>}
            <button
              onClick={() => setModal(p.id)}
              className={`mt-auto flex items-center justify-center gap-1.5 w-full py-2 rounded-lg text-xs font-medium border transition-colors ${connected[p.id] ? 'border-green-400/30 text-green-500 bg-green-400/5 hover:bg-green-400/10' : 'border-primary/30 text-primary bg-primary/5 hover:bg-primary/10'}`}>
              <Zap className="w-3 h-3" />
              {connected[p.id] ? 'Re-configure' : 'Connect & File'}
            </button>
          </div>
        ))}
      </div>
    </>
  );
}