import { Link } from 'react-router-dom';
import SNCBrandLogo from '@/components/SNCBrandLogo';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-border bg-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid sm:grid-cols-2 md:grid-cols-5 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-2">
            {/* SNC-TAX logo + Compl-Ai brand side by side */}
            <div className="flex items-center gap-3 mb-4">
              <img
                src="/brand/snc-logo.png"
                alt="SNC-TAX"
                className="h-8 w-auto object-contain"
              />
              <div className="w-px h-7 bg-border" />
              <SNCBrandLogo size="sm" showTagline={false} light={false} />
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed max-w-xs">
              A product owned and operated by <strong className="text-foreground">SNC-TAX</strong>. Developed by SA-iLabs®™. Your all-in-one South African SMME compliance platform.
            </p>
            <p className="text-xs font-semibold mt-2" style={{ color: '#3cb54a' }}>Re-imagining Compliance Intelligence</p>
            <p className="text-xs text-muted-foreground mt-0.5 italic">Where smart business meets statutory certainty.</p>
          </div>

          {/* Platform */}
          <div>
            <p className="text-xs font-semibold text-foreground uppercase tracking-wider mb-3">Platform</p>
            <div className="space-y-2">
              {[
                { label: 'Dashboard', to: '/' },
                { label: 'Compliance Calendar', to: '/calendar' },
                { label: 'Document Vault', to: '/vault' },
                { label: 'Compl-i™ Chat', to: '/chat' },
                { label: 'Audit Report', to: '/audit-report' },
                { label: 'Maturity Roadmap', to: '/maturity' },
                { label: 'Risk Analytics', to: '/risk-analytics' },
                { label: 'Filing Automation', to: '/filing-automation' },
              ].map(l => (
                <Link key={l.to} to={l.to} className="block text-xs text-muted-foreground hover:text-primary transition-colors">{l.label}</Link>
              ))}
            </div>
          </div>

          {/* Report Bug */}
          <div>
            <p className="text-xs font-semibold text-foreground uppercase tracking-wider mb-3">Report Bug</p>
            <div className="space-y-2 text-xs text-muted-foreground">
              <p><strong className="text-foreground">Developer:</strong><br />Christo Botha from SA-iLabs™</p>
              <a
                href="https://chat.whatsapp.com/GSJlawXrNYSACd5r3kw6n7?s=cl&p=a&ilr=1&amv=0"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 mt-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
                style={{ background: '#25D366', color: '#ffffff' }}
              >
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.693.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.89c0 2.096.549 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                Join WhatsApp Group
              </a>
              <a
                href="https://chat.whatsapp.com/GSJlawXrNYSACd5r3kw6n7?s=cl&p=a&ilr=1&amv=0"
                target="_blank"
                rel="noopener noreferrer"
                className="block mt-3"
              >
                <img
                  src="/brand/whatsapp-qr.jpg"
                  alt="Compl-Ai™ Debug Reports WhatsApp Group QR Code"
                  className="w-24 h-auto rounded-lg border border-border"
                />
              </a>
            </div>
          </div>

          {/* Legal */}
          <div>
            <p className="text-xs font-semibold text-foreground uppercase tracking-wider mb-3">Legal & Compliance</p>
            <div className="space-y-2 text-xs text-muted-foreground">
              <p><strong className="text-foreground">Owner / Copyright Holder:</strong><br />SNC-TAX</p>
              <p><strong className="text-foreground">Developer Agency:</strong><br />SA-iLabs®™</p>
              <p><strong className="text-foreground">In-App AI:</strong><br />Compl-i™</p>
              <p className="mt-1"><strong className="text-foreground">Accuracy &amp; Ethics Engine:</strong><br />Compl-i Assistant™ (MAICP Protocol · SA-iLabs®™)</p>
              <p className="mt-3">POPIA Compliant · FICA Aware · SA Law</p>
              <p className="mt-1">All outputs are for guidance only and do not constitute legal or tax advice. Verify with a registered professional.</p>
              <Link to="/legal" className="inline-block mt-3 px-3 py-1.5 bg-primary/10 border border-primary/30 text-primary rounded-lg text-xs font-semibold hover:bg-primary/20 transition-colors">
                📄 Full Legal &amp; Compliance Documents →
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <div className="text-center sm:text-left">
            <p>© {year} <a href="https://www.snctax.co.za" target="_blank" rel="noopener noreferrer" className="text-foreground hover:text-primary transition-colors">SNC-TAX</a> — All Rights Reserved. Licensed exclusively to SNC-TAX.</p>
            <p className="mt-0.5">Developed & Powered by <a href="https://www.sa-ilabs.co.za" target="_blank" rel="noopener noreferrer" className="text-foreground hover:text-primary transition-colors">SA-iLabs®™</a> · Compl-i™ AI · MAICP Protocol via Compl-i Assistant™ · Compl-Ai™ SA</p>
          </div>
          <div className="flex gap-4">
            <span>POPIA Compliant</span>
            <span>·</span>
            <span>SA Law</span>
            <span>·</span>
            <span>Compl-i™ · Compl-i Assistant™ MAICP</span>
          </div>
        </div>
      </div>
    </footer>
  );
}