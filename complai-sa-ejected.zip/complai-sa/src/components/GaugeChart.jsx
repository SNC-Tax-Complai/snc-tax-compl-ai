/**
 * Reusable SVG half-circle gauge.
 * value: 0–100, label, color, size (px)
 */
export default function GaugeChart({ value = 0, label = '', sublabel = '', color = '#0096b4', size = 140 }) {
  const r = 54;
  const cx = 70;
  const cy = 70;
  const circumference = Math.PI * r; // half circle
  const offset = circumference - (value / 100) * circumference;

  // Arc colours: green < 40, yellow 40-70, red > 70 (for risk) — caller passes explicit color
  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size * 0.6} viewBox="0 0 140 80">
        {/* Track */}
        <path
          d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
          fill="none"
          stroke="#e2e8f0"
          strokeWidth="12"
          strokeLinecap="round"
        />
        {/* Value arc */}
        <path
          d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
          fill="none"
          stroke={color}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={`${(value / 100) * circumference} ${circumference}`}
          style={{ transition: 'stroke-dasharray 0.8s ease' }}
        />
        {/* Centre text */}
        <text x={cx} y={cy - 2} textAnchor="middle" fontSize="18" fontWeight="700" fill="currentColor" className="fill-foreground">
          {value}%
        </text>
      </svg>
      {label && <p className="text-xs font-semibold text-foreground mt-0.5 text-center">{label}</p>}
      {sublabel && <p className="text-xs text-muted-foreground text-center">{sublabel}</p>}
    </div>
  );
}