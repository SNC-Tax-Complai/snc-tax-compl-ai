import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, ChevronDown, Eye } from 'lucide-react';
import SNCBrandLogo from '@/components/SNCBrandLogo';
import { useDemo } from '@/lib/DemoContext';

const navItems = [
  { label: 'Dashboard', path: '/' },
  {
    label: 'Compliance', path: '#', sub: [
      { label: 'CIPC', path: '/cipc' },
      { label: 'SARS Tax', path: '/sars' },
      { label: 'Labour Law', path: '/labour' },
      { label: 'OHS', path: '/ohs' },
      { label: 'POPIA & PAIA', path: '/popia' },
      { label: 'B-BBEE', path: '/bbbee' },
      { label: 'FICA', path: '/fica' },
      { label: 'Municipal', path: '/municipal' },
      { label: 'Industry & Sector', path: '/industry' },
    ]
  },
  { label: 'Tax Engine', path: '/tax-engine' },
  { label: 'Vault', path: '/vault' },
  { label: 'Calendar', path: '/calendar' },
  { label: 'Compl-i™ Chat', path: '/chat' },
  {
    label: 'Intelligence', path: '#', sub: [
      { label: 'Industry Intel', path: '/industry-dashboard' },
      { label: 'Risk Analytics', path: '/risk-analytics' },
      { label: 'Sector Profiling', path: '/sector-profile' },
      { label: 'Maturity Roadmap', path: '/maturity' },
    ]
  },
  {
    label: 'Filing & Reports', path: '#', sub: [
      { label: 'Filing Automation', path: '/filing-automation' },
      { label: 'Filing Workflows', path: '/filing' },
      { label: 'Audit Report', path: '/audit-report' },
      { label: 'Auditor View', path: '/auditor-view' },
    ]
  },
  { label: 'White-Label', path: '/white-label' },
  { label: 'Integrations', path: '/integrations' },
  { label: 'WhatsApp Alerts', path: '/whatsapp' },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();
  const { isDemo, enterDemo, exitDemo } = useDemo();

  const handleDemoToggle = () => {
    if (isDemo) { exitDemo(); }
    else { enterDemo(); }
    navigate('/');
    setOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-border" style={{ boxShadow: '0 2px 12px rgba(13,42,94,0.10)' }}>
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <SNCBrandLogo size="sm" showTagline={true} light={false} />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-0.5">
          {navItems.map((item) =>
            item.sub ? (
              <div key={item.label} className="relative" onMouseEnter={() => setActiveDropdown(item.label)} onMouseLeave={() => setActiveDropdown(null)}>
                <button className="flex items-center gap-1 px-3 py-2 rounded text-sm text-muted-foreground hover:text-primary hover:bg-primary/5 transition-colors">
                  {item.label} <ChevronDown className="w-3 h-3" />
                </button>
                {activeDropdown === item.label && (
                  <div className="absolute top-full left-0 mt-1 w-48 bg-white rounded-lg border border-border shadow-lg py-1 z-50">
                    {item.sub.map(s => (
                      <Link key={s.path} to={s.path} className="block px-4 py-2 text-sm text-muted-foreground hover:text-primary hover:bg-primary/5 transition-colors">
                        {s.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <Link key={item.path} to={item.path}
                className={`px-3 py-2 rounded text-sm transition-colors ${
                  location.pathname === item.path
                    ? 'text-primary bg-primary/10 font-medium'
                    : 'text-muted-foreground hover:text-primary hover:bg-primary/5'
                }`}>
                {item.label}
              </Link>
            )
          )}
        </nav>

        <div className="hidden lg:flex items-center gap-3">
          <button onClick={handleDemoToggle} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all hover:opacity-90"
            style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #f97316 100%)', color: '#fff', borderColor: 'rgba(245,158,11,0.3)' }}>
            <Eye className="w-3.5 h-3.5" /> {isDemo ? 'Exit Demo' : 'DEMO'}
          </button>
          <Link to="/login" className="text-sm text-muted-foreground hover:text-primary transition-colors font-medium">Sign In</Link>
          <Link to="/register" className="px-4 py-2 text-white rounded text-sm font-semibold transition-all shadow-sm hover:opacity-90"
            style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #13b5ea 100%)' }}>
            Get Started
          </Link>
          {/* Separator */}
          <div className="w-px h-5 bg-border mx-1" />
          {/* Admin Portal — separated & distinct */}
          <Link
            to="/admin-login"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all hover:opacity-90"
            style={{ background: 'rgba(13,42,94,0.06)', borderColor: 'rgba(13,42,94,0.20)', color: '#0d2a5e' }}
          >
            🔐 Admin Portal
          </Link>
        </div>

        <button className="lg:hidden text-muted-foreground hover:text-primary" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden bg-white border-t border-border px-4 py-4 space-y-1">
          {navItems.map((item) =>
            item.sub ? (
              <div key={item.label}>
                <p className="px-3 py-1 text-xs font-semibold text-muted-foreground uppercase tracking-wider">{item.label}</p>
                {item.sub.map(s => (
                  <Link key={s.path} to={s.path} onClick={() => setOpen(false)}
                    className="block px-5 py-2 text-sm text-muted-foreground hover:text-primary transition-colors">{s.label}</Link>
                ))}
              </div>
            ) : (
              <Link key={item.path} to={item.path} onClick={() => setOpen(false)}
                className={`block px-3 py-2 rounded-lg text-sm transition-colors ${location.pathname === item.path ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-primary'}`}>
                {item.label}
              </Link>
            )
          )}
          <button onClick={handleDemoToggle}
            className="w-full mb-2 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold"
            style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #f97316 100%)', color: '#fff' }}>
            <Eye className="w-3.5 h-3.5" /> {isDemo ? 'Exit Demo Mode' : 'Try DEMO Mode'}
          </button>
          <div className="pt-3 flex gap-3">
            <Link to="/login" onClick={() => setOpen(false)} className="flex-1 text-center py-2 border border-primary/30 rounded-lg text-sm text-primary">Sign In</Link>
            <Link to="/register" onClick={() => setOpen(false)} className="flex-1 text-center py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium">Get Started</Link>
          </div>
          <Link to="/admin-login" onClick={() => setOpen(false)}
            className="mt-2 block w-full text-center py-2 rounded-lg text-xs font-semibold border"
            style={{ background: 'rgba(13,42,94,0.05)', borderColor: 'rgba(13,42,94,0.20)', color: '#0d2a5e' }}>
            🔐 Admin Portal
          </Link>
        </div>
      )}
    </header>
  );
}