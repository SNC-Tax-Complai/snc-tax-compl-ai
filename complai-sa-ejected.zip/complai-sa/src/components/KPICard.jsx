export default function KPICard({ title, value, subtitle, icon: Icon, color = 'text-primary', trend }) {
  return (
    <div className="relative bg-white rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300 group"
      style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.07), 0 8px 24px rgba(13,42,94,0.04)' }}>
      {/* Top accent bar */}
      <div className="h-1 w-full" style={{ background: 'linear-gradient(90deg, #0d2a5e 0%, #13b5ea 60%, #3cb54a 100%)' }} />
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className={`p-3 rounded-xl ${color} group-hover:scale-110 transition-transform`}
            style={{ background: 'rgba(13,42,94,0.07)' }}>
            <Icon className="w-5 h-5" />
          </div>
          {trend !== undefined && (
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${trend > 0 ? 'bg-green-50 text-green-600 border border-green-200' : 'bg-red-50 text-red-500 border border-red-200'}`}>
              {trend > 0 ? '▲' : '▼'} {Math.abs(trend)}%
            </span>
          )}
        </div>
        <div className="text-3xl font-bold font-grotesk mb-1" style={{ color: '#0d2a5e' }}>{value}</div>
        <div className="text-sm font-semibold text-foreground">{title}</div>
        {subtitle && <div className="text-xs text-muted-foreground mt-1.5 leading-relaxed">{subtitle}</div>}
      </div>
    </div>
  );
}