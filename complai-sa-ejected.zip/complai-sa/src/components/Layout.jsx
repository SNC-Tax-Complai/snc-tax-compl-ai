import { Outlet } from 'react-router-dom';
import Header from './Header';
import CompliAssistant from './CompliAssistant';
import Footer from './Footer';
import DemoBanner from './DemoBanner';

export default function Layout() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <DemoBanner />
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
      <CompliAssistant />
    </div>
  );
}