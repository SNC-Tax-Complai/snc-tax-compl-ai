import { useEffect, useState } from 'react';
import { CheckCircle, Loader2, Bot, FileText, Shield, Globe } from 'lucide-react';

/**
 * LoadingCheckmark — animated checkmark loader with sequential progress steps.
 * Shows a series of tasks that check off one by one, with a spinning indicator
 * on the current task. Used across the app for loading states and AI thinking.
 *
 * Props:
 *  - steps: array of { label, icon } — defaults to AI-style steps
 *  - stepDuration: ms per step (default 600)
 *  - onComplete: optional callback when all steps are done
 *  - size: 'sm' | 'md' | 'lg' (default 'md')
 *  - light: boolean — use white text/icons for dark backgrounds (default false)
 *  - inline: boolean — render inline without full-height centering (default false)
 *  - loop: boolean — loop the animation indefinitely (default true)
 *  - title: optional heading text above steps
 */
const defaultSteps = [
  { label: 'Initialising…', icon: Loader2 },
  { label: 'Fetching live data…', icon: Globe },
  { label: 'AI analysing…', icon: Bot },
  { label: 'Securing your data…', icon: Shield },
];

const sizeMap = {
  sm: { icon: 'w-3.5 h-3.5', text: 'text-xs', check: 'w-3 h-3', gap: 'gap-2', pad: 'p-1.5', spinner: 'w-3 h-3' },
  md: { icon: 'w-4 h-4', text: 'text-sm', check: 'w-4 h-4', gap: 'gap-2.5', pad: 'p-2', spinner: 'w-4 h-4' },
  lg: { icon: 'w-5 h-5', text: 'text-sm', check: 'w-5 h-5', gap: 'gap-3', pad: 'p-2.5', spinner: 'w-5 h-5' },
};

export default function LoadingCheckmark({
  steps = defaultSteps,
  stepDuration = 700,
  onComplete,
  size = 'md',
  light = false,
  inline = false,
  loop = true,
  title = null,
}) {
  const [currentStep, setCurrentStep] = useState(0);
  const s = sizeMap[size] || sizeMap.md;

  useEffect(() => {
    if (currentStep < steps.length) {
      const timer = setTimeout(() => {
        if (currentStep === steps.length - 1) {
          if (onComplete) onComplete();
          if (loop) {
            setTimeout(() => setCurrentStep(0), 500);
          }
        } else {
          setCurrentStep(prev => prev + 1);
        }
      }, stepDuration);
      return () => clearTimeout(timer);
    }
  }, [currentStep, steps.length, stepDuration, loop, onComplete]);

  const containerClass = inline
    ? 'flex flex-col gap-3'
    : 'flex flex-col items-center justify-center gap-4 py-8';

  const labelColor = light ? 'text-white/80' : 'text-muted-foreground';
  const doneColor = light ? 'text-green-400' : 'text-green-500';
  const activeColor = light ? 'text-cyan-300' : 'text-primary';
  const pendingColor = light ? 'text-white/30' : 'text-muted-foreground/40';

  return (
    <div className={containerClass}>
      {title && (
        <p className={`font-grotesk font-semibold ${s.text} ${light ? 'text-white' : 'text-foreground'} mb-1`}>
          {title}
        </p>
      )}
      <div className={`flex flex-col ${s.gap} ${inline ? '' : 'w-full max-w-xs mx-auto'}`}>
        {steps.map((step, i) => {
          const StepIcon = step.icon || Loader2;
          const isDone = i < currentStep;
          const isActive = i === currentStep;
          const isPending = i > currentStep;

          return (
            <div
              key={i}
              className={`flex items-center ${s.gap} ${s.pad} rounded-lg transition-all duration-300 ${
                isActive ? (light ? 'bg-white/10' : 'bg-primary/5') : ''
              }`}
              style={{
                opacity: isPending ? 0.4 : 1,
                transform: isActive ? 'translateX(4px)' : 'translateX(0)',
              }}
            >
              {/* Status icon area */}
              <div className="flex-shrink-0 w-5 flex items-center justify-center">
                {isDone ? (
                  <CheckCircle className={`${s.check} ${doneColor}`} style={{ animation: 'checkmark-pop 0.3s ease-out' }} />
                ) : isActive ? (
                  <StepIcon className={`${s.spinner} ${activeColor} animate-spin`} />
                ) : (
                  <StepIcon className={`${s.icon} ${pendingColor}`} />
                )}
              </div>

              {/* Label */}
              <span className={`${s.text} font-medium ${isDone ? doneColor : isActive ? (light ? 'text-white' : 'text-foreground') : pendingColor}`}>
                {step.label}
              </span>
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes checkmark-pop {
          0% { transform: scale(0); opacity: 0; }
          60% { transform: scale(1.15); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  );
}