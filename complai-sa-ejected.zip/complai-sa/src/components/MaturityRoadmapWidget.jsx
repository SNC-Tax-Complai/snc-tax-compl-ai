import { Link } from 'react-router-dom';
import { ChevronRight, Award, CheckCircle, Lock } from 'lucide-react';

const STAGES = [
  { id: 1, level: 'Non-Compliant', color: '#ef4444', doneDefault: 3, total: 5 },
  { id: 2, level: 'Basic Compliance', color: '#f97316', doneDefault: 2, total: 5 },
  { id: 3, level: 'Operationally Compliant', color: '#eab308', doneDefault: 2, total: 5 },
  { id: 4, level: 'Substantially Compliant', color: '#0096b4', doneDefault: 2, total: 5 },
  { id: 5, level: 'Advanced Compliance', color: '#0d2a5e', doneDefault: 1, total: 5 },
  { id: 6, level: 'Fully Optimized', color: '#16a34a', doneDefault: 0, total: 5 },
];

const MILESTONES = [
  { level: 2, label: '🏅 EME B-BBEE Affidavit' },
  { level: 3, label: '🛡️ OHS Risk Assessment' },
  { level: 4, label: '📊 B-BBEE QSE Verification' },
  { level: 5, label: '⚖️ Employment Equity Report' },
  { level: 6, label: '🏆 ISO 37301 Alignment' },
];

export default function MaturityRoadmapWidget() {
  const currentLevel = 3; // stage 3 = operationally compliant (based on dashboard data)
  const overallPct = Math.round((10 / 30) * 100);

  return (
    <div className="glass-card rounded-xl p-5 border border-primary/10">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-primary" />
          <h2 className="font-grotesk font-semibold text-foreground text-sm">Compliance Maturity Roadmap</h2>
        </div>
        <Link to="/maturity" className="text-xs text-primary hover:underline flex items-center gap-1">
          Full Roadmap <ChevronRight className="w-3 h-3" />
        </Link>
      </div>

      {/* Stage track */}
      <div className="flex items-center gap-1 mb-4">
        {STAGES.map((s, i) => (
          <div key={s.id} className="flex items-center flex-1">
            <div className={`flex-1 flex flex-col items-center gap-1`}>
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold border-2 transition-all ${s.id <= currentLevel ? 'opacity-100' : 'opacity-30'}`}
                style={{ backgroundColor: s.id <= currentLevel ? s.color : '#e2e8f0', borderColor: s.id <= currentLevel ? s.color : '#e2e8f0' }}
              >
                {s.id < currentLevel ? '✓' : s.id === currentLevel ? '→' : <Lock className="w-3 h-3" style={{ color: '#94a3b8' }} />}
              </div>
              <span className="text-[9px] text-muted-foreground text-center leading-tight hidden sm:block" style={{ maxWidth: 52 }}>
                {s.level.split(' ')[0]}
              </span>
            </div>
            {i < STAGES.length - 1 && (
              <div className={`h-0.5 flex-1 mx-0.5 rounded ${s.id < currentLevel ? 'bg-primary' : 'bg-border'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Current level + next milestone */}
      <div className="flex items-center justify-between gap-3 p-3 bg-primary/5 border border-primary/20 rounded-lg">
        <div>
          <p className="text-xs font-semibold text-foreground">Level {currentLevel} — Operationally Compliant</p>
          <p className="text-xs text-muted-foreground mt-0.5">Next milestone: <strong className="text-primary">🛡️ OHS Risk Assessment</strong></p>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="text-lg font-bold text-primary font-grotesk">{overallPct}%</p>
          <p className="text-xs text-muted-foreground">overall</p>
        </div>
      </div>

      {/* Upcoming milestones */}
      <div className="mt-3 space-y-1.5">
        {MILESTONES.filter(m => m.level >= currentLevel).slice(0, 3).map((m, i) => (
          <div key={i} className={`flex items-center gap-2 text-xs p-2 rounded-lg ${m.level === currentLevel ? 'bg-yellow-400/10 border border-yellow-400/20' : 'bg-secondary/40'}`}>
            <CheckCircle className={`w-3.5 h-3.5 flex-shrink-0 ${m.level === currentLevel ? 'text-yellow-500' : 'text-muted-foreground'}`} />
            <span className={m.level === currentLevel ? 'text-foreground font-medium' : 'text-muted-foreground'}>{m.label}</span>
            <span className="ml-auto text-muted-foreground">L{m.level}</span>
          </div>
        ))}
      </div>
    </div>
  );
}