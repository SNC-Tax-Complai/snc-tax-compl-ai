import { Link } from 'react-router-dom';
import { ChevronRight, AlertTriangle } from 'lucide-react';
import GaugeChart from './GaugeChart';

const RISK_GAUGES = [
  { label: 'SARS Penalty Risk', sublabel: 'EMP201 overdue', value: 74, color: '#ef4444' },
  { label: 'CIPC Fine Risk', sublabel: 'Annual return due', value: 48, color: '#f97316' },
  { label: 'OHS Non-Compliance', sublabel: 'Inspection overdue', value: 62, color: '#eab308' },
  { label: 'B-BBEE Risk', sublabel: 'Affidavit expiring', value: 35, color: '#0096b4' },
];

function riskLabel(v) {
  if (v >= 70) return { text: 'HIGH', cls: 'text-red-400 bg-red-400/10' };
  if (v >= 45) return { text: 'MED', cls: 'text-yellow-500 bg-yellow-400/10' };
  return { text: 'LOW', cls: 'text-green-500 bg-green-400/10' };
}

export default function RiskGaugeWidget() {
  return (
    <div className="glass-card rounded-xl p-5 border border-primary/10">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-yellow-400" />
          <h2 className="font-grotesk font-semibold text-foreground text-sm">Predictive Fine Probability</h2>
        </div>
        <Link to="/risk-analytics" className="text-xs text-primary hover:underline flex items-center gap-1">
          Full Analysis <ChevronRight className="w-3 h-3" />
        </Link>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {RISK_GAUGES.map((g, i) => {
          const rl = riskLabel(g.value);
          return (
            <div key={i} className="flex flex-col items-center gap-1 p-3 bg-secondary/40 rounded-xl border border-border">
              <GaugeChart value={g.value} color={g.color} size={110} />
              <p className="text-xs font-semibold text-foreground text-center leading-tight">{g.label}</p>
              <p className="text-xs text-muted-foreground text-center">{g.sublabel}</p>
              <span className={`text-xs px-2 py-0.5 rounded-full font-bold mt-0.5 ${rl.cls}`}>{rl.text} RISK</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}