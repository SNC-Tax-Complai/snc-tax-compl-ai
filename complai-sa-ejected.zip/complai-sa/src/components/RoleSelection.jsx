import { useState } from 'react';
import { User, Shield, ArrowRight, Sparkles } from 'lucide-react';
import SNCBrandLogo from '@/components/SNCBrandLogo';

export default function RoleSelection({ onSelect }) {
  const [hovered, setHovered] = useState(null);

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #0a1f47 100%)' }}>
      <div className="absolute inset-0 opacity-5"
        style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px' }} />

      <div className="relative w-full max-w-3xl">
        <div className="text-center mb-10">
          <div className="flex justify-center mb-4">
            <SNCBrandLogo size="lg" showTagline={true} light={true} />
          </div>
          <h1 className="text-3xl font-bold font-grotesk text-white mb-2">Choose Your Platform</h1>
          <p className="text-white/60 text-sm">Select how you'd like to access Compl-Ai™ SA</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* User Card */}
          <button
            onClick={() => onSelect('user')}
            onMouseEnter={() => setHovered('user')}
            onMouseLeave={() => setHovered(null)}
            className="group relative overflow-hidden rounded-2xl p-8 text-left transition-all duration-300"
            style={{
              background: hovered === 'user' ? 'rgba(60,181,74,0.15)' : 'rgba(255,255,255,0.05)',
              border: `2px solid ${hovered === 'user' ? 'rgba(60,181,74,0.5)' : 'rgba(255,255,255,0.1)'}`,
              transform: hovered === 'user' ? 'translateY(-4px)' : 'translateY(0)',
            }}
          >
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-5"
              style={{ background: 'rgba(60,181,74,0.2)' }}>
              <User className="w-7 h-7 text-green-400" />
            </div>
            <h2 className="text-xl font-bold font-grotesk text-white mb-2">User Platform</h2>
            <p className="text-white/60 text-sm mb-4">Access your compliance dashboard, upload documents, track filings, and chat with Compl-i Assistant.</p>
            <div className="flex items-center gap-2 text-green-400 text-sm font-medium">
              Continue as User <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Admin Card */}
          <button
            onClick={() => onSelect('admin')}
            onMouseEnter={() => setHovered('admin')}
            onMouseLeave={() => setHovered(null)}
            className="group relative overflow-hidden rounded-2xl p-8 text-left transition-all duration-300"
            style={{
              background: hovered === 'admin' ? 'rgba(19,181,234,0.15)' : 'rgba(255,255,255,0.05)',
              border: `2px solid ${hovered === 'admin' ? 'rgba(19,181,234,0.5)' : 'rgba(255,255,255,0.1)'}`,
              transform: hovered === 'admin' ? 'translateY(-4px)' : 'translateY(0)',
            }}
          >
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-5"
              style={{ background: 'rgba(19,181,234,0.2)' }}>
              <Shield className="w-7 h-7 text-cyan-400" />
            </div>
            <h2 className="text-xl font-bold font-grotesk text-white mb-2">Admin Portal</h2>
            <p className="text-white/60 text-sm mb-4">Manage clients, oversee compliance, access the SA-iLabs™ Coding Agent, and control platform settings.</p>
            <div className="flex items-center gap-2 text-cyan-400 text-sm font-medium">
              Continue as Admin <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
            <div className="mt-3 px-2.5 py-1 rounded-full text-xs font-semibold inline-flex items-center gap-1"
              style={{ background: 'rgba(19,181,234,0.1)', color: '#13b5ea' }}>
              <Shield className="w-3 h-3" /> SNC-TAX staff only
            </div>
          </button>
        </div>

        {/* Demo mode */}
        <div className="text-center mt-8">
          <button
            onClick={() => onSelect('demo')}
            className="text-white/40 hover:text-white/70 text-xs transition-colors inline-flex items-center gap-1.5"
          >
            <Sparkles className="w-3 h-3" /> Or explore in Demo Mode — no signup needed
          </button>
        </div>

        <p className="text-center text-white/30 text-xs mt-8">
          © {new Date().getFullYear()} SNC-TAX · SA-iLabs®™ · Compl-Ai™ SA
        </p>
      </div>
    </div>
  );
}