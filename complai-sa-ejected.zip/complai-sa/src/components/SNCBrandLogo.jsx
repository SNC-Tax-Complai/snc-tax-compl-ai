/**
 * SNCBrandLogo — Exact SNC-TAX logo mark (4-square diamond) + Compl-Ai™ name treatment.
 * Matches snctax.co.za branding: navy #0d2a5e + green #3cb54a + cyan #13b5ea
 */
export default function SNCBrandLogo({ size = 'md', showTagline = true, light = false }) {
  const scales = { sm: 0.65, md: 1, lg: 1.35, xl: 1.75 };
  const s = scales[size] || 1;

  const nameColor = light ? '#ffffff' : '#0d2a5e';
  const tagColor = light ? 'rgba(255,255,255,0.65)' : '#64748b';
  const iconSize = Math.round(40 * s);

  return (
    <div className="flex items-center gap-2 select-none">
      {/* SNC-TAX exact diamond/pinwheel mark — 4 squares rotated 45° */}
      <svg
        width={iconSize}
        height={iconSize}
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="SNC-TAX Compl-Ai brand mark"
      >
        {/* Top-left quadrant: navy */}
        <path d="M20 20 L5 20 L20 5 Z" fill="#0d2a5e" />
        {/* Top-right quadrant: green */}
        <path d="M20 20 L20 5 L35 20 Z" fill="#3cb54a" />
        {/* Bottom-right quadrant: navy */}
        <path d="M20 20 L35 20 L20 35 Z" fill="#0d2a5e" />
        {/* Bottom-left quadrant: cyan accent */}
        <path d="M20 20 L20 35 L5 20 Z" fill="#13b5ea" />
        {/* Center dot */}
        <circle cx="20" cy="20" r="3.5" fill="#ffffff" />
      </svg>

      {/* Text treatment */}
      <div className="flex flex-col leading-none">
        {/* Brand name row */}
        <div className="flex items-baseline" style={{ lineHeight: 1 }}>
          <span
            className="font-grotesk font-bold tracking-tight"
            style={{ fontSize: Math.round(20 * s), color: nameColor }}
          >
            Compl
          </span>
          <span
            className="font-grotesk font-black tracking-tight"
            style={{ fontSize: Math.round(20 * s), color: '#3cb54a' }}
          >
            -Ai
          </span>
          <span
            className="font-grotesk font-bold"
            style={{ fontSize: Math.round(13 * s), color: nameColor, marginLeft: 1 }}
          >
            ™
          </span>
          <span
            className="font-grotesk font-semibold ml-1"
            style={{ fontSize: Math.round(12 * s), color: light ? 'rgba(255,255,255,0.50)' : '#94a3b8' }}
          >
            SA
          </span>
        </div>

        {/* Tagline */}
        {showTagline && (
          <span
            className="font-inter font-medium tracking-widest uppercase mt-0.5"
            style={{ fontSize: Math.round(7 * s), color: tagColor, letterSpacing: '0.13em' }}
          >
            Re-imagining Compliance Intelligence
          </span>
        )}
      </div>
    </div>
  );
}