import { useState, useEffect } from 'react';
import {
  Link2, CheckCircle, X, Loader2, Shield, Database, Bot,
  AlertTriangle, RefreshCw, Unlink, TrendingUp, FileText, Building,
} from 'lucide-react';
import { api } from '@/api/apiClient';
import LoadingCheckmark from '@/components/LoadingCheckmark';

export default function SageConnect({ onClose }) {
  const [connected, setConnected] = useState(false);
  const [checking, setChecking] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [token, setToken] = useState('');
  const [country, setCountry] = useState('za');
  const [error, setError] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [lastSync, setLastSync] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [rawData, setRawData] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    checkStatus();
  }, []);

  const checkStatus = async () => {
    setChecking(true);
    try {
      const res = await api.functions.invoke('sageReadBooks', { action: 'status' });
      if (res.data?.connected) {
        setConnected(true);
        setCompanyName(res.data.company_name || '');
        setLastSync(res.data.last_sync_date || '');
      }
    } catch (_) {}
    setChecking(false);
  };

  const handleConnect = async () => {
    if (!token.trim()) { setError('Please enter your Sage API access token.'); return; }
    setConnecting(true);
    setError('');
    try {
      const res = await api.functions.invoke('sageReadBooks', {
        action: 'connect',
        access_token: token.trim(),
        country_region: country,
      });
      if (res.data?.status === 'connected') {
        setConnected(true);
        setCompanyName(res.data.company_name || '');
        setLastSync(new Date().toISOString());
      } else {
        setError(res.data?.error || 'Failed to connect to Sage.');
      }
    } catch (e) {
      setError(e.response?.data?.error || e.message || 'Failed to connect.');
    }
    setConnecting(false);
  };

  const handleDisconnect = async () => {
    await api.functions.invoke('sageReadBooks', { action: 'disconnect' });
    setConnected(false);
    setCompanyName('');
    setAnalysis(null);
    setRawData(null);
  };

  const handleAnalyze = async () => {
    setAnalyzing(true);
    setError('');
    setAnalysis(null);
    try {
      const res = await api.functions.invoke('sageReadBooks', { action: 'analyze' });
      setAnalysis(res.data?.ai_analysis || null);
      setRawData(res.data?.raw_data || null);
      setLastSync(res.data?.sync_date || '');
    } catch (e) {
      setError(e.response?.data?.error || e.message || 'Failed to fetch/analyze books.');
    }
    setAnalyzing(false);
  };

  const ledgerAccounts = rawData?.ledger_accounts?.$items || [];
  const contacts = rawData?.contacts?.$items || [];
  const salesInvoices = rawData?.sales_invoices?.$items || [];
  const purchaseInvoices = rawData?.purchase_invoices?.$items || [];
  const bankAccounts = rawData?.bank_accounts?.$items || [];

  if (checking) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <div className="glass-card rounded-2xl border border-primary/20 p-8 neon-glow">
          <Loader2 className="w-6 h-6 text-primary animate-spin mx-auto" />
          <p className="text-sm text-muted-foreground mt-3">Checking Sage connection…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-3xl glass-card rounded-2xl border border-primary/20 neon-glow animate-slide-up max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-primary/20 flex-shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🟢</span>
            <div>
              <h2 className="font-grotesk font-semibold text-foreground">Sage Business Cloud Accounting</h2>
              <p className="text-xs text-muted-foreground">
                {connected ? `Connected: ${companyName}` : 'Connect your Sage books for AI compliance analysis'}
              </p>
            </div>
          </div>
          <button onClick={onClose}><X className="w-4 h-4 text-muted-foreground hover:text-foreground" /></button>
        </div>

        <div className="overflow-y-auto p-5 space-y-4">
          {/* Not connected: token input form */}
          {!connected && (
            <>
              <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 space-y-2">
                <p className="text-xs font-semibold text-primary flex items-center gap-1">
                  <Shield className="w-3 h-3" /> Read-Only Access
                </p>
                <p className="text-xs text-muted-foreground">
                  Compl-i Assistant will <strong className="text-foreground">only read</strong> your Sage financial data — contacts, invoices, bank accounts, and ledger. No data is written back to Sage.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1.5 block">Sage API Access Token *</label>
                  <input
                    type="password"
                    value={token}
                    onChange={e => setToken(e.target.value)}
                    placeholder="Paste your Sage Business Cloud API token"
                    className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
                  <p className="text-xs text-muted-foreground mt-1">
                    Get your token: Sage Business Cloud → Settings → API Developers → Generate Token
                  </p>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1.5 block">Country / Region</label>
                  <select
                    value={country}
                    onChange={e => setCountry(e.target.value)}
                    className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none">
                    <option value="za">South Africa</option>
                    <option value="gb">United Kingdom</option>
                    <option value="us">United States</option>
                    <option value="au">Australia</option>
                    <option value="ie">Ireland</option>
                    <option value="ca">Canada</option>
                    <option value="in">India</option>
                    <option value="de">Germany</option>
                    <option value="fr">France</option>
                    <option value="es">Spain</option>
                  </select>
                </div>
              </div>

              {error && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-red-400/10 border border-red-400/20 text-xs text-red-400">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  {error}
                </div>
              )}

              <button
                onClick={handleConnect}
                disabled={connecting}
                className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold text-sm neon-glow hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                {connecting ? <><Loader2 className="w-4 h-4 animate-spin" /> Connecting…</> : <><Link2 className="w-4 h-4" /> Connect Sage Account</>}
              </button>
            </>
          )}

          {/* Connected: dashboard */}
          {connected && (
            <>
              {/* Connection bar */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-green-400/10 border border-green-400/20">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <div>
                    <p className="text-sm font-medium text-foreground">{companyName}</p>
                    <p className="text-xs text-muted-foreground">Last synced: {lastSync ? new Date(lastSync).toLocaleString('en-ZA') : 'N/A'}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleAnalyze}
                    disabled={analyzing}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:bg-primary/90 transition-colors disabled:opacity-50">
                    {analyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Bot className="w-3 h-3" />}
                    {analyzing ? 'Analyzing…' : 'AI Analyze Books'}
                  </button>
                  <button
                    onClick={handleDisconnect}
                    className="flex items-center gap-1.5 px-3 py-1.5 border border-border text-muted-foreground rounded-lg text-xs font-medium hover:text-red-400 hover:border-red-400/30 transition-colors">
                    <Unlink className="w-3 h-3" /> Disconnect
                  </button>
                </div>
              </div>

              {/* Analyzing state */}
              {analyzing && (
                <div className="glass-card rounded-xl p-6">
                  <LoadingCheckmark
                    size="sm"
                    stepDuration={800}
                    steps={[
                      { label: 'Fetching financial settings from Sage…', icon: Database },
                      { label: 'Reading ledger accounts & contacts…', icon: Building },
                      { label: 'Retrieving sales & purchase invoices…', icon: FileText },
                      { label: 'Compl-i AI analyzing compliance…', icon: Bot },
                    ]}
                  />
                </div>
              )}

              {error && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-red-400/10 border border-red-400/20 text-xs text-red-400">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  {error}
                </div>
              )}

              {/* AI Analysis Results */}
              {analysis && !analyzing && (
                <div className="space-y-4">
                  {/* Tabs */}
                  <div className="flex gap-1 p-1 bg-secondary rounded-lg">
                    {[
                      { key: 'overview', label: 'AI Analysis', icon: Bot },
                      { key: 'ledger', label: 'Ledger', icon: Database },
                      { key: 'invoices', label: 'Invoices', icon: FileText },
                      { key: 'bank', label: 'Bank', icon: Building },
                    ].map(tab => (
                      <button
                        key={tab.key}
                        onClick={() => setActiveTab(tab.key)}
                        className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-md text-xs font-medium transition-colors ${activeTab === tab.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                        <tab.icon className="w-3 h-3" /> {tab.label}
                      </button>
                    ))}
                  </div>

                  {activeTab === 'overview' && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                          <p className="text-xs text-muted-foreground">VAT Status</p>
                          <p className="text-sm font-medium text-foreground mt-0.5">{analysis.vat_status}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                          <p className="text-xs text-muted-foreground">Revenue Estimate</p>
                          <p className="text-sm font-medium text-foreground mt-0.5">{analysis.revenue_estimate}</p>
                        </div>
                      </div>

                      <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                        <p className="text-xs font-semibold text-primary flex items-center gap-1 mb-1">
                          <TrendingUp className="w-3 h-3" /> Financial Health
                        </p>
                        <p className="text-xs text-foreground">{analysis.financial_health}</p>
                      </div>

                      <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                        <p className="text-xs font-semibold text-primary flex items-center gap-1 mb-1">
                          <Shield className="w-3 h-3" /> Tax Compliance Notes
                        </p>
                        <p className="text-xs text-foreground">{analysis.tax_compliance_notes}</p>
                      </div>

                      <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                        <p className="text-xs font-semibold text-primary flex items-center gap-1 mb-1">
                          <FileText className="w-3 h-3" /> SARS Relevance
                        </p>
                        <p className="text-xs text-foreground">{analysis.sars_relevance}</p>
                      </div>

                      {analysis.risk_flags?.length > 0 && (
                        <div className="p-3 rounded-lg bg-red-400/5 border border-red-400/20">
                          <p className="text-xs font-semibold text-red-400 flex items-center gap-1 mb-2">
                            <AlertTriangle className="w-3 h-3" /> Risk Flags
                          </p>
                          <div className="space-y-1.5">
                            {analysis.risk_flags.map((flag, i) => (
                              <div key={i} className="flex items-start gap-2">
                                <span className="text-xs text-red-400 mt-0.5">•</span>
                                <p className="text-xs text-foreground">{flag}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {analysis.recommendations?.length > 0 && (
                        <div className="p-3 rounded-lg bg-green-400/5 border border-green-400/20">
                          <p className="text-xs font-semibold text-green-400 flex items-center gap-1 mb-2">
                            <CheckCircle className="w-3 h-3" /> AI Recommendations
                          </p>
                          <div className="space-y-1.5">
                            {analysis.recommendations.map((rec, i) => (
                              <div key={i} className="flex items-start gap-2">
                                <CheckCircle className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                                <p className="text-xs text-foreground">{rec}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {activeTab === 'ledger' && (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {ledgerAccounts.length > 0 ? ledgerAccounts.map((a, i) => (
                        <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-secondary/40">
                          <div>
                            <p className="text-xs font-medium text-foreground">{a.name}</p>
                            <p className="text-xs text-muted-foreground">{a.nominal_code || '—'}</p>
                          </div>
                          <span className="text-xs font-mono text-foreground">{a.balance ?? '—'}</span>
                        </div>
                      )) : <p className="text-xs text-muted-foreground text-center py-4">No ledger accounts found.</p>}
                    </div>
                  )}

                  {activeTab === 'invoices' && (
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                      <div>
                        <p className="text-xs font-semibold text-foreground mb-1">Sales Invoices ({salesInvoices.length})</p>
                        {salesInvoices.slice(0, 10).map((inv, i) => (
                          <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-secondary/40 mb-1">
                            <div>
                              <p className="text-xs font-medium text-foreground">{inv.reference || '—'} · {inv.contact_name || '—'}</p>
                              <p className="text-xs text-muted-foreground">Due: {inv.due_date || '—'}</p>
                            </div>
                            <span className="text-xs font-mono text-foreground">{inv.total_amount ?? '—'}</span>
                          </div>
                        ))}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-foreground mb-1">Purchase Invoices ({purchaseInvoices.length})</p>
                        {purchaseInvoices.slice(0, 10).map((inv, i) => (
                          <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-secondary/40 mb-1">
                            <div>
                              <p className="text-xs font-medium text-foreground">{inv.reference || '—'} · {inv.contact_name || '—'}</p>
                              <p className="text-xs text-muted-foreground">Due: {inv.due_date || '—'}</p>
                            </div>
                            <span className="text-xs font-mono text-foreground">{inv.total_amount ?? '—'}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === 'bank' && (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {bankAccounts.length > 0 ? bankAccounts.map((b, i) => (
                        <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-secondary/40">
                          <div>
                            <p className="text-xs font-medium text-foreground">{b.bank_account_name || '—'}</p>
                            <p className="text-xs text-muted-foreground">{b.account_number || '—'}</p>
                          </div>
                          <span className="text-xs font-mono text-foreground">{b.balance ?? '—'}</span>
                        </div>
                      )) : <p className="text-xs text-muted-foreground text-center py-4">No bank accounts found.</p>}
                      {contacts.length > 0 && (
                        <p className="text-xs text-muted-foreground text-center pt-2">{contacts.length} contacts in Sage</p>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Empty state when connected but not yet analyzed */}
              {!analysis && !analyzing && (
                <div className="text-center py-8">
                  <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: 'rgba(13,42,94,0.08)' }}>
                    <Bot className="w-7 h-7 text-primary" />
                  </div>
                  <p className="text-sm text-foreground font-medium mb-1">Ready to analyze your books</p>
                  <p className="text-xs text-muted-foreground mb-4">Compl-i Assistant will read your Sage financial data and provide compliance insights.</p>
                  <button
                    onClick={handleAnalyze}
                    className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium neon-glow hover:bg-primary/90 transition-colors">
                    <Bot className="w-4 h-4" /> Start AI Analysis
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-primary/20 flex items-center justify-between flex-shrink-0">
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Shield className="w-3 h-3" /> Read-only access · Token stored securely per user
          </p>
          <button onClick={onClose} className="text-xs text-muted-foreground hover:text-foreground">Close</button>
        </div>
      </div>
    </div>
  );
}