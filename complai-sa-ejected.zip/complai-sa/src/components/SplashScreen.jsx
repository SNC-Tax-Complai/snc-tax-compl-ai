import { useEffect, useState } from 'react';
import { Loader2, Globe, Bot, Shield } from 'lucide-react';
import SNCBrandLogo from './SNCBrandLogo';
import LoadingCheckmark from './LoadingCheckmark';

export default function SplashScreen({ onComplete }) {
  const [phase, setPhase] = useState('visible'); // visible → fadeout → done

  useEffect(() => {
    const t1 = setTimeout(() => setPhase('fadeout'), 2600);
    const t2 = setTimeout(() => onComplete(), 3200);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  if (phase === 'done') return null;

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center overflow-hidden"
      style={{
        transition: 'opacity 0.6s ease',
        opacity: phase === 'fadeout' ? 0 : 1,
        background: '#0d2a5e',
      }}
    >
      {/* Full-bleed marketing image */}
      <img
        src="/brand/splash-hero.png"
        alt="SNC-TAX team using Compl-Ai"
        className="absolute inset-0 w-full h-full object-cover object-center"
        style={{ opacity: 1 }}
      />

      {/* Overlay gradient for readability */}
      <div
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(to right, rgba(13,42,94,0.55) 0%, rgba(0,150,180,0.18) 100%)',
        }}
      />

      {/* Center branding overlay */}
      <div className="relative flex flex-col items-center gap-6 text-center">
        {/* SNC-TAX logo */}
        <img
          src="/brand/snc-logo.png"
          alt="SNC-TAX"
          className="h-12 w-auto object-contain"
          style={{ filter: 'brightness(0) invert(1)', opacity: 0.95 }}
        />
        <div className="w-px h-8 bg-white/30 mx-auto" />
        <SNCBrandLogo size="xl" showTagline={true} light={true} />
        <p className="text-white/60 text-xs tracking-widest uppercase mt-2">Loading your compliance dashboard…</p>
        <div className="mt-4 w-full max-w-xs">
          <LoadingCheckmark
            light={true}
            size="sm"
            stepDuration={550}
            steps={[
              { label: 'Initialising platform…', icon: Loader2 },
              { label: 'Fetching live compliance data…', icon: Globe },
              { label: 'AI preparing your dashboard…', icon: Bot },
              { label: 'Securing your session…', icon: Shield },
            ]}
          />
        </div>
      </div>

      {/* Bottom loading bar */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10">
        <div
          className="h-full bg-gradient-to-r from-cyan-400 to-teal-300"
          style={{
            animation: 'splashbar 2.4s ease-out forwards',
          }}
        />
      </div>

      {/* Powered-by footer */}
      <div className="absolute bottom-6 left-0 right-0 text-center">
        <p className="text-white/50 text-xs tracking-widest uppercase">Powered by SA-iLabs®™ · Compl-i Assistant™ · MAICP Protocol</p>
      </div>

      <style>{`
        @keyframes splashbar {
          from { width: 0%; }
          to   { width: 100%; }
        }
      `}</style>
    </div>
  );
}