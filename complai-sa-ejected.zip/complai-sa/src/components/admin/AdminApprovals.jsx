import { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Loader2, UserCheck } from 'lucide-react';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';

export default function AdminApprovals() {
  const { user } = useAuth();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState({});

  const load = async () => {
    try {
      const reqs = await api.entities.AdminApprovalRequest.list('-created_date', 50);
      setRequests(reqs);
    } catch (e) { console.error('Failed to load requests', e); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleApprove = async (req) => {
    setActionLoading(p => ({ ...p, [req.id]: true }));
    try {
      await api.entities.AdminApprovalRequest.update(req.id, {
        status: 'approved',
        approved_by: user?.email || 'admin',
        approved_date: new Date().toISOString(),
      });
      await api.users.inviteUser(req.email, 'admin');
      await api.integrations.Core.SendEmail({
        to: req.email,
        subject: '✅ Admin Access Approved — Compl-Ai™ SA',
        body: `Dear ${req.full_name},\n\nYour admin access request has been approved! You now have admin privileges on the Compl-Ai™ SA platform.\n\nPlease check your email for an invitation to set your password and log in at ${window.location.origin}/admin-login\n\nWelcome aboard!\nSA-iLabs®™ Team`,
      });
      load();
    } catch (e) { console.error('Approval failed', e); }
    setActionLoading(p => ({ ...p, [req.id]: false }));
  };

  const handleReject = async (req) => {
    setActionLoading(p => ({ ...p, [req.id]: true }));
    try {
      await api.entities.AdminApprovalRequest.update(req.id, {
        status: 'rejected',
        approved_by: user?.email || 'admin',
      });
      await api.integrations.Core.SendEmail({
        to: req.email,
        subject: 'Admin Access Request Update — Compl-Ai™ SA',
        body: `Dear ${req.full_name},\n\nWe regret to inform you that your admin access request was not approved at this time.\n\nIf you believe this is an error, please contact your administrator.\n\nSA-iLabs®™ Team`,
      });
      load();
    } catch (e) { console.error('Rejection failed', e); }
    setActionLoading(p => ({ ...p, [req.id]: false }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="w-6 h-6 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <UserCheck className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-gray-900 text-sm">Admin Access Requests</h2>
        </div>
        <span className="text-xs text-gray-400">{requests.filter(r => r.status === 'pending').length} pending</span>
      </div>
      <div className="divide-y divide-gray-50">
        {requests.length === 0 ? (
          <p className="py-8 text-center text-gray-400 text-sm">No admin requests yet.</p>
        ) : requests.map(req => (
          <div key={req.id} className="p-4 flex items-center justify-between gap-4">
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-900">{req.full_name}</p>
              <p className="text-xs text-gray-500">{req.email}</p>
              <p className="text-xs text-gray-400 mt-1">{req.motivation}</p>
              <p className="text-xs text-gray-300 mt-1">
                {req.created_date ? new Date(req.created_date).toLocaleDateString('en-ZA') : ''}
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {req.status === 'pending' ? (
                <>
                  <button onClick={() => handleApprove(req)} disabled={actionLoading[req.id]}
                    className="px-3 py-1.5 bg-green-500 text-white rounded-lg text-xs font-medium hover:bg-green-600 transition-colors disabled:opacity-50 flex items-center gap-1">
                    {actionLoading[req.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle className="w-3 h-3" />}
                    Approve
                  </button>
                  <button onClick={() => handleReject(req)} disabled={actionLoading[req.id]}
                    className="px-3 py-1.5 border border-red-200 text-red-500 rounded-lg text-xs font-medium hover:bg-red-50 transition-colors disabled:opacity-50 flex items-center gap-1">
                    <XCircle className="w-3 h-3" />
                    Reject
                  </button>
                </>
              ) : (
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${req.status === 'approved' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                  {req.status}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}