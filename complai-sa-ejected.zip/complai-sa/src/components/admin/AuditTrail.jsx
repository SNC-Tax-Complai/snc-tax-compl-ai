import { useState, useEffect } from 'react';
import { ScrollText, Loader2, CheckCircle, XCircle, FilePlus, Search } from 'lucide-react';
import { api } from '@/api/apiClient';

const actionConfig = {
  created: { icon: FilePlus, color: 'text-blue-500', bg: 'bg-blue-50', border: 'border-blue-200', label: 'Request Created' },
  approved: { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-50', border: 'border-green-200', label: 'Approved' },
  rejected: { icon: XCircle, color: 'text-red-500', bg: 'bg-red-50', border: 'border-red-200', label: 'Rejected' },
};

export default function AuditTrail() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const load = async () => {
    try {
      const entries = await api.entities.AuditLog.list('-created_date', 200);
      setLogs(entries);
    } catch (e) {
      console.error('Failed to load audit logs', e);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
    const unsub = api.entities.AuditLog.subscribe(() => load());
    return () => unsub();
  }, []);

  const filtered = logs.filter(l => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      (l.actor_email || '').toLowerCase().includes(q) ||
      (l.target_email || '').toLowerCase().includes(q) ||
      (l.target_name || '').toLowerCase().includes(q) ||
      (l.details || '').toLowerCase().includes(q) ||
      (l.action_type || '').toLowerCase().includes(q)
    );
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="w-6 h-6 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        {['created', 'approved', 'rejected'].map(type => {
          const cfg = actionConfig[type];
          const count = logs.filter(l => l.action_type === type).length;
          const Icon = cfg.icon;
          return (
            <div key={type} className={`bg-white rounded-xl border ${cfg.border} p-4 shadow-sm`}>
              <div className="flex items-center gap-2 mb-2">
                <div className={`p-1.5 rounded-lg ${cfg.bg}`}>
                  <Icon className={`w-4 h-4 ${cfg.color}`} />
                </div>
                <p className="text-xs text-gray-400">{cfg.label}</p>
              </div>
              <p className={`text-2xl font-bold font-grotesk ${cfg.color}`}>{count}</p>
            </div>
          );
        })}
      </div>

      {/* Audit log table */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-gray-100 gap-4">
          <div className="flex items-center gap-2">
            <ScrollText className="w-4 h-4 text-primary" />
            <h2 className="font-semibold text-gray-900 text-sm">Admin Audit Trail</h2>
            <div className="flex items-center gap-1.5 text-xs text-green-600 ml-2">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              Real-time
            </div>
          </div>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search audit logs…"
              className="pl-9 pr-3 py-1.5 text-xs bg-gray-50 rounded-lg border border-gray-200 focus:border-primary/50 outline-none w-48 sm:w-64"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[800px]">
            <thead>
              <tr className="border-b border-gray-100">
                {['Action', 'Actor (Admin)', 'Target User', 'Status Change', 'Details', 'Timestamp'].map(h => (
                  <th key={h} className="text-left py-3 px-4 text-xs text-gray-400 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-gray-400 text-sm">
                    {search ? 'No matching audit entries.' : 'No audit entries yet. Admin actions on approval requests will appear here.'}
                  </td>
                </tr>
              ) : filtered.map(log => {
                const cfg = actionConfig[log.action_type] || actionConfig.created;
                const Icon = cfg.icon;
                return (
                  <tr key={log.id} className="hover:bg-gray-50 transition-colors">
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center gap-1.5 text-xs px-2 py-1 rounded-full font-medium ${cfg.bg} ${cfg.color}`}>
                        <Icon className="w-3 h-3" />
                        {cfg.label}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-700 text-xs font-mono">{log.actor_email || '—'}</td>
                    <td className="py-3 px-4">
                      <p className="text-xs font-medium text-gray-900">{log.target_name || '—'}</p>
                      <p className="text-xs text-gray-400">{log.target_email || '—'}</p>
                    </td>
                    <td className="py-3 px-4 text-xs">
                      {log.previous_status ? (
                        <span className="flex items-center gap-1.5">
                          <span className="text-gray-400">{log.previous_status}</span>
                          <span className="text-gray-300">→</span>
                          <span className={cfg.color + ' font-medium'}>{log.new_status}</span>
                        </span>
                      ) : (
                        <span className="text-gray-400">— (new)</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-xs text-gray-500 max-w-xs truncate" title={log.details}>{log.details || '—'}</td>
                    <td className="py-3 px-4 text-xs text-gray-400 font-mono whitespace-nowrap">
                      {log.created_date ? new Date(log.created_date).toLocaleString('en-ZA', { dateStyle: 'short', timeStyle: 'short' }) : '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length > 0 && (
          <div className="p-3 border-t border-gray-100 text-xs text-gray-400 text-center">
            Showing {filtered.length} of {logs.length} audit entries
          </div>
        )}
      </div>
    </div>
  );
}