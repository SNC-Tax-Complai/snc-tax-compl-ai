import { useState } from 'react';
import { Download, Loader2, FileText, Calendar } from 'lucide-react';
import { api } from '@/api/apiClient';

export default function AuditorSummaryPanel() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const now = new Date();
  const monthLabel = now.toLocaleString('en-ZA', { month: 'long', year: 'numeric' });

  const handleDownload = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.functions.invoke('generateAuditorSummary', {});
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ComplAi-Auditor-Summary-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (e) {
      setError('Failed to generate report. ' + (e.message || 'Please try again.'));
    }
    setLoading(false);
  };

  return (
    <div className="glass-card rounded-2xl p-6 border border-border mb-6">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <FileText className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="font-grotesk font-semibold text-foreground">Monthly Compliance Summary Report</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Generate a downloadable PDF summarising compliance data across all onboarded clients for {monthLabel}.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
        {[
          { label: 'Portfolio overview & KPIs', icon: '📊' },
          { label: 'Average module scores', icon: '📈' },
          { label: 'Per-client breakdown', icon: '📋' },
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-2 p-2.5 rounded-lg bg-secondary/40 border border-border">
            <span className="text-sm">{item.icon}</span>
            <span className="text-xs text-muted-foreground">{item.label}</span>
          </div>
        ))}
      </div>

      {error && (
        <div className="mb-3 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-600">
          {error}
        </div>
      )}

      <button
        onClick={handleDownload}
        disabled={loading}
        className={`flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-medium transition-all ${
          loading
            ? 'bg-secondary text-muted-foreground cursor-not-allowed'
            : 'text-white neon-glow hover:opacity-90'
        }`}
        style={!loading ? { background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' } : {}}
      >
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
        {loading ? 'Generating PDF…' : `Download ${monthLabel} Summary`}
      </button>

      <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
        <Calendar className="w-3 h-3" />
        Report includes all BusinessProfile records with onboarding completed.
      </p>
    </div>
  );
}