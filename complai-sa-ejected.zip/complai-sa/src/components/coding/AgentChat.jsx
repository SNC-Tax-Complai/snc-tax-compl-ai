import { useState, useEffect, useRef } from 'react';
import { Send, Loader2, MessageSquare, Plus, Bot } from 'lucide-react';
import { api } from '@/api/apiClient';
import MessageBubble from '@/components/coding/MessageBubble';

export default function AgentChat() {
  const [conversations, setConversations] = useState([]);
  const [currentConv, setCurrentConv] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    if (!currentConv?.id) return;
    const unsubscribe = api.agents.subscribeToConversation(currentConv.id, (data) => {
      setMessages(data.messages || []);
    });
    return () => unsubscribe();
  }, [currentConv?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadConversations = async () => {
    try {
      const convs = await api.agents.listConversations({ agent_name: 'coding_agent' });
      setConversations(convs);
      if (convs.length > 0) {
        const latest = convs[0];
        setCurrentConv(latest);
        setMessages(latest.messages || []);
      } else {
        const conv = await api.agents.createConversation({
          agent_name: 'coding_agent',
          metadata: { name: 'New Session' },
        });
        setConversations([conv]);
        setCurrentConv(conv);
        setMessages([]);
      }
    } catch (e) {
      console.error('Failed to load conversations', e);
    }
    setLoading(false);
  };

  const handleNewConversation = async () => {
    try {
      const conv = await api.agents.createConversation({
        agent_name: 'coding_agent',
        metadata: { name: `Session ${new Date().toLocaleString('en-ZA')}` },
      });
      setConversations(prev => [conv, ...prev]);
      setCurrentConv(conv);
      setMessages([]);
    } catch (e) {
      console.error('Failed to create conversation', e);
    }
  };

  const handleSelectConversation = (conv) => {
    setCurrentConv(conv);
    setMessages(conv.messages || []);
  };

  const handleSend = async () => {
    if (!input.trim() || !currentConv || sending) return;
    const content = input.trim();
    setInput('');
    setSending(true);
    try {
      await api.agents.addMessage(currentConv, { role: 'user', content });
    } catch (e) {
      console.error('Failed to send message', e);
    }
    setSending(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-950">
        <Loader2 className="w-6 h-6 text-cyan-400 animate-spin" />
      </div>
    );
  }

  return (
    <div className="h-full flex bg-gray-950">
      {/* Conversation list sidebar */}
      <div className="w-48 border-r border-gray-800 flex flex-col flex-shrink-0">
        <button onClick={handleNewConversation}
          className="flex items-center gap-2 px-3 py-2.5 m-2 rounded-lg text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-700 transition-colors">
          <Plus className="w-3.5 h-3.5" /> New Chat
        </button>
        <div className="flex-1 overflow-y-auto px-2 space-y-1">
          {conversations.map(conv => (
            <button key={conv.id} onClick={() => handleSelectConversation(conv)}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs transition-colors text-left ${
                currentConv?.id === conv.id ? 'bg-gray-800 text-white' : 'text-gray-400 hover:bg-gray-800/50'
              }`}>
              <MessageSquare className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{conv.metadata?.name || 'Untitled'}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
                style={{ background: 'rgba(19,181,234,0.1)' }}>
                <Bot className="w-8 h-8 text-cyan-400" />
              </div>
              <h3 className="text-white font-grotesk font-semibold mb-1">SA-iLabs™ Coding Agent</h3>
              <p className="text-gray-500 text-sm max-w-xs">
                Ask me about code changes, compliance logic, data models, or feature planning for Compl-Ai™ SA.
              </p>
            </div>
          ) : (
            messages.map((msg, i) => (
              <MessageBubble key={i} message={msg} />
            ))
          )}
          {sending && (
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-400" />
              SA-iLabs™ Agent is thinking…
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-3 border-t border-gray-800 flex-shrink-0">
          <div className="flex gap-2 items-end">
            <textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Describe a code change or ask about the platform…"
              rows={1}
              className="flex-1 bg-gray-800 rounded-lg px-3 py-2.5 text-sm text-white border border-gray-700 focus:border-cyan-500 outline-none resize-none"
              style={{ minHeight: '40px', maxHeight: '120px' }}
            />
            <button onClick={handleSend} disabled={!input.trim() || sending}
              className="p-2.5 rounded-lg text-white transition-colors disabled:opacity-40"
              style={{ background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' }}>
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}