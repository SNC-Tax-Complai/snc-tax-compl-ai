import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { CheckCircle, Loader2, AlertTriangle, ChevronDown, ChevronUp, Wrench } from 'lucide-react';

const statusMap = {
  pending: { icon: Loader2, color: 'text-yellow-400', label: 'Pending', spin: true },
  running: { icon: Loader2, color: 'text-blue-400', label: 'Running', spin: true },
  in_progress: { icon: Loader2, color: 'text-blue-400', label: 'In Progress', spin: true },
  completed: { icon: CheckCircle, color: 'text-green-400', label: 'Completed' },
  success: { icon: CheckCircle, color: 'text-green-400', label: 'Success' },
  failed: { icon: AlertTriangle, color: 'text-red-400', label: 'Failed' },
  error: { icon: AlertTriangle, color: 'text-red-400', label: 'Error' },
};

function ToolCallDisplay({ toolCall }) {
  const [expanded, setExpanded] = useState(false);
  const rawStatus = toolCall.status || 'pending';
  const status = statusMap[rawStatus] || statusMap.pending;
  const StatusIcon = status.icon;
  const isFailed = rawStatus === 'failed' || rawStatus === 'error';

  let parsedResults = toolCall.results;
  try {
    if (typeof toolCall.results === 'string') parsedResults = JSON.parse(toolCall.results);
  } catch {}

  let parsedArgs = toolCall.arguments_string;
  try {
    if (typeof toolCall.arguments_string === 'string') parsedArgs = JSON.stringify(JSON.parse(toolCall.arguments_string), null, 2);
  } catch {}

  const hideDetails = toolCall.display_projection?.hide_details && toolCall.display_projection?.details_redacted;

  return (
    <div className="mt-2 text-xs">
      <button
        onClick={() => !hideDetails && setExpanded(!expanded)}
        className={`flex items-center gap-1.5 ${hideDetails ? 'cursor-default' : 'cursor-pointer hover:bg-gray-800/50'} rounded px-1.5 py-0.5 -mx-1.5`}
      >
        <StatusIcon className={`w-3 h-3 ${status.color} ${status.spin ? 'animate-spin' : ''}`} />
        <span className={`font-medium ${status.color}`}>{toolCall.name || 'Tool'}</span>
        <span className="text-gray-500">
          {hideDetails
            ? (isFailed ? (toolCall.display_projection?.error_label || 'Failed') : (toolCall.display_projection?.active_label || status.label))
            : status.label}
        </span>
        {!hideDetails && (expanded ? <ChevronUp className="w-3 h-3 text-gray-500" /> : <ChevronDown className="w-3 h-3 text-gray-500" />)}
      </button>
      {expanded && !hideDetails && (
        <div className="mt-1.5 space-y-2 pl-3 border-l border-gray-700">
          {toolCall.arguments_string && (
            <div>
              <p className="text-gray-500 font-medium mb-0.5">Parameters:</p>
              <pre className="bg-gray-800 rounded p-2 text-gray-300 overflow-x-auto text-xs">{parsedArgs}</pre>
            </div>
          )}
          {parsedResults != null && (
            <div>
              <p className="text-gray-500 font-medium mb-0.5">Result:</p>
              <pre className="bg-gray-800 rounded p-2 text-gray-300 overflow-x-auto text-xs">
                {typeof parsedResults === 'string' ? parsedResults : JSON.stringify(parsedResults, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function MessageBubble({ message }) {
  const isUser = message.role === 'user';

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[85%] rounded-lg p-3 ${
        isUser
          ? 'text-white'
          : 'bg-gray-800 text-gray-100'
      }`} style={isUser ? { background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' } : {}}>
        {message.content && (
          isUser
            ? <p className="text-sm whitespace-pre-wrap">{message.content}</p>
            : <div className="text-sm prose prose-sm prose-invert max-w-none"><ReactMarkdown>{message.content}</ReactMarkdown></div>
        )}
        {message.tool_calls?.map((tc, i) => <ToolCallDisplay key={i} toolCall={tc} />)}
      </div>
    </div>
  );
}