import { useState } from 'react';
import { Globe, RefreshCw, ExternalLink, Smartphone, Monitor } from 'lucide-react';

export default function PreviewPanel() {
  const [refreshKey, setRefreshKey] = useState(0);
  const [device, setDevice] = useState('desktop');

  return (
    <div className="h-full flex flex-col bg-gray-900">
      {/* URL bar */}
      <div className="flex items-center gap-2 px-3 h-10 bg-gray-950 border-b border-gray-800 flex-shrink-0">
        <div className="flex-1 flex items-center gap-2 bg-gray-800 rounded px-3 py-1.5">
          <Globe className="w-3 h-3 text-gray-500 flex-shrink-0" />
          <span className="text-xs text-gray-400 truncate">{window.location.origin}</span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setDevice(device === 'desktop' ? 'mobile' : 'desktop')}
            className="p-1.5 text-gray-400 hover:text-white rounded transition-colors" title="Toggle device">
            {device === 'desktop' ? <Smartphone className="w-3.5 h-3.5" /> : <Monitor className="w-3.5 h-3.5" />}
          </button>
          <button onClick={() => setRefreshKey(k => k + 1)}
            className="p-1.5 text-gray-400 hover:text-white rounded transition-colors" title="Refresh preview">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <a href={window.location.origin} target="_blank" rel="noopener noreferrer"
            className="p-1.5 text-gray-400 hover:text-white rounded transition-colors" title="Open in new tab">
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* iframe */}
      <div className="flex-1 flex items-center justify-center bg-gray-800 overflow-hidden">
        <div
          className={device === 'mobile' ? 'h-full bg-white shadow-2xl' : 'w-full h-full bg-white'}
          style={device === 'mobile' ? { width: '375px', maxWidth: '100%' } : {}}
        >
          <iframe
            key={refreshKey}
            src={window.location.origin}
            className="w-full h-full border-0"
            title="Live App Preview"
          />
        </div>
      </div>
    </div>
  );
}