import { useState, useRef } from 'react';
import {
  Upload, FileText, X, Loader2, Sparkles, CheckCircle,
  AlertTriangle, CloudUpload, Trash2,
} from 'lucide-react';
import { api } from '@/api/apiClient';
import LoadingCheckmark from '@/components/LoadingCheckmark';

const categories = ['SARS', 'CIPC', 'COIDA', 'B-BBEE', 'OHS', 'FICA', 'Labour', 'POPIA', 'Municipal', 'Other'];

// file status: 'queued' | 'analyzing' | 'analyzed' | 'error' | 'uploading' | 'done'
function FileEntry({ entry, onUpdate, onRemove }) {
  const s = entry.status;

  return (
    <div className="rounded-xl border border-primary/15 bg-white p-4 space-y-3">
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-lg bg-primary/5 flex-shrink-0">
          <FileText className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground truncate">{entry.file.name}</p>
          <p className="text-xs text-muted-foreground">{(entry.file.size / 1024).toFixed(0)} KB</p>
        </div>
        {s !== 'uploading' && s !== 'done' && (
          <button onClick={() => onRemove(entry.id)} className="p-1.5 text-muted-foreground hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors flex-shrink-0">
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {s === 'analyzing' && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="w-3.5 h-3.5 animate-spin text-primary flex-shrink-0" />
          Compl-i OCR scanning & extracting metadata…
        </div>
      )}

      {s === 'error' && (
        <div className="flex items-center gap-2 text-xs text-red-400">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
          {entry.error || 'Analysis failed. You can still upload with manual details.'}
        </div>
      )}

      {(s === 'analyzed' || s === 'error') && (
        <>
          {entry.suggestion && s === 'analyzed' && (
            <div className="p-2.5 bg-primary/5 border border-primary/20 rounded-lg space-y-1">
              <p className="text-xs font-medium text-primary flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Auto-detected
              </p>
              <p className="text-xs text-foreground">{entry.suggestion.description}</p>
              <div className="flex flex-wrap gap-1">
                {entry.suggestion.tags?.map((t, i) => (
                  <span key={i} className="text-xs px-1.5 py-0.5 bg-primary/10 text-primary border border-primary/20 rounded-full">{t}</span>
                ))}
              </div>
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Category</label>
              <select
                value={entry.form.category}
                onChange={e => onUpdate(entry.id, { form: { ...entry.form, category: e.target.value } })}
                className="w-full bg-secondary rounded-lg px-2.5 py-2 text-xs text-foreground border border-primary/20 focus:border-primary/50 outline-none">
                <option value="">Select…</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Expiry (optional)</label>
              <input
                type="date"
                value={entry.form.expires}
                onChange={e => onUpdate(entry.id, { form: { ...entry.form, expires: e.target.value } })}
                className="w-full bg-secondary rounded-lg px-2.5 py-2 text-xs text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
            </div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Tags (comma-separated)</label>
            <input
              value={entry.form.tags}
              onChange={e => onUpdate(entry.id, { form: { ...entry.form, tags: e.target.value } })}
              placeholder="e.g. SARS, Tax, Certificate"
              className="w-full bg-secondary rounded-lg px-2.5 py-2 text-xs text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
          </div>
        </>
      )}

      {s === 'uploading' && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="w-3.5 h-3.5 animate-spin text-primary flex-shrink-0" />
          Saving to vault…
        </div>
      )}

      {s === 'done' && (
        <div className="flex items-center gap-2 text-xs text-green-400">
          <CheckCircle className="w-3.5 h-3.5 flex-shrink-0" />
          Uploaded & saved
        </div>
      )}
    </div>
  );
}

export default function MultiFileUpload({ onClose, onComplete, businessProfileId, userId }) {
  const [entries, setEntries] = useState([]);
  const [dragging, setDragging] = useState(false);
  const [bulkUploading, setBulkUploading] = useState(false);
  const fileRef = useRef();
  const idCounter = useRef(0);

  const analyzeFile = async (entry) => {
    onUpdate(entry.id, { status: 'analyzing' });
    try {
      const f = entry.file;
      let fileUrl = null;
      const isPdfOrImage = /\.(pdf|png|jpg|jpeg)$/i.test(f.name);
      if (isPdfOrImage) {
        const uploaded = await api.integrations.Core.UploadFile({ file: f });
        fileUrl = uploaded.file_url;
      }
      const result = await api.integrations.Core.InvokeLLM({
        prompt: `You are a South African compliance document specialist with OCR capability.
${fileUrl ? `Analyse the attached compliance document and extract all visible metadata.` : `A user is uploading: "${f.name}" (${(f.size / 1024).toFixed(0)} KB).`}
Extract: 1) Document category (from: ${categories.join(', ')}), 2) Issuing authority (SARS/CIPC/DoL/InfoReg/DTIC/etc), 3) Expiry or renewal date (YYYY-MM-DD or null), 4) Reference/certificate number (or null), 5) Entity name on document (or null), 6) 3-5 compliance tags, 7) One-sentence description, 8) Verification status — set to "verified" if the document is complete, valid, not expired, and all critical fields (reference number, entity name, dates) are legible and present; set to "needs_action" if the document is expired, incomplete, illegible, has discrepancies, or is missing critical information. Return JSON only.`,
        file_urls: fileUrl ? [fileUrl] : undefined,
        response_json_schema: {
          type: 'object',
          properties: {
            category: { type: 'string' },
            issuing_authority: { type: 'string' },
            expiry_date: { type: 'string' },
            reference_number: { type: 'string' },
            entity_name: { type: 'string' },
            tags: { type: 'array', items: { type: 'string' } },
            description: { type: 'string' },
            verification_status: { type: 'string' },
          },
        },
      });
      onUpdate(entry.id, {
        status: 'analyzed',
        suggestion: { ...result, _fileUrl: fileUrl },
        form: {
          category: result.category || '',
          tags: result.tags?.join(', ') || '',
          expires: result.expiry_date || '',
        },
      });
    } catch (e) {
      onUpdate(entry.id, { status: 'error', error: e.message });
    }
  };

  const addFiles = (fileList) => {
    const newFiles = Array.from(fileList);
    const newEntries = newFiles.map(f => ({
      id: `f${++idCounter.current}`,
      file: f,
      status: 'queued',
      suggestion: null,
      form: { category: '', expires: '', tags: '' },
      error: null,
    }));
    setEntries(prev => [...prev, ...newEntries]);
    // kick off analysis sequentially to avoid rate limits
    newEntries.reduce(async (chain, entry) => {
      await chain;
      await analyzeFile(entry);
    }, Promise.resolve());
  };

  const onUpdate = (id, patch) => {
    setEntries(prev => prev.map(e => e.id === id ? { ...e, ...patch } : e));
  };

  const onRemove = (id) => {
    setEntries(prev => prev.filter(e => e.id !== id));
  };

  const handleDragOver = (e) => { e.preventDefault(); setDragging(true); };
  const handleDragLeave = (e) => { e.preventDefault(); setDragging(false); };
  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files.length > 0) addFiles(e.dataTransfer.files);
  };

  const allAnalyzed = entries.length > 0 && entries.every(e => e.status === 'analyzed' || e.status === 'error' || e.status === 'done');
  const hasPending = entries.some(e => e.status === 'queued' || e.status === 'analyzing' || e.status === 'uploading');

  const handleBulkUpload = async () => {
    setBulkUploading(true);
    const created = [];
    for (const entry of entries) {
      if (entry.status === 'done') continue;
      onUpdate(entry.id, { status: 'uploading' });
      try {
        const file_url = entry.suggestion?._fileUrl || (await api.integrations.Core.UploadFile({ file: entry.file })).file_url;
        const tags = entry.form.tags.split(',').map(t => t.trim()).filter(Boolean);
        const doc = await api.entities.ComplianceDocument.create({
          user_id: userId,
          business_profile_id: businessProfileId,
          document_type: entry.form.category || 'Other',
          document_name: entry.file.name,
          file_url,
          ai_extracted_data: JSON.stringify({
            issuing_authority: entry.suggestion?.issuing_authority || null,
            reference_number: entry.suggestion?.reference_number || null,
            entity_name: entry.suggestion?.entity_name || null,
            tags,
            description: entry.suggestion?.description || null,
            expires: entry.form.expires || null,
          }),
          status: entry.suggestion ? (entry.suggestion.verification_status === 'needs_action' ? 'needs_action' : 'verified') : 'pending',
        });
        created.push(doc);
        onUpdate(entry.id, { status: 'done' });
      } catch (e) {
        onUpdate(entry.id, { status: 'error', error: e.message });
      }
    }
    setBulkUploading(false);
    if (created.length > 0) {
      onComplete(created);
    }
    // close only if no errors remain
    if (!entries.some(e => e.status === 'error')) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-2xl glass-card rounded-2xl border border-primary/20 neon-glow animate-slide-up max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-primary/20 flex-shrink-0">
          <h2 className="font-grotesk font-semibold text-foreground flex items-center gap-2">
            <CloudUpload className="w-4 h-4 text-primary" /> Bulk Upload Documents
          </h2>
          <button onClick={onClose}><X className="w-4 h-4 text-muted-foreground hover:text-foreground" /></button>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Drop zone */}
          <div
            onClick={() => fileRef.current.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${dragging ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/40 hover:bg-secondary/50'}`}>
            <input
              ref={fileRef}
              type="file"
              multiple
              className="hidden"
              onChange={e => { if (e.target.files.length > 0) addFiles(e.target.files); e.target.value = ''; }}
            />
            <CloudUpload className={`w-10 h-10 mx-auto mb-2 ${dragging ? 'text-primary' : 'text-muted-foreground'}`} />
            <p className="text-sm text-muted-foreground">
              {dragging ? 'Drop files here…' : <>Drag & drop multiple files or <span className="text-primary">browse</span></>}
            </p>
            <p className="text-xs text-muted-foreground mt-1">PDF, PNG, JPG, DOCX supported — Compl-i OCR will auto-detect each</p>
          </div>

          {/* File list */}
          {entries.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-muted-foreground">{entries.length} file{entries.length !== 1 ? 's' : ''} queued</p>
                <button
                  onClick={() => setEntries([])}
                  className="text-xs text-muted-foreground hover:text-red-400 flex items-center gap-1">
                  <Trash2 className="w-3 h-3" /> Clear all
                </button>
              </div>
              {entries.map(entry => (
                <FileEntry key={entry.id} entry={entry} onUpdate={onUpdate} onRemove={onRemove} />
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex gap-2 p-5 border-t border-primary/20 flex-shrink-0">
          <button onClick={onClose} className="flex-1 py-2.5 border border-border text-muted-foreground rounded-xl text-sm hover:bg-secondary transition-colors">
            Cancel
          </button>
          <button
            onClick={handleBulkUpload}
            disabled={entries.length === 0 || !allAnalyzed || bulkUploading}
            className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium neon-glow hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
            {bulkUploading
              ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Saving…</>
              : <><Upload className="w-3.5 h-3.5" /> Upload {entries.length || ''} Document{entries.length !== 1 ? 's' : ''}</>}
          </button>
        </div>
      </div>
    </div>
  );
}