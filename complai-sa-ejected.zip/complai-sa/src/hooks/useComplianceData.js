import { useState, useEffect, useCallback } from 'react';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';

/**
 * Loads the logged-in user's BusinessProfile and ComplianceDocuments.
 * Provides helper to derive checklist item status from module score + uploaded docs.
 */
export function useComplianceData() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadAll = useCallback(async () => {
    if (!user?.id) { setLoading(false); return; }
    setLoading(true);
    setError(null);
    try {
      const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
      const p = profiles.length > 0 ? profiles[0] : null;
      setProfile(p);

      if (p) {
        const docs = await api.entities.ComplianceDocument.filter({ business_profile_id: p.id });
        setDocuments(docs);
      } else {
        setDocuments([]);
      }
    } catch (e) {
      console.error('useComplianceData error', e);
      setError(e);
    }
    setLoading(false);
  }, [user?.id]);

  useEffect(() => { loadAll(); }, [loadAll]);

  /**
   * Derive checklist status from a module score (0-100) and whether docs of that category exist.
   * Returns 'done' | 'pending' | 'urgent'
   */
  const deriveStatus = useCallback((moduleScore, docCategory, threshold = 60) => {
    const score = moduleScore ?? 0;
    const hasDoc = docCategory
      ? documents.some(d => (d.document_type || '').toLowerCase().includes(docCategory.toLowerCase()) ||
                            (d.document_name || '').toLowerCase().includes(docCategory.toLowerCase()))
      : false;
    if (score >= threshold) return 'done';
    if (score > 0 || hasDoc) return 'pending';
    return 'urgent';
  }, [documents]);

  return { profile, documents, loading, error, reload: loadAll, deriveStatus };
}