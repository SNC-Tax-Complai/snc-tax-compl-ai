import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Shield, Users, Building, FileText, LogOut, RefreshCw, AlertTriangle,
  CheckCircle, Power, PowerOff, Trash2, Plus, BarChart2, Settings,
  Bell, Eye, Download, Lock, Activity, ChevronDown, Loader2,
  CreditCard, Globe, Palette, Database, Code, UserCheck, ScrollText
} from 'lucide-react';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import SNCBrandLogo from '@/components/SNCBrandLogo';
import AdminApprovals from '@/components/admin/AdminApprovals';
import AuditTrail from '@/components/admin/AuditTrail';

const ALLOWED_DOMAINS = ['snctax.co.za', 'snatax.co.za', 'sa-ilabs.co.za'];
const SUDO_ADMINS = ['wernerbotha199@gmail.com', 'sudo@sudo.com'];

const inputCls = "w-full bg-gray-50 rounded-lg px-3 py-2.5 text-sm text-gray-900 border border-gray-200 focus:border-primary/50 outline-none";

// ── Real-time stats from entities ──────────────────────────────────────────
function useRealTimeStats() {
  const [stats, setStats] = useState({ profiles: 0, docs: 0, avgScore: 0, highRisk: 0, pending: 0, loading: true });

  const load = async () => {
    try {
      const [profiles, docs] = await Promise.all([
        api.entities.BusinessProfile.list('-created_date', 200),
        api.entities.ComplianceDocument.list('-created_date', 500),
      ]);
      const complete = profiles.filter(p => p.onboarding_complete);
      const scores = complete.map(p => p.compliance_score || 0).filter(Boolean);
      const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
      const highRisk = complete.filter(p => p.risk_level === 'High').length;
      const pending = docs.filter(d => d.status === 'pending').length;
      setStats({ profiles: complete.length, docs: docs.length, avgScore: avg, highRisk, pending, loading: false, raw: profiles });
    } catch {
      setStats(s => ({ ...s, loading: false }));
    }
  };

  useEffect(() => {
    load();
    // Subscribe for real-time updates
    const unsubP = api.entities.BusinessProfile.subscribe(() => load());
    const unsubD = api.entities.ComplianceDocument.subscribe(() => load());
    return () => { unsubP(); unsubD(); };
  }, []);

  return { stats, reload: load };
}

// ── Business Profile table ──────────────────────────────────────────────────
function ClientTable({ profiles }) {
  const riskColor = { Low: 'text-green-600 bg-green-50', Medium: 'text-yellow-600 bg-yellow-50', High: 'text-red-600 bg-red-50' };
  if (!profiles?.length) return <p className="text-sm text-gray-400 py-6 text-center">No client profiles yet.</p>;

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm min-w-[700px]">
        <thead>
          <tr className="border-b border-gray-100">
            {['Business', 'Entity Type', 'Industry', 'Province', 'Score', 'Risk', 'Documents', 'Registered'].map(h => (
              <th key={h} className="text-left py-3 px-3 text-xs text-gray-400 font-medium">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {profiles.map(p => (
            <tr key={p.id} className="hover:bg-gray-50 transition-colors">
              <td className="py-3 px-3 font-medium text-gray-900">{p.entity_name || '—'}</td>
              <td className="py-3 px-3 text-gray-500 text-xs">{p.entity_type || '—'}</td>
              <td className="py-3 px-3 text-gray-500 text-xs">{p.industry || '—'}</td>
              <td className="py-3 px-3 text-gray-500 text-xs">{p.province || '—'}</td>
              <td className="py-3 px-3">
                <span className="font-bold text-primary">{p.compliance_score ?? '—'}%</span>
              </td>
              <td className="py-3 px-3">
                {p.risk_level ? (
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${riskColor[p.risk_level] || 'text-gray-500 bg-gray-100'}`}>
                    {p.risk_level}
                  </span>
                ) : '—'}
              </td>
              <td className="py-3 px-3 text-gray-500 text-xs">{p.pending_filings ?? 0} pending</td>
              <td className="py-3 px-3 text-gray-400 text-xs font-mono">
                {p.created_date ? new Date(p.created_date).toLocaleDateString('en-ZA') : '—'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────
export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('overview');
  const [accessDenied, setAccessDenied] = useState(false);
  const [checking, setChecking] = useState(true);
  const { stats, reload } = useRealTimeStats();

  // Auth gate — check SNC email or admin role
  useEffect(() => {
    const check = async () => {
      try {
        const me = await api.auth.me();
        if (!me) { navigate('/admin-login'); return; }
        const domain = me.email?.split('@')[1]?.toLowerCase();
        const allowed = ALLOWED_DOMAINS.includes(domain) || me.role === 'admin' || me.role === 'sudo' || SUDO_ADMINS.includes(me.email?.toLowerCase());
        if (!allowed) setAccessDenied(true);
      } catch {
        navigate('/admin-login');
      }
      setChecking(false);
    };
    check();
  }, []);

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0d2a5e' }}>
        <Loader2 className="w-8 h-8 text-white animate-spin" />
      </div>
    );
  }

  if (accessDenied) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: '#0d2a5e' }}>
        <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-sm text-gray-500 mb-6">
            Your account (<strong>{user?.email}</strong>) is not authorised to access the Admin Portal.<br /><br />
            Only SNC-TAX staff with <strong>@snctax.co.za</strong> email addresses or users assigned the <strong>Admin role</strong> may enter.
          </p>
          <button onClick={() => logout()} className="w-full py-2.5 bg-red-500 text-white rounded-xl text-sm font-medium hover:bg-red-600 transition-colors">
            Sign Out
          </button>
          <Link to="/" className="block mt-3 text-sm text-primary hover:underline">← Back to App</Link>
        </div>
      </div>
    );
  }

  const TABS = [
    { key: 'overview', label: 'Overview', icon: BarChart2 },
    { key: 'clients', label: 'Client Profiles', icon: Users },
    { key: 'documents', label: 'Document Vault', icon: FileText },
    { key: 'whitelabel', label: 'White-Label', icon: Globe },
    { key: 'approvals', label: 'Admin Requests', icon: UserCheck },
    { key: 'audit', label: 'Audit Trail', icon: ScrollText },
    { key: 'coding', label: 'Coding Agent', icon: Code },
    { key: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40" style={{ boxShadow: '0 2px 12px rgba(13,42,94,0.08)' }}>
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <SNCBrandLogo size="sm" showTagline={false} light={false} />
            <span className="px-2 py-0.5 text-xs font-semibold rounded-full"
              style={{ background: 'rgba(13,42,94,0.08)', color: '#0d2a5e' }}>
              🔐 Admin Portal
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-gray-500 hidden sm:block">Live · {user?.full_name || user?.email}</span>
            </div>
            <button
              onClick={reload}
              className="p-2 rounded-lg text-gray-400 hover:text-primary hover:bg-primary/5 transition-colors"
              title="Refresh data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <Link to="/" className="text-xs text-gray-400 hover:text-primary transition-colors hidden sm:block">
              ← Client App
            </Link>
            <button
              onClick={() => logout()}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-red-200 text-red-500 rounded-lg text-xs font-medium hover:bg-red-50 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" /> Sign Out
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Hero */}
        <div
          className="relative overflow-hidden rounded-2xl p-6 text-white"
          style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #1a3a6e 60%, #13b5ea 100%)' }}
        >
          <div className="absolute top-0 right-0 w-56 h-56 rounded-full opacity-10"
            style={{ background: '#3cb54a', transform: 'translate(20%, -30%)' }} />
          <div className="relative">
            <p className="text-white/60 text-xs uppercase tracking-widest mb-1">SNC-TAX · SA-iLabs®™</p>
            <h1 className="text-2xl font-bold font-grotesk mb-1">Compl-Ai™ Admin Control Centre</h1>
            <p className="text-white/70 text-sm">Real-time platform management · POPIA compliant · All access logged</p>
          </div>
        </div>

        {/* KPI row — live from DB */}
        {stats.loading ? (
          <div className="flex items-center justify-center h-24">
            <Loader2 className="w-6 h-6 text-primary animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { label: 'Onboarded Clients', value: stats.profiles, icon: Users, color: 'text-primary' },
              { label: 'Total Documents', value: stats.docs, icon: FileText, color: 'text-blue-500' },
              { label: 'Avg Compliance Score', value: `${stats.avgScore}%`, icon: BarChart2, color: 'text-green-500' },
              { label: 'High Risk Clients', value: stats.highRisk, icon: AlertTriangle, color: 'text-red-500' },
              { label: 'Docs Pending Analysis', value: stats.pending, icon: Activity, color: 'text-yellow-500' },
            ].map((k, i) => (
              <div key={i} className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <k.icon className={`w-4 h-4 ${k.color}`} />
                  <p className="text-xs text-gray-400">{k.label}</p>
                </div>
                <p className={`text-2xl font-bold font-grotesk ${k.color}`}>{k.value}</p>
              </div>
            ))}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 bg-white rounded-xl p-1 border border-gray-100 shadow-sm flex-wrap">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all ${
                tab === t.key
                  ? 'text-white shadow-sm'
                  : 'text-gray-400 hover:text-gray-700'
              }`}
              style={tab === t.key ? { background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' } : {}}>
              <t.icon className="w-3.5 h-3.5" /> {t.label}
            </button>
          ))}
        </div>

        {/* ── Overview Tab ── */}
        {tab === 'overview' && (
          <div className="space-y-5">
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="flex items-center gap-2 p-4 border-b border-gray-100">
                <Activity className="w-4 h-4 text-primary" />
                <h2 className="font-semibold text-gray-900 text-sm">Live Client Activity</h2>
                <div className="ml-auto flex items-center gap-1.5 text-xs text-green-600">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  Real-time
                </div>
              </div>
              <div className="p-4">
                <ClientTable profiles={stats.raw || []} />
              </div>
            </div>
          </div>
        )}

        {/* ── Clients Tab ── */}
        {tab === 'clients' && (
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                <h2 className="font-semibold text-gray-900 text-sm">All Business Profiles</h2>
              </div>
              <span className="text-xs text-gray-400">{stats.profiles} registered</span>
            </div>
            <div className="p-4">
              <ClientTable profiles={stats.raw || []} />
            </div>
          </div>
        )}

        {/* ── Documents Tab ── */}
        {tab === 'documents' && <DocumentsPanel />}

        {/* ── White-Label Tab ── */}
        {tab === 'whitelabel' && (
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-6 space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <Globe className="w-4 h-4 text-primary" />
              <h2 className="font-semibold text-gray-900 text-sm">White-Label & Vendor Management</h2>
            </div>
            <p className="text-sm text-gray-500">Manage white-label partner accounting firms, theme customisation, and subscription plans.</p>
            <Link
              to="/white-label"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-white rounded-xl text-sm font-medium transition-all hover:opacity-90"
              style={{ background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' }}
            >
              <Palette className="w-4 h-4" /> Open White-Label Portal →
            </Link>
            <Link
              to="/sudo-admin"
              className="ml-3 inline-flex items-center gap-2 px-5 py-2.5 border border-primary/30 text-primary rounded-xl text-sm font-medium hover:bg-primary/5 transition-all"
            >
              <Lock className="w-4 h-4" /> Open Sudo SaaS Portal →
            </Link>
          </div>
        )}

        {/* ── Approvals Tab ── */}
        {tab === 'approvals' && <AdminApprovals />}

        {/* ── Audit Trail Tab ── */}
        {tab === 'audit' && <AuditTrail />}

        {/* ── Coding Agent Tab ── */}
        {tab === 'coding' && (
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-6 space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <Code className="w-4 h-4 text-primary" />
              <h2 className="font-semibold text-gray-900 text-sm">SA-iLabs™ Coding Agent Realtime</h2>
            </div>
            <p className="text-sm text-gray-500">Launch the in-app AI coding assistant to discuss, plan, and generate code changes for the Compl-Ai™ SA platform. Features a split-view interface with AI chat on the left and live app preview on the right.</p>
            <Link to="/coding-agent" className="inline-flex items-center gap-2 px-5 py-2.5 text-white rounded-xl text-sm font-medium transition-all hover:opacity-90" style={{ background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' }}>
              <Code className="w-4 h-4" /> Launch Coding Agent →
            </Link>
          </div>
        )}

        {/* ── Settings Tab ── */}
        {tab === 'settings' && (
          <div className="space-y-5">
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Bell className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-gray-900 text-sm">Platform Notifications</h3>
              </div>
              {[
                'Email alert on new client onboarding',
                'Email alert on high-risk client detected',
                'Email alert on document upload failure',
                'Weekly compliance summary email',
              ].map((n, i) => (
                <label key={i} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                  <span className="text-sm text-gray-700">{n}</span>
                  <input type="checkbox" defaultChecked={i < 2} className="w-4 h-4 accent-primary" />
                </label>
              ))}
            </div>

            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 space-y-3">
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-gray-900 text-sm">Platform Info</h3>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-xs text-gray-400">Platform</p>
                  <p className="font-medium text-gray-900">Compl-Ai™ SA</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Developed by</p>
                  <p className="font-medium text-gray-900">SA-iLabs®™</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Powered by</p>
                  <p className="font-medium text-gray-900">SNC-TAX</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Admin User</p>
                  <p className="font-medium text-gray-900">{user?.email}</p>
                </div>
              </div>
            </div>

            <div className="bg-red-50 rounded-xl border border-red-200 p-5">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle className="w-4 h-4 text-red-500" />
                <h3 className="font-semibold text-red-700 text-sm">Danger Zone</h3>
              </div>
              <div className="flex flex-wrap gap-3">
                <button className="px-4 py-2 border border-red-300 text-red-600 rounded-lg text-sm hover:bg-red-100 transition-colors">
                  Export All Data (POPIA)
                </button>
                <button onClick={() => logout()} className="px-4 py-2 border border-red-300 text-red-600 rounded-lg text-sm hover:bg-red-100 transition-colors flex items-center gap-1">
                  <LogOut className="w-3.5 h-3.5" /> Force Sign Out
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="text-center text-xs text-gray-400 pt-4 border-t border-gray-100">
          © {new Date().getFullYear()} <strong>SNC-TAX</strong> · Compl-Ai™ SA Admin Portal · All access is logged and audited · SA-iLabs®™
        </div>
      </div>
    </div>
  );
}

// ── Documents Panel (live) ─────────────────────────────────────────────────
function DocumentsPanel() {
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const d = await api.entities.ComplianceDocument.list('-created_date', 100);
        setDocs(d);
      } catch { }
      setLoading(false);
    };
    load();
    const unsub = api.entities.ComplianceDocument.subscribe(() => load());
    return () => unsub();
  }, []);

  const statusStyle = {
    pending: 'bg-yellow-50 text-yellow-700',
    analyzed: 'bg-green-50 text-green-700',
    error: 'bg-red-50 text-red-700',
    verified: 'bg-green-50 text-green-700',
    needs_action: 'bg-red-50 text-red-700',
  };

  if (loading) return (
    <div className="flex items-center justify-center h-32">
      <Loader2 className="w-6 h-6 text-primary animate-spin" />
    </div>
  );

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-gray-900 text-sm">All Uploaded Documents</h2>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-green-600">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          Live
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[600px]">
          <thead>
            <tr className="border-b border-gray-100">
              {['Document Name', 'Type', 'Status', 'Uploaded'].map(h => (
                <th key={h} className="text-left py-3 px-4 text-xs text-gray-400 font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {docs.length === 0 ? (
              <tr><td colSpan={4} className="py-8 text-center text-gray-400 text-sm">No documents uploaded yet.</td></tr>
            ) : docs.map(d => (
              <tr key={d.id} className="hover:bg-gray-50 transition-colors">
                <td className="py-3 px-4 font-medium text-gray-900">{d.document_name || '—'}</td>
                <td className="py-3 px-4 text-gray-500 text-xs">{d.document_type?.replace(/_/g, ' ') || '—'}</td>
                <td className="py-3 px-4">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusStyle[d.status] || 'bg-gray-50 text-gray-500'}`}>
                    {d.status}
                  </span>
                </td>
                <td className="py-3 px-4 text-gray-400 text-xs font-mono">
                  {d.created_date ? new Date(d.created_date).toLocaleDateString('en-ZA') : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}