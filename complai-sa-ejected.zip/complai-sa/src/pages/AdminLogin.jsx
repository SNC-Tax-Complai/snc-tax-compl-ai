import { useState } from 'react';
import { Shield, Eye, EyeOff, AlertTriangle, Lock, Loader2 } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '@/api/apiClient';
import SNCBrandLogo from '@/components/SNCBrandLogo';

const ALLOWED_DOMAINS = ['snctax.co.za', 'snatax.co.za', 'sa-ilabs.co.za'];
const SUDO_ADMINS = ['wernerbotha199@gmail.com'];

export default function AdminLogin() {
  const navigate = useNavigate();
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAdminLogin = async () => {
    setLoading(true);
    setError('');
    try {
      // Platform handles auth — redirect to login, then check on return
      await api.auth.redirectToLogin('/admin');
    } catch {
      setError('Authentication failed. Please try again.');
    }
    setLoading(false);
  };

  const handleGateCheck = async () => {
    setLoading(true);
    setError('');
    try {
      const user = await api.auth.me();
      if (!user) {
        api.auth.redirectToLogin('/admin');
        return;
      }
      const emailDomain = user.email?.split('@')[1]?.toLowerCase();
      const isSnc = ALLOWED_DOMAINS.includes(emailDomain);
        const isAdmin = user.role === 'admin';
        const isSudo = SUDO_ADMINS.includes(user.email?.toLowerCase());

        if (isSnc || isAdmin || isSudo) {
        navigate('/admin');
      } else {
        setError(`Access denied. Admin access is restricted to SNC-TAX staff (${user.email}). Please use a @snctax.co.za email or contact your administrator.`);
      }
    } catch {
      api.auth.redirectToLogin('/admin');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #0a1f47 100%)' }}>
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5"
        style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px' }} />

      <div className="relative w-full max-w-sm">
        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Top accent bar */}
          <div className="h-1.5" style={{ background: 'linear-gradient(90deg, #0d2a5e, #3cb54a, #13b5ea)' }} />

          <div className="p-8">
            {/* Logos */}
            <div className="text-center mb-8">
              <img
                src="/brand/snc-logo.png"
                alt="SNC-TAX"
                className="h-10 w-auto object-contain mx-auto mb-4"
              />
              <div className="flex justify-center mb-3">
                <SNCBrandLogo size="md" showTagline={false} light={false} />
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold"
                style={{ background: 'rgba(13,42,94,0.08)', color: '#0d2a5e' }}>
                <Lock className="w-3 h-3" /> Admin Portal · Restricted Access
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="mb-5 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
                <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            {/* Info box */}
            <div className="mb-6 p-4 rounded-xl bg-blue-50 border border-blue-100 text-xs text-blue-800 space-y-1">
              <p className="font-semibold">Authorised users only:</p>
              <p>• SNC-TAX staff with <strong>@snctax.co.za</strong> email</p>
              <p>• Users with <strong>Admin role</strong> assigned by SNC-TAX</p>
            </div>

            <button
              onClick={handleAdminLogin}
              disabled={loading}
              className="w-full py-3 rounded-xl font-semibold text-sm text-white flex items-center justify-center gap-2 transition-all hover:opacity-90"
              style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #13b5ea 100%)' }}
            >
              {loading
                ? <><Loader2 className="w-4 h-4 animate-spin" /> Authenticating…</>
                : <><Shield className="w-4 h-4" /> Sign In with SNC-TAX Account</>
              }
            </button>

            {/* Already signed in check */}
            <button
              onClick={handleGateCheck}
              disabled={loading}
              className="w-full mt-3 py-2.5 rounded-xl text-sm font-medium border transition-all hover:bg-gray-50"
              style={{ borderColor: '#0d2a5e', color: '#0d2a5e' }}
            >
              I'm already signed in →
            </button>

            <p className="text-center text-xs text-gray-400 mt-4">
              All admin access is logged and audited · POPIA compliant
            </p>
            <p className="text-center text-xs text-gray-400 mt-2">
              New SNC-TAX staff? <Link to="/admin-register" className="text-primary hover:underline">Request Admin Access</Link>
            </p>
          </div>
        </div>

        <p className="text-center text-white/40 text-xs mt-4">
          © {new Date().getFullYear()} SNC-TAX · SA-iLabs®™ · Compl-Ai™ SA
        </p>
      </div>
    </div>
  );
}