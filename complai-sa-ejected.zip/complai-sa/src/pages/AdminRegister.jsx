import { useState } from 'react';
import { Shield, ArrowLeft, CheckCircle, AlertTriangle, Loader2, Lock } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '@/api/apiClient';
import SNCBrandLogo from '@/components/SNCBrandLogo';

export default function AdminRegister() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ full_name: '', email: '', motivation: '' });
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const isSncEmail = (email) => /snc/i.test(email);

  const handleSubmit = async () => {
    setError('');
    if (!form.full_name.trim() || !form.email.trim() || !form.motivation.trim()) {
      setError('Please fill in all fields.');
      return;
    }
    if (!isSncEmail(form.email)) {
      setError('Admin access requires an SNC email address (must contain "snc", e.g. @snctax.co.za).');
      return;
    }
    setLoading(true);
    try {
      const existing = await api.entities.AdminApprovalRequest.filter({ email: form.email.toLowerCase() });
      if (existing.some(r => r.status === 'pending')) {
        setError('A pending admin request already exists for this email. Please wait for approval.');
        setLoading(false);
        return;
      }

      await api.entities.AdminApprovalRequest.create({
        email: form.email.toLowerCase(),
        full_name: form.full_name,
        motivation: form.motivation,
        status: 'pending',
      });

      await api.integrations.Core.SendEmail({
        to: 'wernerbotha199@gmail.com',
        subject: '🔐 New Admin Access Request — Compl-Ai™ SA',
        body: `A new admin access request has been submitted:\n\nName: ${form.full_name}\nEmail: ${form.email}\nMotivation: ${form.motivation}\n\nPlease review and approve/reject in the Admin Portal:\n${window.location.origin}/admin\n\nSA-iLabs®™ · Compl-Ai™ SA`,
      });

      setSubmitted(true);
    } catch (e) {
      setError('Failed to submit request. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #0a1f47 100%)' }}>
      <div className="absolute inset-0 opacity-5"
        style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px' }} />

      <div className="relative w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="h-1.5" style={{ background: 'linear-gradient(90deg, #0d2a5e, #3cb54a, #13b5ea)' }} />
          <div className="p-8">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-3">
                <SNCBrandLogo size="md" showTagline={false} light={false} />
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold mb-3"
                style={{ background: 'rgba(13,42,94,0.08)', color: '#0d2a5e' }}>
                <Lock className="w-3 h-3" /> Admin Access Request
              </div>
            </div>

            {submitted ? (
              <div className="text-center py-6">
                <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
                <h2 className="font-grotesk font-bold text-foreground text-lg mb-2">Request Submitted</h2>
                <p className="text-sm text-muted-foreground mb-1">
                  Your admin access request has been sent to existing administrators for approval.
                </p>
                <p className="text-xs text-muted-foreground mb-6">
                  You'll receive an email notification once your request is reviewed.
                </p>
                <button onClick={() => navigate('/admin-login')}
                  className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-semibold text-sm neon-glow hover:bg-primary/90 transition-colors">
                  Back to Admin Login
                </button>
              </div>
            ) : (
              <>
                <div className="mb-5 p-3 rounded-xl bg-blue-50 border border-blue-100 text-xs text-blue-800 space-y-1">
                  <p className="font-semibold">Admin access requirements:</p>
                  <p>• Must use an <strong>SNC email</strong> (contains "snc", e.g. @snctax.co.za)</p>
                  <p>• Must be approved by an existing admin</p>
                  <p>• All access is logged and audited</p>
                </div>

                {error && (
                  <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
                    <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                    {error}
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">Full Name</label>
                    <input value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))}
                      placeholder="Your full name"
                      className="w-full bg-gray-50 rounded-lg px-4 py-2.5 text-sm text-gray-900 border border-gray-200 focus:border-primary/50 outline-none" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">SNC Email Address</label>
                    <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                      placeholder="yourname@snctax.co.za"
                      className="w-full bg-gray-50 rounded-lg px-4 py-2.5 text-sm text-gray-900 border border-gray-200 focus:border-primary/50 outline-none" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">Motivation</label>
                    <textarea value={form.motivation} onChange={e => setForm(p => ({ ...p, motivation: e.target.value }))}
                      placeholder="Why do you need admin access? What is your role at SNC-TAX?"
                      rows={3}
                      className="w-full bg-gray-50 rounded-lg px-4 py-2.5 text-sm text-gray-900 border border-gray-200 focus:border-primary/50 outline-none resize-none" />
                  </div>
                  <button onClick={handleSubmit} disabled={loading}
                    className="w-full py-3 rounded-xl font-semibold text-sm text-white flex items-center justify-center gap-2 transition-all hover:opacity-90 disabled:opacity-50"
                    style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #13b5ea 100%)' }}>
                    {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Submitting…</> : <><Shield className="w-4 h-4" /> Submit Request</>}
                  </button>
                </div>

                <Link to="/admin-login" className="block text-center text-xs text-muted-foreground hover:text-foreground mt-4">
                  ← Back to Admin Login
                </Link>
              </>
            )}
          </div>
        </div>
        <p className="text-center text-white/40 text-xs mt-4">
          © {new Date().getFullYear()} SNC-TAX · SA-iLabs®™ · Compl-Ai™ SA
        </p>
      </div>
    </div>
  );
}