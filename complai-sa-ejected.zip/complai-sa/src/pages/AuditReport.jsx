import { useState, useRef } from 'react';
import { FileText, Download, Loader2, Shield, CheckCircle, AlertTriangle, Clock, Building, TrendingUp, Sparkles } from 'lucide-react';
import { api } from '@/api/apiClient';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const documents = [
  { name: 'CIPC Certificate of Incorporation', category: 'CIPC', status: 'valid', expires: '2027-03-15' },
  { name: 'B-BBEE Sworn Affidavit', category: 'B-BBEE', status: 'expiring', expires: '2026-06-30' },
  { name: 'Tax Clearance Certificate', category: 'SARS', status: 'valid', expires: '2026-09-01' },
  { name: 'Certificate of Acceptability (Food)', category: 'Municipal', status: 'urgent', expires: '2026-04-05' },
  { name: 'OHS Risk Assessment 2025', category: 'OHS', status: 'valid', expires: '2026-12-01' },
  { name: 'Director ID — John Smith', category: 'FICA', status: 'valid', expires: null },
  { name: 'COIDA Certificate of Compliance', category: 'Labour', status: 'expiring', expires: '2026-03-31' },
  { name: 'POPIA Privacy Policy v2', category: 'POPIA', status: 'valid', expires: null },
];

const filings = [
  { name: 'EMP201 — PAYE/SDL/UIF', category: 'SARS', due: '2026-04-07', status: 'overdue' },
  { name: 'VAT201 Bi-Monthly Return', category: 'SARS', due: '2026-04-25', status: 'upcoming' },
  { name: 'CIPC Annual Return', category: 'CIPC', due: '2026-05-15', status: 'upcoming' },
  { name: 'COIDA Return of Earnings (W.As.8)', category: 'COIDA', due: '2026-03-31', status: 'overdue' },
  { name: 'B-BBEE Affidavit Renewal', category: 'B-BBEE', due: '2026-06-30', status: 'pending' },
  { name: 'IRP6 — 2nd Provisional Tax', category: 'SARS', due: '2027-02-28', status: 'pending' },
];

const riskFlags = [
  { area: 'PAYE Compliance', level: 'high', note: 'EMP201 overdue — penalties accruing daily under s213 of Tax Administration Act' },
  { area: 'COIDA Registration', level: 'high', note: 'Return of Earnings overdue — potential claim rejection risk' },
  { area: 'B-BBEE Certificate', level: 'medium', note: 'Affidavit expiring within 90 days — may affect tender eligibility' },
  { area: 'Food Safety', level: 'high', note: 'Certificate of Acceptability expired — regulatory inspection risk' },
  { area: 'POPIA Compliance', level: 'low', note: 'Privacy policy current — no immediate action required' },
];

const statusColors = { valid: '#22c55e', expiring: '#eab308', urgent: '#ef4444', overdue: '#ef4444', upcoming: '#eab308', pending: '#60a5fa' };
const statusLabels = { valid: 'Valid', expiring: 'Expiring Soon', urgent: 'Urgent', overdue: 'Overdue', upcoming: 'Upcoming', pending: 'Pending' };

function ScoreMeter({ score }) {
  const color = score >= 75 ? '#22c55e' : score >= 50 ? '#eab308' : '#ef4444';
  const label = score >= 75 ? 'Good Standing' : score >= 50 ? 'Needs Attention' : 'At Risk';
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-24 h-24">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
          <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="10" />
          <circle cx="50" cy="50" r="40" fill="none" stroke={color} strokeWidth="10"
            strokeDasharray={`${score * 2.51} 251`} strokeLinecap="round" />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-xl font-bold font-grotesk" style={{ color }}>{score}%</span>
        </div>
      </div>
      <span className="text-xs font-medium" style={{ color }}>{label}</span>
    </div>
  );
}

export default function AuditReport() {
  const [aiSummary, setAiSummary] = useState('');
  const [generating, setGenerating] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [businessName, setBusinessName] = useState('');
  const [sector, setSector] = useState('General');
  const reportRef = useRef();

  const overdueCount = filings.filter(f => f.status === 'overdue').length;
  const urgentDocs = documents.filter(d => d.status === 'urgent' || d.status === 'expiring').length;
  const resolvedFilings = filings.filter(f => f.status === 'pending').length;
  const complianceScore = Math.round(((documents.filter(d => d.status === 'valid').length / documents.length) * 50) + ((filings.filter(f => f.status !== 'overdue').length / filings.length) * 50));

  const generateAISummary = async () => {
    setGenerating(true);
    const result = await api.integrations.Core.InvokeLLM({
      prompt: `You are a South African compliance auditor generating an executive summary for a compliance audit report.

Business: "${businessName || 'The Company'}" | Sector: ${sector} | Date: 6 April 2026

Compliance Score: ${complianceScore}%
Overdue filings: ${overdueCount} (${filings.filter(f => f.status === 'overdue').map(f => f.name).join(', ')})
Documents needing attention: ${urgentDocs} (${documents.filter(d => d.status !== 'valid').map(d => d.name).join(', ')})
Risk flags: ${riskFlags.filter(r => r.level === 'high').length} high, ${riskFlags.filter(r => r.level === 'medium').length} medium

Write a professional 3-paragraph executive summary suitable for submission to auditors or board members. 
- Paragraph 1: Overall compliance posture and score interpretation
- Paragraph 2: Critical non-compliance issues with specific SA legislative references (cite Act names and sections)
- Paragraph 3: Recommended remediation priorities and timeline

Use formal business language. No markdown formatting — plain text only.`,
    });
    setAiSummary(result);
    setGenerating(false);
  };

  const downloadPDF = async () => {
    setDownloading(true);
    const canvas = await html2canvas(reportRef.current, { scale: 2, backgroundColor: '#060d1a', useCORS: true });
    const img = canvas.toDataURL('image/png');
    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const w = pdf.internal.pageSize.getWidth();
    const h = (canvas.height * w) / canvas.width;
    let position = 0;
    const pageHeight = pdf.internal.pageSize.getHeight();
    pdf.addImage(img, 'PNG', 0, position, w, h);
    let remainingHeight = h;
    while (remainingHeight > pageHeight) {
      pdf.addPage();
      position -= pageHeight;
      pdf.addImage(img, 'PNG', 0, position, w, h);
      remainingHeight -= pageHeight;
    }
    pdf.save(`Compl-Ai-Audit-Report-${new Date().toISOString().split('T')[0]}.pdf`);
    setDownloading(false);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      {/* Controls */}
      <div className="glass-card rounded-2xl p-6 border border-primary/20 neon-glow space-y-4">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-2 border border-primary/30">Audit Report Generator</span>
            <h1 className="text-2xl font-bold font-grotesk text-foreground">Compliance Audit Report</h1>
            <p className="text-sm text-muted-foreground mt-1">Generate a professional PDF report for auditors and stakeholders.</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button onClick={generateAISummary} disabled={generating}
              className="flex items-center gap-2 px-4 py-2 bg-secondary border border-primary/20 text-primary rounded-xl text-sm font-medium hover:bg-primary/10 transition-colors disabled:opacity-50">
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {generating ? 'Generating...' : 'AI Executive Summary'}
            </button>
            <button onClick={downloadPDF} disabled={downloading}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium neon-glow hover:bg-primary/90 transition-colors disabled:opacity-50">
              {downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              {downloading ? 'Generating PDF...' : 'Download PDF'}
            </button>
          </div>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">Business / Entity Name</label>
            <input value={businessName} onChange={e => setBusinessName(e.target.value)} placeholder="e.g. Acme (Pty) Ltd"
              className="w-full bg-secondary rounded-lg px-3 py-2 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">Industry Sector</label>
            <input value={sector} onChange={e => setSector(e.target.value)} placeholder="e.g. Retail, Construction"
              className="w-full bg-secondary rounded-lg px-3 py-2 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
          </div>
        </div>
      </div>

      {/* PDF Preview / Report */}
      <div ref={reportRef} className="bg-white rounded-2xl border border-border overflow-hidden shadow-sm">
        {/* Report Header */}
        <div className="bg-gradient-to-r from-primary/10 to-sky-50 p-8 border-b border-border">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-6 h-6 text-primary" />
                <span className="font-grotesk font-bold text-primary text-lg">Compl-Ai™ SA</span>
                </div>
                <h2 className="text-2xl font-bold font-grotesk text-foreground">Compliance Audit Report</h2>
                <p className="text-sm text-muted-foreground mt-1">{businessName || '[Entity Name]'} · {sector} Sector</p>
                <p className="text-xs text-muted-foreground/60 mt-1">Report Date: 6 April 2026 · Generated by Compl-i™ · Emma-i™ MAICP</p>
            </div>
            <ScoreMeter score={complianceScore} />
          </div>
        </div>

        <div className="p-8 space-y-8">
          {/* Executive Summary */}
          <section>
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
              <FileText className="w-4 h-4 text-primary" /> Executive Summary
            </h3>
            <div className="bg-secondary/40 rounded-xl p-5 border border-border">
              {aiSummary ? (
                <p className="text-sm text-foreground leading-relaxed">{aiSummary}</p>
              ) : (
                <p className="text-sm text-muted-foreground italic">Click "AI Executive Summary" above to generate an AI-written summary for this report.</p>
              )}
            </div>
          </section>

          {/* KPI Strip */}
          <section>
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Compliance Overview</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Compliance Score', value: `${complianceScore}%`, icon: Shield, color: complianceScore >= 75 ? '#22c55e' : '#eab308' },
                { label: 'Overdue Filings', value: overdueCount, icon: AlertTriangle, color: '#ef4444' },
                { label: 'Docs Expiring', value: urgentDocs, icon: Clock, color: '#eab308' },
                { label: 'High Risk Flags', value: riskFlags.filter(r => r.level === 'high').length, icon: TrendingUp, color: '#ef4444' },
              ].map((k, i) => (
                <div key={i} className="bg-secondary/40 rounded-xl p-4 border border-border text-center">
                  <k.icon className="w-5 h-5 mx-auto mb-2" style={{ color: k.color }} />
                  <div className="text-2xl font-bold font-grotesk" style={{ color: k.color }}>{k.value}</div>
                  <div className="text-xs text-gray-500 mt-1">{k.label}</div>
                </div>
              ))}
            </div>
          </section>

          {/* Statutory Filings */}
          <section>
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
              <Building className="w-4 h-4 text-primary" /> Statutory Filing Status
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    {['Filing', 'Authority', 'Due Date', 'Status'].map(h => (
                      <th key={h} className="text-left py-2 px-3 text-xs text-muted-foreground font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filings.map((f, i) => (
                    <tr key={i} className="hover:bg-secondary/30">
                      <td className="py-2.5 px-3 text-foreground font-medium">{f.name}</td>
                      <td className="py-2.5 px-3 text-muted-foreground">{f.category}</td>
                      <td className="py-2.5 px-3 text-muted-foreground font-mono text-xs">{f.due}</td>
                      <td className="py-2.5 px-3">
                        <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ color: statusColors[f.status], backgroundColor: `${statusColors[f.status]}18` }}>
                          {statusLabels[f.status]}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Document Status */}
          <section>
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
              <FileText className="w-4 h-4 text-primary" /> Document Vault Status
            </h3>
            <div className="grid md:grid-cols-2 gap-2">
              {documents.map((d, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg border border-border">
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{d.name}</p>
                    <p className="text-xs text-muted-foreground">{d.category}{d.expires ? ` · Exp: ${d.expires}` : ''}</p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ml-2" style={{ color: statusColors[d.status], backgroundColor: `${statusColors[d.status]}18` }}>
                    {statusLabels[d.status]}
                  </span>
                </div>
              ))}
            </div>
          </section>

          {/* Risk Flags */}
          <section>
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400" /> Compliance Risk Flags
            </h3>
            <div className="space-y-2">
              {riskFlags.map((r, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg border" style={{ borderColor: `${statusColors[r.level]}30`, backgroundColor: `${statusColors[r.level]}08` }}>
                  <span className="text-xs px-2 py-0.5 rounded-full font-bold flex-shrink-0 mt-0.5" style={{ color: statusColors[r.level], backgroundColor: `${statusColors[r.level]}18` }}>
                    {r.level.toUpperCase()}
                  </span>
                  <div>
                    <p className="text-xs font-semibold text-gray-200">{r.area}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{r.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Footer */}
          <div className="pt-4 border-t border-border flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Generated by Compl-Ai™ SA · Compl-i™ · Emma-i™ MAICP Protocol · SA-iLabs®™</p>
              <p className="text-xs text-muted-foreground/60 mt-0.5">This report is for guidance only and does not constitute legal or tax advice. Verify with registered professionals.</p>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-primary" />
              <span className="text-xs text-primary font-medium">Compl-Ai™ Verified</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}