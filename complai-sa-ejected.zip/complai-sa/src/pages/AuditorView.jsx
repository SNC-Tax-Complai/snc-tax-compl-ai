import { useState } from 'react';
import { Shield, FileText, CheckCircle, AlertTriangle, Clock, Lock, Eye, Copy, ExternalLink } from 'lucide-react';
import AuditorSummaryPanel from '@/components/auditor/AuditorSummaryPanel';

// READ-ONLY auditor view — no edit controls
const documents = [
  { name: 'CIPC Certificate of Incorporation', category: 'CIPC', status: 'valid', expires: '2027-03-15' },
  { name: 'B-BBEE Sworn Affidavit', category: 'B-BBEE', status: 'expiring', expires: '2026-06-30' },
  { name: 'Tax Clearance Certificate', category: 'SARS', status: 'valid', expires: '2026-09-01' },
  { name: 'Certificate of Acceptability (Food)', category: 'Municipal', status: 'urgent', expires: '2026-04-05' },
  { name: 'OHS Risk Assessment 2025', category: 'OHS', status: 'valid', expires: '2026-12-01' },
  { name: 'Director ID — John Smith', category: 'FICA', status: 'valid', expires: null },
  { name: 'COIDA Certificate of Compliance', category: 'Labour', status: 'expiring', expires: '2026-03-31' },
  { name: 'POPIA Privacy Policy v2', category: 'POPIA', status: 'valid', expires: null },
];

const filings = [
  { name: 'EMP201 — PAYE/SDL/UIF', category: 'SARS', due: '2026-04-07', status: 'overdue' },
  { name: 'VAT201 Bi-Monthly Return', category: 'SARS', due: '2026-04-25', status: 'upcoming' },
  { name: 'CIPC Annual Return', category: 'CIPC', due: '2026-05-15', status: 'upcoming' },
  { name: 'COIDA Return of Earnings', category: 'COIDA', due: '2026-03-31', status: 'overdue' },
  { name: 'B-BBEE Affidavit Renewal', category: 'B-BBEE', due: '2026-06-30', status: 'pending' },
  { name: 'IRP6 — 2nd Provisional Tax', category: 'SARS', due: '2027-02-28', status: 'pending' },
];

const statusConfig = {
  valid: { color: 'text-green-700', bg: 'bg-green-50', border: 'border-green-200', label: 'Valid', icon: CheckCircle },
  expiring: { color: 'text-yellow-700', bg: 'bg-yellow-50', border: 'border-yellow-200', label: 'Expiring', icon: Clock },
  urgent: { color: 'text-red-700', bg: 'bg-red-50', border: 'border-red-200', label: 'Urgent', icon: AlertTriangle },
  overdue: { color: 'text-red-700', bg: 'bg-red-50', border: 'border-red-200', label: 'Overdue', icon: AlertTriangle },
  upcoming: { color: 'text-yellow-700', bg: 'bg-yellow-50', border: 'border-yellow-200', label: 'Upcoming', icon: Clock },
  pending: { color: 'text-blue-700', bg: 'bg-blue-50', border: 'border-blue-200', label: 'Pending', icon: Clock },
};

const score = 72;

// The "share link" generator panel — shown in the main app
function ShareLinkPanel() {
  const [copied, setCopied] = useState(false);
  const link = `${window.location.origin}/auditor-view?token=audit_readonly_demo`;

  const copy = () => {
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="glass-card rounded-2xl p-6 border border-border mb-6">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Eye className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="font-grotesk font-semibold text-foreground">Auditor Access Link</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Share a secure, read-only view of your compliance status with accountants, SARS officials, or stakeholders. No login required.</p>
        </div>
      </div>

      <div className="flex gap-2">
        <div className="flex-1 flex items-center gap-2 px-3 py-2.5 bg-secondary rounded-lg border border-border text-sm font-mono text-muted-foreground overflow-hidden">
          <Lock className="w-3.5 h-3.5 flex-shrink-0 text-green-600" />
          <span className="truncate">{link}</span>
        </div>
        <button onClick={copy}
          className="flex items-center gap-2 px-4 py-2.5 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors flex-shrink-0">
          {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? 'Copied!' : 'Copy Link'}
        </button>
        <a href="/auditor-view" target="_blank"
          className="flex items-center gap-2 px-4 py-2.5 bg-secondary border border-border text-foreground rounded-lg text-sm font-medium hover:bg-secondary/80 transition-colors flex-shrink-0">
          <ExternalLink className="w-4 h-4" /> Preview
        </a>
      </div>

      <div className="grid grid-cols-3 gap-3 mt-4">
        {[
          { label: 'View document vault', allowed: true },
          { label: 'View filing statuses', allowed: true },
          { label: 'View compliance score', allowed: true },
          { label: 'Download audit report', allowed: true },
          { label: 'Edit or upload documents', allowed: false },
          { label: 'Access chat / tools', allowed: false },
        ].map((p, i) => (
          <div key={i} className={`flex items-center gap-2 p-2.5 rounded-lg text-xs ${p.allowed ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
            {p.allowed ? <CheckCircle className="w-3.5 h-3.5 text-green-600 flex-shrink-0" /> : <Lock className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />}
            <span className={p.allowed ? 'text-green-700' : 'text-red-500'}>{p.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// The actual read-only auditor report view
function AuditorReport() {
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('token');

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      {/* Read-only banner */}
      <div className="flex items-center gap-3 px-4 py-3 rounded-xl border border-blue-200 bg-blue-50">
        <Lock className="w-4 h-4 text-blue-600 flex-shrink-0" />
        <p className="text-sm text-blue-700 font-medium">Read-Only Auditor View — You are viewing a shared compliance report. No data can be modified.</p>
      </div>

      {/* Header */}
      <div className="rounded-2xl p-8 border border-border" style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #0096b4 100%)' }}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <img src="/brand/snc-logo.png"
                alt="Logo" className="h-8 object-contain" style={{ filter: 'brightness(0) invert(1)' }} />
            </div>
            <h1 className="text-2xl font-bold font-grotesk text-white">Compliance Status Report</h1>
            <p className="text-white/70 text-sm mt-1">My Business (Pty) Ltd · General Sector</p>
            <p className="text-white/50 text-xs mt-1">Report Date: 7 April 2026 · Compl-Ai™ SA · Read-Only Access</p>
          </div>
          <div className="text-center">
            <div className="relative w-20 h-20">
              <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="10" />
                <circle cx="50" cy="50" r="40" fill="none" stroke="#4ecb71" strokeWidth="10"
                  strokeDasharray={`${score * 2.51} 251`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg font-bold text-white">{score}%</span>
              </div>
            </div>
            <p className="text-white/60 text-xs mt-1">Compliance Score</p>
          </div>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Valid Documents', value: `${documents.filter(d => d.status === 'valid').length}/${documents.length}`, color: 'text-green-600', bg: 'bg-green-50 border-green-200' },
          { label: 'Overdue Filings', value: filings.filter(f => f.status === 'overdue').length, color: 'text-red-600', bg: 'bg-red-50 border-red-200' },
          { label: 'Upcoming Deadlines', value: filings.filter(f => f.status === 'upcoming').length, color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200' },
          { label: 'Docs Expiring', value: documents.filter(d => d.status !== 'valid').length, color: 'text-orange-600', bg: 'bg-orange-50 border-orange-200' },
        ].map((k, i) => (
          <div key={i} className={`rounded-xl p-4 border text-center ${k.bg}`}>
            <div className={`text-2xl font-bold font-grotesk ${k.color}`}>{k.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{k.label}</div>
          </div>
        ))}
      </div>

      {/* Filings */}
      <div className="glass-card rounded-2xl border border-border overflow-hidden">
        <div className="px-5 py-4 border-b border-border bg-secondary/30">
          <h3 className="font-grotesk font-semibold text-foreground text-sm flex items-center gap-2">
            <FileText className="w-4 h-4 text-primary" /> Statutory Filing Status
          </h3>
        </div>
        <table className="w-full text-sm">
          <thead><tr className="border-b border-border bg-secondary/20">
            {['Filing', 'Authority', 'Due Date', 'Status'].map(h => <th key={h} className="text-left py-2.5 px-4 text-xs text-muted-foreground font-medium">{h}</th>)}
          </tr></thead>
          <tbody className="divide-y divide-border">
            {filings.map((f, i) => {
              const s = statusConfig[f.status];
              return <tr key={i} className="hover:bg-secondary/20">
                <td className="py-3 px-4 font-medium text-foreground">{f.name}</td>
                <td className="py-3 px-4 text-muted-foreground">{f.category}</td>
                <td className="py-3 px-4 text-muted-foreground font-mono text-xs">{f.due}</td>
                <td className="py-3 px-4">
                  <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium ${s.bg} ${s.color} border ${s.border}`}>
                    <s.icon className="w-3 h-3" />{s.label}
                  </span>
                </td>
              </tr>;
            })}
          </tbody>
        </table>
      </div>

      {/* Documents */}
      <div className="glass-card rounded-2xl border border-border overflow-hidden">
        <div className="px-5 py-4 border-b border-border bg-secondary/30">
          <h3 className="font-grotesk font-semibold text-foreground text-sm flex items-center gap-2">
            <Shield className="w-4 h-4 text-primary" /> Document Vault
          </h3>
        </div>
        <div className="p-4 grid md:grid-cols-2 gap-2">
          {documents.map((d, i) => {
            const s = statusConfig[d.status];
            return (
              <div key={i} className={`flex items-center justify-between p-3 rounded-xl border ${s.border} ${s.bg}`}>
                <div>
                  <p className="text-sm font-medium text-foreground">{d.name}</p>
                  <p className="text-xs text-muted-foreground">{d.category}{d.expires ? ` · Exp: ${d.expires}` : ''}</p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${s.color} flex-shrink-0`}>{s.label}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="text-center py-4">
        <p className="text-xs text-muted-foreground">Generated by Compl-Ai™ SA · Emma-i™ AI · SA-iLabs®™ · Read-Only Auditor Access</p>
        <p className="text-xs text-muted-foreground/60 mt-1">This report is for informational purposes only and does not constitute legal or tax advice.</p>
      </div>
    </div>
  );
}

export default function AuditorViewPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const isAuditorView = urlParams.get('token');

  if (isAuditorView) return <AuditorReport />;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <div className="rounded-2xl p-8 border border-border" style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #0096b4 100%)' }}>
        <span className="inline-block px-3 py-1 bg-white/15 text-white text-xs font-semibold rounded-full mb-3">🔒 Auditor Access</span>
        <h1 className="text-3xl font-bold font-grotesk text-white mb-2">Auditor View</h1>
        <p className="text-white/70 text-sm">Share a secure, read-only compliance report with your accountant, SARS auditor, or board members.</p>
      </div>
      <ShareLinkPanel />
      <AuditorSummaryPanel />
      <div className="glass-card rounded-2xl p-5 border border-border">
        <h3 className="font-grotesk font-semibold text-foreground mb-3 text-sm">Preview — What auditors will see:</h3>
        <AuditorReport />
      </div>
    </div>
  );
}