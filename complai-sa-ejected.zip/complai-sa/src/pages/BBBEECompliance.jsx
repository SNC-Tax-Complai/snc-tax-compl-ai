import { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem } from '../components/ComplianceSection';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

export default function BBBEECompliance() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocs(demoDocuments); setLoading(false); return; }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
          setDocs(d);
        }
      } catch (e) { console.error('B-BBEE load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const score = profile?.bbbee_score ?? 0;
  const hasDoc = (cat) => docs.some(d => (d.document_type || '').toLowerCase().includes(cat.toLowerCase()));
  const st = (threshold) => score >= threshold ? 'done' : score > 0 ? 'pending' : 'urgent';

  // Determine entity classification from turnover
  let classification = 'Not Available';
  if (profile?.turnover) {
    const turnoverNum = parseFloat(profile.turnover.replace(/[^0-9.]/g, ''));
    if (!isNaN(turnoverNum)) {
      if (profile.turnover.toLowerCase().includes('m') && turnoverNum >= 50) classification = 'Generic';
      else if (profile.turnover.toLowerCase().includes('m') && turnoverNum >= 10) classification = 'QSE';
      else classification = 'EME';
    }
  }

  if (loading) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero badge="B-BBEE Compliance" title="Broad-Based Black Economic Empowerment"
        subtitle="B-BBEE scorecard, EME/QSE classifications, affidavits, ownership, skills development, and sector codes." />

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">Entity Classification</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-primary/20">
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Category</th>
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Annual Turnover</th>
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Default Level</th>
                <th className="text-left py-2 px-3 text-muted-foreground font-medium">Requirement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {[
                { cat: 'EME', turnover: '< R10 million', level: 'Level 4 (or 1/2 if >51% black owned)', req: 'Sworn Affidavit only' },
                { cat: 'QSE', turnover: 'R10M – R50M', level: 'Scorecard based', req: 'QSE Scorecard or Affidavit if ≥51% BO' },
                { cat: 'Generic', turnover: '> R50 million', level: 'Full Scorecard', req: 'Accredited verification agency' },
              ].map((r, i) => (
                <tr key={i} className={`hover:bg-secondary/30 transition-colors ${classification === r.cat ? 'bg-primary/5' : ''}`}>
                  <td className="py-3 px-3 font-medium text-primary">{r.cat}{classification === r.cat && ' ← Your classification'}</td>
                  <td className="py-3 px-3 text-foreground">{r.turnover}</td>
                  <td className="py-3 px-3 text-green-400">{r.level}</td>
                  <td className="py-3 px-3 text-muted-foreground">{r.req}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {profile?.turnover && (
          <p className="text-xs text-muted-foreground mt-3">Your turnover: <span className="text-primary font-medium">{profile.turnover}</span> → Classification: <span className="text-primary font-medium">{classification}</span></p>
        )}
      </div>

      {profile && (
        <div className="glass-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-grotesk font-semibold text-foreground">Your B-BBEE Compliance Score</h2>
            <span className="text-2xl font-bold font-grotesk text-primary">{score}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${score}%` }} />
          </div>
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">Compliance Checklist (EME/QSE)</h2>
        <div className="space-y-2">
          <ChecklistItem label="Determine entity classification (EME/QSE/Generic)" status={profile?.turnover ? 'done' : 'pending'} />
          <ChecklistItem label="Obtain sworn affidavit if EME (Commissioner of Oaths)" status={hasDoc('B-BBEE') ? 'done' : st(30)} detail="Valid for 12 months" />
          <ChecklistItem label="B-BBEE certificate obtained from accredited SANAS agency (if QSE/Generic)" status={hasDoc('B-BBEE') ? st(50) : 'pending'} />
          <ChecklistItem label="Certificate displayed and available to clients/tendering" status={hasDoc('B-BBEE') ? 'done' : 'pending'} />
          <ChecklistItem label="Annual renewal of affidavit or certificate" status={st(60)} />
          <ChecklistItem label="Skills development targets tracked" status={st(65)} />
          <ChecklistItem label="Preferential procurement policy in place" status={st(70)} />
          <ChecklistItem label="Supplier database includes B-BBEE verified suppliers" status={st(75)} />
        </div>
      </div>

      <ExpandableSection title="5 Elements of the Generic Scorecard" defaultOpen>
        {[
          { element: 'Ownership', points: '25 pts', detail: 'Black ownership %, voting rights, economic interest' },
          { element: 'Management Control', points: '19 pts', detail: 'Black executives, board representation' },
          { element: 'Skills Development', points: '20 pts', detail: 'Training spend, learnerships, internships' },
          { element: 'Enterprise & Supplier Development', points: '40 pts', detail: 'Preferential procurement + enterprise development' },
          { element: 'Socio-Economic Development', points: '5 pts', detail: 'Contributions to community development' },
        ].map((e, i) => (
          <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30">
            <span className="text-xs px-2 py-1 bg-primary/20 text-primary rounded-full font-mono flex-shrink-0">{e.points}</span>
            <div>
              <p className="text-sm font-medium text-foreground">{e.element}</p>
              <p className="text-xs text-muted-foreground">{e.detail}</p>
            </div>
          </div>
        ))}
      </ExpandableSection>

      <ExpandableSection title="Sector Codes — Industry-Specific">
        <p className="text-sm text-muted-foreground mb-3">Many sectors have dedicated B-BBEE Codes of Good Practice. Always apply your sector code first.</p>
        {['Construction Sector Charter', 'Financial Sector Code', 'Tourism Sector Charter', 'ICT Sector Code', 'Agri-BEE Charter', 'Mining Charter', 'Media & Advertising Charter', 'Chartered Accountancy Profession Code'].map((s, i) => (
          <ChecklistItem key={i} label={s} status="pending" />
        ))}
      </ExpandableSection>

      <ExpandableSection title="EME Sworn Affidavit — Template Checklist">
        <ChecklistItem label="Company name and registration number" status={profile?.entity_name ? 'done' : 'pending'} detail={profile?.reg_number || ''} />
        <ChecklistItem label="Annual turnover confirmation (below R10M)" status={profile?.turnover ? 'done' : 'pending'} />
        <ChecklistItem label="Black ownership percentage declared" status="pending" />
        <ChecklistItem label="Signed before Commissioner of Oaths" status="pending" />
        <ChecklistItem label="Dated within last 12 months" status="pending" />
        <ChecklistItem label="Affidavit stored in Compliance Vault" status={hasDoc('B-BBEE') ? 'done' : 'pending'} />
      </ExpandableSection>
    </div>
  );
}