import { useState, useEffect } from 'react';
import { Building, FileText, AlertTriangle, Calendar, Loader2 } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem, DeadlineBadge } from '../components/ComplianceSection';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

export default function CIPCCompliance() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocs(demoDocuments); setLoading(false); return; }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
          setDocs(d);
        }
      } catch (e) { console.error('CIPC load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const score = profile?.cipc_score ?? 0;
  const hasDoc = (cat) => docs.some(d => (d.document_type || '').toLowerCase().includes(cat.toLowerCase()));
  const st = (threshold) => score >= threshold ? 'done' : score > 0 ? 'pending' : 'urgent';

  if (loading) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero badge="CIPC Compliance" title="Companies & Intellectual Property Commission"
        subtitle="Annual returns, director amendments, share registers, and company registration compliance for all South African entities." />

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { label: 'Annual Return Due', value: '30 Days', sub: 'After anniversary date', icon: Calendar, color: 'text-blue-400' },
          { label: 'Late Filing Penalty', value: 'R250+', sub: 'Escalates to deregistration', icon: AlertTriangle, color: 'text-red-400' },
          { label: 'Filing Fee (small co)', value: 'R100', sub: 'Turnover < R1M', icon: FileText, color: 'text-green-400' },
        ].map((c, i) => (
          <div key={i} className="glass-card rounded-xl p-5 neon-glow">
            <c.icon className={`w-6 h-6 ${c.color} mb-2`} />
            <div className={`text-2xl font-bold font-grotesk ${c.color}`}>{c.value}</div>
            <div className="text-sm font-medium text-foreground">{c.label}</div>
            <div className="text-xs text-muted-foreground">{c.sub}</div>
          </div>
        ))}
      </div>

      {profile && (
        <div className="glass-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-grotesk font-semibold text-foreground">Your CIPC Compliance Score</h2>
            <span className="text-2xl font-bold font-grotesk text-primary">{score}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${score}%` }} />
          </div>
          <p className="text-xs text-muted-foreground mt-2">Derived from your uploaded documents and Compl-i Assistant analysis.</p>
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4 flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> Key Deadlines</h2>
        <div className="space-y-2">
          <DeadlineBadge label="Annual Return — Anniversary +30 days" date="Rolling" />
          <DeadlineBadge label="Director Change — Within 10 business days" date="Rolling" urgent />
          <DeadlineBadge label="Registered Address Update" date="Immediate" />
          <DeadlineBadge label="Share Register Update on transfer" date="Immediate" />
        </div>
      </div>

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">Compliance Checklist</h2>
        <div className="space-y-2">
          <ChecklistItem label="Company registered with CIPC" status={st(20)} detail={profile?.reg_number ? `Reg: ${profile.reg_number}` : 'Registration certificate obtained'} />
          <ChecklistItem label="Annual Return filed (current year)" status={st(50)} detail="File via CIPC e-Services portal" />
          <ChecklistItem label="Director information up to date" status={profile?.director_name ? 'done' : 'pending'} detail={profile?.director_name ? `Director: ${profile.director_name}` : 'CoR39 submitted if changes'} />
          <ChecklistItem label="Registered office address confirmed" status={profile?.province ? 'done' : 'pending'} />
          <ChecklistItem label="Share register maintained" status={st(60)} detail="Required for all PTY companies" />
          <ChecklistItem label="Company Memorandum of Incorporation (MOI)" status={hasDoc('MOI') || hasDoc('CIPC') ? 'done' : st(40)} />
          <ChecklistItem label="B-BBEE certificate/affidavit on file" status={hasDoc('B-BBEE') ? 'done' : 'pending'} />
          <ChecklistItem label="CIPC customer code active" status={st(30)} />
        </div>
      </div>

      <ExpandableSection title="Annual Returns — Full Guide" defaultOpen>
        <p className="text-sm text-muted-foreground mb-3">Every company and CC must file an Annual Return each year within 30 business days of its anniversary date. Failure results in deregistration.</p>
        <div className="space-y-2">
          <ChecklistItem label="Log in to CIPC e-Services (cipc.co.za)" status="pending" />
          <ChecklistItem label="Confirm financial year-end and turnover" status="pending" />
          <ChecklistItem label="Pay annual return fee (R100–R3,000 depending on turnover)" status="pending" />
          <ChecklistItem label="Upload annual financial statements if required" status="pending" />
        </div>
      </ExpandableSection>

      <ExpandableSection title="Director Amendments (CoR39)">
        <p className="text-sm text-muted-foreground mb-3">Any change in directorship must be submitted to CIPC within 10 business days using CoR39 form.</p>
        <div className="space-y-2">
          <ChecklistItem label="Obtain CoR39 form from CIPC website" status="pending" />
          <ChecklistItem label="Attach certified copies of new director ID" status="pending" />
          <ChecklistItem label="Board resolution authorizing change" status="pending" />
          <ChecklistItem label="Submit via CIPC e-Services or in person" status="pending" />
        </div>
      </ExpandableSection>

      <ExpandableSection title="Company Deregistration & Restoration">
        <p className="text-sm text-muted-foreground mb-3">Companies deregistered for non-filing can be restored. A CoR40.5 application must be submitted with outstanding annual returns paid.</p>
        <ChecklistItem label="Apply for restoration via CoR40.5" status="pending" />
        <ChecklistItem label="Pay all outstanding annual return fees plus penalties" status="pending" />
        <ChecklistItem label="Submit affidavit confirming reason for non-filing" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Share Register & Securities">
        <ChecklistItem label="Maintain updated securities register at registered office" status="pending" />
        <ChecklistItem label="Record all share transfers within 60 days" status="pending" />
        <ChecklistItem label="Issue share certificates upon allotment" status="pending" />
        <ChecklistItem label="File CoR9.4 for voluntary amendments to MOI" status="pending" />
      </ExpandableSection>
    </div>
  );
}