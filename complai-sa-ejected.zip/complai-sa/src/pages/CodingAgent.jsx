import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Code, LogOut, Loader2, AlertTriangle, PanelRightClose, PanelRightOpen, Lock } from 'lucide-react';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import AgentChat from '@/components/coding/AgentChat';
import PreviewPanel from '@/components/coding/PreviewPanel';

const ALLOWED_DOMAINS = ['snctax.co.za', 'snatax.co.za', 'sa-ilabs.co.za'];
const SUDO_ADMINS = ['wernerbotha199@gmail.com'];

export default function CodingAgent() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [checking, setChecking] = useState(true);
  const [accessDenied, setAccessDenied] = useState(false);
  const [view, setView] = useState('split');

  useEffect(() => {
    const check = async () => {
      try {
        const me = await api.auth.me();
        if (!me) { navigate('/admin-login'); return; }
        const domain = me.email?.split('@')[1]?.toLowerCase();
        const allowed = ALLOWED_DOMAINS.includes(domain) || me.role === 'admin' || SUDO_ADMINS.includes(me.email?.toLowerCase());
        if (!allowed) { setAccessDenied(true); return; }
      } catch {
        navigate('/admin-login');
      }
      setChecking(false);
    };
    check();
  }, []);

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-950">
        <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
      </div>
    );
  }

  if (accessDenied) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gray-950">
        <div className="bg-gray-900 rounded-2xl p-8 max-w-sm w-full text-center border border-gray-800">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Access Denied</h2>
          <p className="text-sm text-gray-400 mb-6">
            Your account (<strong>{user?.email}</strong>) is not authorised to access the Coding Agent.
            Only SNC-TAX admins may use this tool.
          </p>
          <button onClick={() => logout()} className="w-full py-2.5 bg-red-500 text-white rounded-xl text-sm font-medium hover:bg-red-600 transition-colors">
            Sign Out
          </button>
          <Link to="/admin" className="block mt-3 text-sm text-cyan-400 hover:underline">← Back to Admin Dashboard</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-950 overflow-hidden">
      {/* Top bar */}
      <header className="flex items-center justify-between px-4 h-12 bg-gray-950 border-b border-gray-800 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #0d2a5e, #13b5ea)' }}>
              <Code className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm font-medium text-white font-grotesk">SA-iLabs™ Coding Agent</span>
            <span className="text-cyan-400 font-bold text-xs">Realtime</span>
          </div>
          <span className="px-2 py-0.5 text-xs rounded-full bg-green-500/20 text-green-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" /> Live
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={() => setView(view === 'split' ? 'chat' : 'split')}
            className="p-1.5 text-gray-400 hover:text-white rounded transition-colors"
            title={view === 'split' ? 'Hide preview' : 'Show preview'}>
            {view === 'split' ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
          </button>
          <Link to="/admin" className="text-xs text-gray-400 hover:text-white transition-colors px-2">
            ← Admin
          </Link>
          <div className="text-xs text-gray-500 hidden sm:block">{user?.email}</div>
          <button onClick={() => logout()}
            className="flex items-center gap-1 px-2.5 py-1 border border-red-800 text-red-400 rounded text-xs font-medium hover:bg-red-900/30 transition-colors">
            <LogOut className="w-3 h-3" /> Exit
          </button>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Chat panel */}
        <div className={view === 'split' ? 'w-2/5' : 'w-full'} style={{ minWidth: 0 }}>
          <AgentChat />
        </div>

        {/* Preview panel */}
        {view === 'split' && (
          <div className="w-3/5 border-l border-gray-800" style={{ minWidth: 0 }}>
            <PreviewPanel />
          </div>
        )}
      </div>
    </div>
  );
}