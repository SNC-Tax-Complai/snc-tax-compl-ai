import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar, List, Clock, Bot, X, Loader2, Send, Zap, ChevronDown, FolderOpen } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

// Statutory recurring deadlines — fixed SA regulatory dates, not mock data
const STATUTORY_EVENTS = [
  { date: '2026-04-30', name: 'Workplace Skills Plan (WSP)', category: 'Labour', authority: 'SETA' },
  { date: '2026-04-30', name: 'Annual Training Report (ATR)', category: 'Labour', authority: 'SETA' },
  { date: '2026-05-31', name: 'EMP501 Annual Reconciliation', category: 'SARS', authority: 'SARS' },
  { date: '2026-08-31', name: 'IRP6 — 1st Provisional Tax', category: 'SARS', authority: 'SARS' },
  { date: '2026-10-31', name: 'EMP501 Interim Reconciliation', category: 'SARS', authority: 'SARS' },
  { date: '2026-10-31', name: 'ITR12 Individual Income Tax', category: 'SARS', authority: 'SARS' },
  { date: '2026-11-30', name: 'FICA KYC Annual Review', category: 'FICA', authority: 'FIC' },
  { date: '2027-01-15', name: 'Employment Equity Report (EEA)', category: 'Labour', authority: 'DoEL' },
  { date: '2027-02-28', name: 'IRP6 — 2nd Provisional Tax', category: 'SARS', authority: 'SARS' },
  { date: '2027-03-31', name: 'COIDA Return of Earnings (W.As.8)', category: 'COIDA', authority: 'CF' },
];

const catColors = {
  SARS: { bg: 'bg-green-400/15', text: 'text-green-400', border: 'border-green-400/30', dot: 'bg-green-400' },
  CIPC: { bg: 'bg-blue-400/15', text: 'text-blue-400', border: 'border-blue-400/30', dot: 'bg-blue-400' },
  Labour: { bg: 'bg-yellow-400/15', text: 'text-yellow-400', border: 'border-yellow-400/30', dot: 'bg-yellow-400' },
  'B-BBEE': { bg: 'bg-purple-400/15', text: 'text-purple-400', border: 'border-purple-400/30', dot: 'bg-purple-400' },
  OHS: { bg: 'bg-red-400/15', text: 'text-red-400', border: 'border-red-400/30', dot: 'bg-red-400' },
  FICA: { bg: 'bg-orange-400/15', text: 'text-orange-400', border: 'border-orange-400/30', dot: 'bg-orange-400' },
  COIDA: { bg: 'bg-pink-400/15', text: 'text-pink-400', border: 'border-pink-400/30', dot: 'bg-pink-400' },
  POPIA: { bg: 'bg-indigo-400/15', text: 'text-indigo-400', border: 'border-indigo-400/30', dot: 'bg-indigo-400' },
};

const statusDot = { overdue: 'bg-red-400 animate-pulse', upcoming: 'bg-yellow-400', pending: 'bg-blue-400', resolved: 'bg-green-400' };

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

function formatTodayStr() {
  const d = new Date();
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function computeEventStatus(dateStr) {
  if (!dateStr) return 'pending';
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const due = new Date(dateStr);
  due.setHours(0, 0, 0, 0);
  const daysLeft = Math.ceil((due - now) / (1000 * 60 * 60 * 24));
  if (daysLeft < 0) return 'overdue';
  if (daysLeft <= 14) return 'upcoming';
  return 'pending';
}

function ResolveModal({ event, onClose }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [input, setInput] = useState('');
  const [started, setStarted] = useState(false);

  const start = async () => {
    setStarted(true);
    setLoading(true);
    const result = await api.integrations.Core.InvokeLLM({
      prompt: `You are Compl-i Assistant. Provide resolution guidance for: "${event.name}" (${event.category}, due ${event.date}).
Return JSON:
{
  "answer": "Brief explanation + why important with SA Act citation",
  "steps": ["step 1", "step 2", "step 3", "step 4"],
  "penalties": "Penalty description with legal reference",
  "portal": "Where to submit / portal URL or contact"
}`,
      response_json_schema: {
        type: 'object',
        properties: {
          answer: { type: 'string' },
          steps: { type: 'array', items: { type: 'string' } },
          penalties: { type: 'string' },
          portal: { type: 'string' },
        }
      }
    });
    setMessages([{ role: 'assistant', data: result }]);
    setLoading(false);
  };

  const sendFollowUp = async () => {
    const msg = input.trim();
    if (!msg || loading) return;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: msg }]);
    setLoading(true);
    const result = await api.integrations.Core.InvokeLLM({
      prompt: `Compl-i Assistant compliance assistant. Context: "${event.name}" (${event.category}). User asks: "${msg}". Answer concisely with SA law references.`,
    });
    setMessages(prev => [...prev, { role: 'assistant', content: result }]);
    setLoading(false);
  };

  const c = catColors[event.category] || catColors.SARS;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-lg glass-card rounded-2xl border border-primary/20 neon-glow flex flex-col max-h-[85vh] animate-slide-up">
        <div className="flex items-start justify-between p-5 border-b border-primary/20 flex-shrink-0">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center"><Bot className="w-4 h-4 text-primary" /></div>
            <div>
              <p className="font-grotesk font-semibold text-foreground text-sm">Compl-i Assistant Resolve</p>
              <p className="text-xs text-muted-foreground mt-0.5">{event.name}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className={`text-xs px-2 py-0.5 rounded-full ${c.bg} ${c.text}`}>{event.category}</span>
                <span className="text-xs text-muted-foreground">Due: {event.date}</span>
              </div>
            </div>
          </div>
          <button onClick={onClose}><X className="w-4 h-4 text-muted-foreground hover:text-foreground" /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {!started ? (
            <div className="text-center py-8 space-y-4">
              <p className="text-sm text-muted-foreground">Compl-i Assistant will guide you through resolving this filing with step-by-step instructions and relevant SA legislation.</p>
              <button onClick={start} className="flex items-center gap-2 mx-auto px-6 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium text-sm neon-glow hover:bg-primary/90 transition-colors">
                <Zap className="w-4 h-4" /> Get Resolution Steps
              </button>
            </div>
          ) : loading && messages.length === 0 ? (
            <div className="flex items-center gap-3 py-4"><Loader2 className="w-4 h-4 text-primary animate-spin" /><span className="text-sm text-muted-foreground">Researching requirements...</span></div>
          ) : (
            <div className="space-y-4">
              {messages.map((m, i) => (
                <div key={i}>
                  {m.role === 'user' ? (
                    <div className="flex justify-end"><div className="max-w-[80%] bg-primary text-primary-foreground rounded-xl px-3 py-2 text-sm">{m.content}</div></div>
                  ) : m.data ? (
                    <div className="space-y-3">
                      <div className="glass-card rounded-xl p-4 border border-primary/10 text-sm text-foreground leading-relaxed">{m.data.answer}</div>
                      {m.data.steps?.length > 0 && (
                        <div className="space-y-1.5">
                          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Action Steps</p>
                          {m.data.steps.map((s, si) => (
                            <div key={si} className="flex items-start gap-2.5 p-2.5 bg-green-400/5 border border-green-400/20 rounded-lg">
                              <div className="w-5 h-5 rounded-full bg-green-400/20 text-green-400 text-xs flex items-center justify-center font-bold flex-shrink-0">{si + 1}</div>
                              <p className="text-xs text-foreground">{s}</p>
                            </div>
                          ))}
                        </div>
                      )}
                      {m.data.penalties && <div className="flex items-start gap-2 p-3 bg-red-400/5 border border-red-400/20 rounded-lg"><span className="text-xs text-red-400">⚠ {m.data.penalties}</span></div>}
                      {m.data.portal && <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg text-xs text-foreground">{m.data.portal}</div>}
                    </div>
                  ) : (
                    <div className="glass-card rounded-xl p-3 border border-primary/10 text-sm text-foreground">{m.content}</div>
                  )}
                </div>
              ))}
              {loading && <div className="flex items-center gap-2"><Loader2 className="w-4 h-4 text-primary animate-spin" /><span className="text-xs text-muted-foreground">Responding...</span></div>}
            </div>
          )}
        </div>

        {started && messages.length > 0 && (
          <div className="p-4 border-t border-primary/20 flex gap-2 flex-shrink-0">
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendFollowUp()}
              placeholder="Ask a follow-up..." className="flex-1 bg-secondary rounded-lg px-3 py-2 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
            <button onClick={sendFollowUp} disabled={loading || !input.trim()} className="px-3 py-2 bg-primary text-primary-foreground rounded-lg disabled:opacity-50">
              <Send className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function EventPill({ event, onClick, dragHandleProps }) {
  const c = catColors[event.category] || catColors.SARS;
  return (
    <div {...dragHandleProps} onClick={() => onClick(event)}
      className={`text-xs px-1.5 py-0.5 rounded cursor-pointer truncate border ${c.bg} ${c.text} ${c.border} hover:opacity-80 transition-opacity flex items-center gap-1`}>
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${statusDot[event.status] || 'bg-blue-400'}`} />
      <span className="truncate">{event.name}</span>
    </div>
  );
}

export default function ComplianceCalendar() {
  const { user } = useAuth();
  const { isDemo, demoProfile } = useDemo();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('month');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [expandedDay, setExpandedDay] = useState(null);

  useEffect(() => {
    if (!isDemo && !user?.id) { setLoading(false); return; }
    (async () => {
      setLoading(true);
      try {
        const profiles = isDemo ? [demoProfile] : await api.entities.BusinessProfile.filter({ user_id: user.id });
        let aiDeadlines = [];
        if (profiles.length > 0) {
          try { aiDeadlines = JSON.parse(profiles[0].upcoming_deadlines || '[]'); } catch (_) {}
        }

        const todayDate = new Date();
        const built = [];

        // Fixed-date statutory events
        STATUTORY_EVENTS.forEach(e => {
          built.push({ id: `stat-${e.date}-${e.name}`, ...e, status: computeEventStatus(e.date) });
        });

        // Recurring monthly statutory events (EMP201 on 7th, VAT201 on 25th)
        for (let m = 0; m < 6; m++) {
          const d = new Date(todayDate.getFullYear(), todayDate.getMonth() + m, 7);
          if (d >= todayDate) {
            const ds = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-07`;
            built.push({ id: `stat-emp201-${ds}`, date: ds, name: 'EMP201 — PAYE/SDL/UIF', category: 'SARS', authority: 'SARS', status: computeEventStatus(ds) });
          }
          const d2 = new Date(todayDate.getFullYear(), todayDate.getMonth() + m, 25);
          if (d2 >= todayDate) {
            const ds = `${d2.getFullYear()}-${String(d2.getMonth() + 1).padStart(2, '0')}-25`;
            built.push({ id: `stat-vat201-${ds}`, date: ds, name: 'VAT201 Bi-Monthly Return', category: 'SARS', authority: 'SARS', status: computeEventStatus(ds) });
          }
        }

        // AI-extracted deadlines from the user's BusinessProfile
        aiDeadlines.forEach((d, i) => {
          if (d.date) {
            built.push({
              id: `ai-${i}`,
              date: d.date,
              name: d.label || d.type || 'AI-Extracted Deadline',
              category: d.category || d.type || 'CIPC',
              authority: d.authority || 'AI',
              status: computeEventStatus(d.date),
            });
          }
        });

        setEvents(built);
      } catch (e) { console.error('Calendar load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const weekStart = new Date(currentDate);
  weekStart.setDate(currentDate.getDate() - currentDate.getDay());

  const navigate = (dir) => {
    const d = new Date(currentDate);
    if (view === 'month') d.setMonth(d.getMonth() + dir);
    else if (view === 'week') d.setDate(d.getDate() + dir * 7);
    else d.setDate(d.getDate() + dir);
    setCurrentDate(d);
  };

  const getEventsForDate = (dateStr) => events.filter(e => e.date === dateStr);

  const formatDate = (d) => {
    const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const eventId = result.draggableId;
    const newDate = result.destination.droppableId;
    if (newDate === result.source.droppableId) return;
    setEvents(prev => prev.map(e => e.id === eventId ? { ...e, date: newDate } : e));
  };

  const buildMonthDays = () => {
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const daysInPrevMonth = new Date(year, month, 0).getDate();
    const days = [];
    for (let i = firstDay - 1; i >= 0; i--) days.push({ date: new Date(year, month - 1, daysInPrevMonth - i), outside: true });
    for (let i = 1; i <= daysInMonth; i++) days.push({ date: new Date(year, month, i), outside: false });
    while (days.length % 7 !== 0) days.push({ date: new Date(year, month + 1, days.length - daysInMonth - firstDay + 1), outside: true });
    return days;
  };

  const buildWeekDays = () => {
    return Array.from({ length: 7 }, (_, i) => { const d = new Date(weekStart); d.setDate(weekStart.getDate() + i); return d; });
  };

  const today = formatTodayStr();

  const upcomingEvents = events
    .filter(e => e.date && e.date >= today)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 20);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  const MonthView = () => {
    const days = buildMonthDays();
    return (
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="grid grid-cols-7 gap-px bg-border rounded-xl overflow-hidden">
          {DAYS.map(d => <div key={d} className="bg-background/50 text-center py-2 text-xs font-medium text-muted-foreground">{d}</div>)}
          {days.map((day, i) => {
            const ds = formatDate(day.date);
            const dayEvents = getEventsForDate(ds);
            const isToday = ds === today;
            return (
              <Droppable key={ds} droppableId={ds}>
                {(provided, snapshot) => (
                  <div ref={provided.innerRef} {...provided.droppableProps}
                    className={`min-h-[90px] p-1.5 transition-colors ${day.outside ? 'bg-background/20' : 'bg-background/50'} ${snapshot.isDraggingOver ? 'bg-primary/10' : ''}`}>
                    <div className={`text-xs font-medium mb-1 w-5 h-5 flex items-center justify-center rounded-full ${isToday ? 'bg-primary text-primary-foreground' : day.outside ? 'text-muted-foreground/40' : 'text-muted-foreground'}`}>
                      {day.date.getDate()}
                    </div>
                    <div className="space-y-0.5">
                      {dayEvents.slice(0, expandedDay === ds ? 100 : 2).map((ev, ei) => (
                        <Draggable key={ev.id} draggableId={ev.id} index={ei}>
                          {(drag) => (
                            <div ref={drag.innerRef} {...drag.draggableProps}>
                              <EventPill event={ev} onClick={setSelectedEvent} dragHandleProps={drag.draggableProps} />
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {dayEvents.length > 2 && expandedDay !== ds && (
                        <button onClick={() => setExpandedDay(ds)} className="text-xs text-primary hover:underline pl-1">+{dayEvents.length - 2} more</button>
                      )}
                    </div>
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            );
          })}
        </div>
      </DragDropContext>
    );
  };

  const WeekView = () => {
    const weekDays = buildWeekDays();
    return (
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="grid grid-cols-7 gap-2">
          {weekDays.map(day => {
            const ds = formatDate(day);
            const dayEvents = getEventsForDate(ds);
            const isToday = ds === today;
            return (
              <Droppable key={ds} droppableId={ds}>
                {(provided, snapshot) => (
                  <div ref={provided.innerRef} {...provided.droppableProps}
                    className={`glass-card rounded-xl p-2 min-h-[200px] transition-colors ${snapshot.isDraggingOver ? 'border-primary/50 bg-primary/5' : 'border-primary/10'}`}>
                    <div className={`text-center mb-2 pb-2 border-b border-border`}>
                      <p className="text-xs text-muted-foreground">{DAYS[day.getDay()]}</p>
                      <p className={`text-sm font-bold ${isToday ? 'text-primary' : 'text-foreground'}`}>{day.getDate()}</p>
                    </div>
                    <div className="space-y-1">
                      {dayEvents.map((ev, ei) => (
                        <Draggable key={ev.id} draggableId={ev.id} index={ei}>
                          {(drag) => (
                            <div ref={drag.innerRef} {...drag.draggableProps}>
                              <EventPill event={ev} onClick={setSelectedEvent} dragHandleProps={drag.draggableProps} />
                            </div>
                          )}
                        </Draggable>
                      ))}
                    </div>
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            );
          })}
        </div>
      </DragDropContext>
    );
  };

  const DayView = () => {
    const ds = formatDate(currentDate);
    const dayEvents = getEventsForDate(ds);
    return (
      <div className="glass-card rounded-xl p-6 border border-primary/10">
        <h3 className="font-grotesk font-semibold text-foreground mb-4">
          {currentDate.toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
        </h3>
        {dayEvents.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground text-sm">No compliance events on this day.</div>
        ) : (
          <div className="space-y-3">
            {dayEvents.map(ev => {
              const c = catColors[ev.category] || catColors.SARS;
              return (
                <button key={ev.id} onClick={() => setSelectedEvent(ev)}
                  className={`w-full flex items-center gap-4 p-4 rounded-xl border text-left hover:opacity-90 transition-opacity ${c.bg} ${c.border}`}>
                  <div className={`w-3 h-3 rounded-full ${statusDot[ev.status]}`} />
                  <div className="flex-1">
                    <p className={`font-medium text-sm ${c.text}`}>{ev.name}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{ev.authority} · Click to resolve with Compl-i Assistant</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${c.bg} ${c.text} border ${c.border}`}>{ev.status}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  const headerTitle = view === 'month'
    ? `${MONTHS[month]} ${year}`
    : view === 'week'
      ? `${weekStart.toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' })} – ${new Date(weekStart.getFullYear(), weekStart.getMonth(), weekStart.getDate() + 6).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short', year: 'numeric' })}`
      : currentDate.toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
      {selectedEvent && <ResolveModal event={selectedEvent} onClose={() => setSelectedEvent(null)} />}

      <div className="relative overflow-hidden rounded-2xl glass-card p-6 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <div className="relative flex items-center justify-between gap-4 flex-wrap">
          <div>
            <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-2 border border-primary/30">🗓️ Compliance Calendar</span>
            <h1 className="text-2xl font-bold font-grotesk text-foreground">Regulatory Deadline Calendar</h1>
            <p className="text-sm text-muted-foreground mt-1">Drag events to reschedule · Click any event for Compl-i Assistant guidance</p>
          </div>
          <div className="flex items-center gap-1 glass-card rounded-xl p-1 border border-primary/20">
            {[{ k: 'day', icon: Clock, label: 'Day' }, { k: 'week', icon: List, label: 'Week' }, { k: 'month', icon: Calendar, label: 'Month' }].map(v => (
              <button key={v.k} onClick={() => setView(v.k)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${view === v.k ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                <v.icon className="w-3.5 h-3.5" />{v.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex gap-3 flex-wrap">
        {Object.entries(catColors).map(([cat, c]) => (
          <div key={cat} className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${c.dot}`} />
            <span className="text-xs text-muted-foreground">{cat}</span>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 glass-card rounded-lg border border-border hover:border-primary/30 text-muted-foreground hover:text-primary transition-colors">
          <ChevronLeft className="w-4 h-4" />
        </button>
        <h2 className="flex-1 text-center font-grotesk font-semibold text-foreground">{headerTitle}</h2>
        <button onClick={() => setCurrentDate(new Date())}
          className="px-3 py-1.5 text-xs glass-card rounded-lg border border-border hover:border-primary/30 text-muted-foreground hover:text-primary transition-colors">
          Today
        </button>
        <button onClick={() => navigate(1)} className="p-2 glass-card rounded-lg border border-border hover:border-primary/30 text-muted-foreground hover:text-primary transition-colors">
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {view === 'month' && <MonthView />}
      {view === 'week' && <WeekView />}
      {view === 'day' && <DayView />}

      <div className="glass-card rounded-xl border border-primary/10 overflow-hidden">
        <div className="flex items-center gap-2 p-4 border-b border-primary/10">
          <List className="w-4 h-4 text-primary" />
          <h3 className="font-grotesk font-semibold text-foreground text-sm">Upcoming Deadlines — Next 90 Days</h3>
          <span className="ml-auto text-xs text-muted-foreground">{upcomingEvents.length} events</span>
        </div>
        {upcomingEvents.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground text-sm flex flex-col items-center gap-2">
            <FolderOpen className="w-8 h-8 text-muted-foreground" />
            No upcoming deadlines. Complete onboarding or upload compliance documents for Compl-i Assistant to extract your filing dates.
          </div>
        ) : (
          <div className="divide-y divide-border">
            {upcomingEvents.map(ev => {
              const c = catColors[ev.category] || catColors.SARS;
              const now = new Date();
              now.setHours(0, 0, 0, 0);
              const due = new Date(ev.date);
              due.setHours(0, 0, 0, 0);
              const days = Math.ceil((due - now) / (1000 * 60 * 60 * 24));
              return (
                <button key={ev.id} onClick={() => setSelectedEvent(ev)}
                  className="w-full flex items-center gap-4 px-4 py-3 hover:bg-secondary/30 transition-colors text-left">
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${statusDot[ev.status] || 'bg-blue-400'}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{ev.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`text-xs px-1.5 py-0.5 rounded ${c.bg} ${c.text}`}>{ev.category}</span>
                      <span className="text-xs text-muted-foreground">{ev.authority}</span>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs font-mono text-muted-foreground">{ev.date}</p>
                    <p className={`text-xs font-medium mt-0.5 ${days <= 14 ? 'text-red-400' : days <= 30 ? 'text-yellow-400' : 'text-muted-foreground'}`}>
                      {days === 0 ? 'Today' : `${days}d away`}
                    </p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-muted-foreground -rotate-90 flex-shrink-0" />
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}