import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, BookOpen, AlertTriangle, CheckCircle, ChevronDown, Sparkles, RefreshCw } from 'lucide-react';
import { api } from '@/api/apiClient';
import ReactMarkdown from 'react-markdown';

const sectors = [
  'General / All Sectors', 'Construction', 'Food & Beverage', 'Healthcare', 'Technology & ICT',
  'Transport & Logistics', 'Retail & Wholesale', 'Agriculture', 'Financial Services',
  'Property & Real Estate', 'Energy & Utilities', 'Professional Services', 'Hospitality & Tourism',
];

const suggestedQuestions = [
  "What are my POPIA obligations as a small business?",
  "When must I register for VAT with SARS?",
  "What does the BCEA say about overtime pay?",
  "Am I required to register with COIDA?",
  "What OHS requirements apply to my workplace?",
  "How do I calculate provisional tax (IRP6)?",
  "What B-BBEE level am I as an EME?",
  "What permits do I need to open a restaurant?",
  "When must I submit EMP201 to SARS?",
  "What are my UIF obligations as an employer?",
];

function CitationBadge({ citation }) {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-primary/10 border border-primary/30 text-primary text-xs rounded-full font-medium">
      <BookOpen className="w-2.5 h-2.5" />
      {citation}
    </span>
  );
}

function ActionCard({ action, index }) {
  return (
    <div className="flex items-start gap-2.5 p-2.5 bg-green-400/5 border border-green-400/20 rounded-lg">
      <div className="w-5 h-5 rounded-full bg-green-400/20 text-green-400 text-xs flex items-center justify-center font-bold flex-shrink-0 mt-0.5">{index + 1}</div>
      <p className="text-xs text-foreground leading-relaxed">{action}</p>
    </div>
  );
}

function MessageBubble({ message }) {
  const isUser = message.role === 'user';

  if (isUser) {
    return (
      <div className="flex justify-end">
        <div className="max-w-[80%] flex items-start gap-2.5">
          <div className="bg-primary text-primary-foreground rounded-2xl rounded-tr-sm px-4 py-3 text-sm leading-relaxed">
            {message.content}
          </div>
          <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
            <User className="w-3.5 h-3.5 text-primary" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start">
      <div className="max-w-[90%] flex items-start gap-2.5">
        <div className="w-7 h-7 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center flex-shrink-0 mt-0.5">
          <Bot className="w-3.5 h-3.5 text-primary" />
        </div>
        <div className="space-y-3 flex-1">
          {/* Main answer */}
          <div className="glass-card rounded-2xl rounded-tl-sm px-4 py-3 border border-primary/10">
            <div className="text-sm text-foreground leading-relaxed prose prose-sm prose-invert max-w-none">
              <ReactMarkdown>{message.content}</ReactMarkdown>
            </div>
          </div>

          {/* Citations */}
          {message.citations?.length > 0 && (
            <div className="px-1">
              <p className="text-xs text-muted-foreground mb-1.5 flex items-center gap-1">
                <BookOpen className="w-3 h-3" /> Legislative References
              </p>
              <div className="flex flex-wrap gap-1.5">
                {message.citations.map((c, i) => <CitationBadge key={i} citation={c} />)}
              </div>
            </div>
          )}

          {/* Corrective actions */}
          {message.actions?.length > 0 && (
            <div className="px-1">
              <p className="text-xs text-muted-foreground mb-1.5 flex items-center gap-1">
                <CheckCircle className="w-3 h-3 text-green-400" /> <span className="text-green-400">Recommended Immediate Actions</span>
              </p>
              <div className="space-y-1.5">
                {message.actions.map((a, i) => <ActionCard key={i} action={a} index={i} />)}
              </div>
            </div>
          )}

          {/* Urgency flag */}
          {message.urgency === 'high' && (
            <div className="px-1 flex items-center gap-2 text-xs text-red-400">
              <AlertTriangle className="w-3 h-3" /> High priority — non-compliance may result in penalties or legal action.
            </div>
          )}

          <p className="text-xs text-muted-foreground px-1">Compl-i™ · Powered by Emma-i™ MAICP · Compl-Ai™ SA · Always verify with a registered professional.</p>
        </div>
      </div>
    </div>
  );
}

export default function ComplianceChat() {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "Hello! I'm **Compl-i™**, your Compl-Ai™ SA compliance expert. Select your industry sector and ask me any compliance question — I'll cite the relevant Acts, sections, and give you immediate corrective actions tailored to your business.\n\n*Accuracy & Ethics Engine: Emma-i™ (MAICP Protocol · SA-iLabs®™)*",
      citations: [],
      actions: [],
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [sector, setSector] = useState('General / All Sectors');
  const [sectorOpen, setSectorOpen] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = async (text) => {
    const msg = (text || input).trim();
    if (!msg || loading) return;
    setInput('');

    const userMsg = { role: 'user', content: msg };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    const history = messages.slice(-8).map(m => `${m.role === 'user' ? 'User' : 'Compl-i™'}: ${m.content}`).join('\n');

    const prompt = `You are Compl-i™, an expert South African compliance AI assistant for Compl-Ai™ SA, powered by the Emma-i™ accuracy and ethics engine (MAICP Protocol by SA-iLabs®™). The user operates in the sector: "${sector}".

Conversation history:
${history}

User question: "${msg}"

Respond with a JSON object in this exact format:
{
  "answer": "Detailed, accurate compliance answer in markdown format. Be specific about South African law. Cite exact Act names, section numbers, and regulation references inline (e.g. 'Section 29 of the BCEA', 'Regulation R638', 'Section 11 of POPIA'). Be practical and sector-specific.",
  "citations": ["Short citation labels, e.g. 'BCEA s29', 'POPIA s11', 'SARS IRP6', 'OHS Act s8'"],
  "actions": ["Specific corrective action 1 the business should take immediately", "Specific corrective action 2", "Specific corrective action 3"],
  "urgency": "low|medium|high"
}

Rules:
- Answer must be specific to South African law and the user's sector
- Always cite specific Act sections (not just Act names)
- Corrective actions must be practical and actionable, not generic
- If the question is not compliance-related, redirect politely to compliance topics
- urgency is "high" if non-compliance carries criminal penalty, deregistration, or SARS audit risk`;

    const result = await api.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          answer: { type: 'string' },
          citations: { type: 'array', items: { type: 'string' } },
          actions: { type: 'array', items: { type: 'string' } },
          urgency: { type: 'string' },
        }
      }
    });

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: result.answer || 'I was unable to generate a response. Please try again.',
      citations: result.citations || [],
      actions: result.actions || [],
      urgency: result.urgency || 'low',
    }]);
    setLoading(false);
    inputRef.current?.focus();
  };

  const clearChat = () => {
    setMessages([{
      role: 'assistant',
      content: "Chat cleared. I'm Compl-i™ — ask me any compliance question for your sector.\n\n*Accuracy & Ethics Engine: Emma-i™ (MAICP Protocol · SA-iLabs®™)*",
      citations: [], actions: [],
    }]);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 h-[calc(100vh-5rem)] flex flex-col gap-4">
      {/* Header */}
      <div className="glass-card rounded-2xl p-5 neon-glow border border-primary/20 flex items-center justify-between gap-4 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="font-grotesk font-bold text-foreground flex items-center gap-2">
              Compl-i™ Compliance Chat <span className="text-xs px-2 py-0.5 bg-green-400/10 text-green-400 border border-green-400/20 rounded-full">● Live</span>
            </h1>
            <p className="text-xs text-muted-foreground">AI-powered · Cites SA legislation · Sector-specific corrective actions</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Accuracy &amp; Ethics powered by <strong className="text-primary">Emma-i™</strong> — MAICP Protocol · SA-iLabs®™
            </p>
          </div>
        </div>
        <button onClick={clearChat} className="p-2 text-muted-foreground hover:text-primary hover:bg-secondary rounded-lg transition-colors" title="Clear chat">
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Sector selector */}
      <div className="flex-shrink-0 relative">
        <button onClick={() => setSectorOpen(!sectorOpen)}
          className="w-full flex items-center justify-between px-4 py-2.5 glass-card rounded-xl border border-primary/20 hover:border-primary/40 transition-colors text-sm">
          <span className="text-muted-foreground">Sector: <span className="text-foreground font-medium">{sector}</span></span>
          <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${sectorOpen ? 'rotate-180' : ''}`} />
        </button>
        {sectorOpen && (
          <div className="absolute top-full left-0 right-0 mt-1 glass-card rounded-xl border border-primary/20 z-20 py-1 shadow-2xl max-h-64 overflow-y-auto">
            {sectors.map(s => (
              <button key={s} onClick={() => { setSector(s); setSectorOpen(false); }}
                className={`w-full text-left px-4 py-2 text-sm transition-colors hover:bg-secondary ${sector === s ? 'text-primary bg-primary/5' : 'text-muted-foreground'}`}>
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-5 pr-1">
        {messages.map((m, i) => <MessageBubble key={i} message={m} />)}

        {loading && (
          <div className="flex justify-start">
            <div className="flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center flex-shrink-0">
                <Bot className="w-3.5 h-3.5 text-primary" />
              </div>
              <div className="glass-card rounded-2xl rounded-tl-sm px-4 py-3 border border-primary/10 flex items-center gap-2">
                <Loader2 className="w-4 h-4 text-primary animate-spin" />
                <span className="text-sm text-muted-foreground">Compl-i™ is researching SA legislation...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested questions */}
      {messages.length <= 1 && (
        <div className="flex-shrink-0 space-y-2">
          <p className="text-xs text-muted-foreground px-1">Suggested questions:</p>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {suggestedQuestions.map((q, i) => (
              <button key={i} onClick={() => sendMessage(q)}
                className="flex-shrink-0 text-xs px-3 py-2 glass-card rounded-xl border border-primary/20 text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors whitespace-nowrap">
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="flex-shrink-0 flex gap-2 glass-card rounded-2xl border border-primary/20 p-2">
        <textarea
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
          placeholder="Ask Compl-i™ a compliance question... (Enter to send, Shift+Enter for new line)"
          rows={2}
          className="flex-1 bg-transparent px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none"
        />
        <button onClick={() => sendMessage()} disabled={loading || !input.trim()}
          className={`px-4 rounded-xl text-sm font-medium flex items-center gap-2 transition-all ${loading || !input.trim() ? 'bg-secondary text-muted-foreground cursor-not-allowed' : 'bg-primary text-primary-foreground neon-glow hover:bg-primary/90'}`}>
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}