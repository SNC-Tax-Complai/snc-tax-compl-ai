import { useState, useEffect } from 'react';
import { CheckCircle, Lock, ChevronRight, Star, TrendingUp, Shield, Zap, Award, FileText, Users, Globe, Target, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import GaugeChart from '../components/GaugeChart';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';

const stages = [
  {
    id: 1,
    level: 'Non-Compliant',
    color: '#ef4444',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200',
    textColor: 'text-red-600',
    icon: Shield,
    description: 'Critical gaps — immediate action required',
    tasks: [
      { id: 't1', label: 'Register company with CIPC', scoreField: 'cipc_score', threshold: 0 },
      { id: 't2', label: 'Register for income tax with SARS', scoreField: 'sars_score', threshold: 0 },
      { id: 't3', label: 'Open business bank account', scoreField: null, threshold: null },
      { id: 't4', label: 'Register for UIF with Department of Labour', scoreField: 'labour_score', threshold: 0 },
      { id: 't5', label: 'Register with COIDA Compensation Fund', scoreField: 'labour_score', threshold: 0 },
    ]
  },
  {
    id: 2,
    level: 'Basic Compliance',
    color: '#f97316',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-200',
    textColor: 'text-orange-600',
    icon: FileText,
    description: 'Core registrations complete — filings needed',
    tasks: [
      { id: 't6', label: 'Submit first EMP201 (PAYE/SDL/UIF)', scoreField: 'sars_score', threshold: 20 },
      { id: 't7', label: 'File CIPC Annual Return', scoreField: 'cipc_score', threshold: 20 },
      { id: 't8', label: 'Register for VAT (if turnover > R1M)', scoreField: 'sars_score', threshold: 20 },
      { id: 't9', label: 'Complete B-BBEE Affidavit (EME)', scoreField: 'bbbee_score', threshold: 20 },
      { id: 't10', label: 'File COIDA Return of Earnings (W.As.8)', scoreField: 'labour_score', threshold: 20 },
    ]
  },
  {
    id: 3,
    level: 'Operationally Compliant',
    color: '#eab308',
    bgColor: 'bg-yellow-50',
    borderColor: 'border-yellow-200',
    textColor: 'text-yellow-600',
    icon: TrendingUp,
    description: 'Filings up to date — documentation gaps remain',
    tasks: [
      { id: 't11', label: 'Upload all SARS certificates to Vault', scoreField: 'sars_score', threshold: 40 },
      { id: 't12', label: 'Draft & publish POPIA Privacy Policy', scoreField: 'popia_score', threshold: 40 },
      { id: 't13', label: 'Appoint OHS Representative', scoreField: 'ohs_score', threshold: 40 },
      { id: 't14', label: 'Complete OHS Workplace Risk Assessment', scoreField: 'ohs_score', threshold: 40 },
      { id: 't15', label: 'Maintain employee contracts (BCEA compliant)', scoreField: 'labour_score', threshold: 40 },
    ]
  },
  {
    id: 4,
    level: 'Substantially Compliant',
    color: '#0096b4',
    bgColor: 'bg-cyan-50',
    borderColor: 'border-cyan-200',
    textColor: 'text-cyan-600',
    icon: Users,
    description: 'Strong foundation — advanced obligations needed',
    tasks: [
      { id: 't16', label: 'Submit Employment Equity Report (EEA2)', scoreField: 'labour_score', threshold: 60 },
      { id: 't17', label: 'Implement POPIA Information Officer training', scoreField: 'popia_score', threshold: 60 },
      { id: 't18', label: 'FICA KYC documentation complete', scoreField: 'fica_score', threshold: 60 },
      { id: 't19', label: 'Workplace Skills Plan (WSP) submitted to SETA', scoreField: 'labour_score', threshold: 60 },
      { id: 't20', label: 'Register for eFiling & activate all tax types', scoreField: 'sars_score', threshold: 60 },
    ]
  },
  {
    id: 5,
    level: 'Advanced Compliance',
    color: '#0d2a5e',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    textColor: 'text-blue-700',
    icon: Globe,
    description: 'Proactive compliance posture — optimizing needed',
    tasks: [
      { id: 't21', label: 'Annual external B-BBEE verification (QSE+)', scoreField: 'bbbee_score', threshold: 80 },
      { id: 't22', label: 'Compliance audit conducted & report filed', scoreField: null, threshold: null },
      { id: 't23', label: 'PAIA manual lodged with Dept of Justice', scoreField: 'popia_score', threshold: 80 },
      { id: 't24', label: 'Director training on Companies Act duties', scoreField: 'cipc_score', threshold: 80 },
      { id: 't25', label: 'Integrated compliance calendar active', scoreField: null, threshold: null },
    ]
  },
  {
    id: 6,
    level: 'Fully Optimized',
    color: '#16a34a',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200',
    textColor: 'text-green-700',
    icon: Award,
    description: 'Best-in-class — continuous compliance excellence',
    tasks: [
      { id: 't26', label: 'Quarterly compliance reviews scheduled', scoreField: null, threshold: null },
      { id: 't27', label: 'Automated filing workflows live', scoreField: null, threshold: null },
      { id: 't28', label: 'Third-party auditor access configured', scoreField: null, threshold: null },
      { id: 't29', label: 'AI-powered risk monitoring active (Compl-i Assistant)', scoreField: null, threshold: null },
      { id: 't30', label: 'ISO 37301 Compliance Management alignment', scoreField: null, threshold: null },
    ]
  },
];

function NoProfileState() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      <div className="relative overflow-hidden rounded-2xl p-8 border border-border"
        style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #0096b4 100%)' }}>
        <div className="relative">
          <span className="inline-block px-3 py-1 bg-white/15 text-white text-xs font-semibold rounded-full mb-3">🏆 Compliance Maturity Framework</span>
          <h1 className="text-3xl font-bold font-grotesk text-white mb-2">Your Compliance Journey</h1>
          <p className="text-white/70 max-w-xl text-sm">Track your progress from Non-Compliant to Fully Optimized.</p>
        </div>
      </div>
      <div className="glass-card rounded-xl p-12 flex flex-col items-center gap-4 border border-primary/10 text-center">
        <Shield className="w-12 h-12 text-primary/40" />
        <h2 className="font-grotesk font-bold text-foreground">No Compliance Data Available</h2>
        <p className="text-sm text-muted-foreground max-w-md">
          Your maturity roadmap is generated from your AI-analysed compliance scores.
          Complete onboarding and upload documents to get started.
        </p>
        <Link to="/onboarding" className="px-5 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors">
          Complete Onboarding
        </Link>
      </div>
    </div>
  );
}

export default function ComplianceMaturity() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [taskStatus, setTaskStatus] = useState({});

  useEffect(() => {
    if (user?.id) loadProfile();
  }, [user]);

  const loadProfile = async () => {
    setLoading(true);
    try {
      const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
      if (profiles.length > 0) {
        const p = profiles[0];
        setProfile(p);
        // Derive task statuses from real compliance scores
        const map = {};
        stages.forEach(s => s.tasks.forEach(t => {
          if (t.scoreField && t.threshold != null) {
            const score = p[t.scoreField];
            map[t.id] = score != null && score >= t.threshold;
          } else {
            map[t.id] = false; // No score mapping — requires manual completion
          }
        }));
        setTaskStatus(map);
      }
    } catch (e) {
      console.error('Failed to load profile', e);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return <NoProfileState />;
  }

  const tasks = taskStatus;
  const toggleTask = (id) => setTaskStatus(p => ({ ...p, [id]: !p[id] }));

  const stageProgress = (stage) => {
    const done = stage.tasks.filter(t => tasks[t.id]).length;
    return { done, total: stage.tasks.length, pct: Math.round((done / stage.tasks.length) * 100) };
  };

  const totalDone = Object.values(tasks).filter(Boolean).length;
  const totalTasks = Object.values(tasks).length;
  const overallPct = totalTasks > 0 ? Math.round((totalDone / totalTasks) * 100) : 0;

  const currentStageIndex = stages.findIndex(s => {
    const { done, total } = stageProgress(s);
    return done < total;
  });
  const currentStage = stages[Math.max(0, currentStageIndex)];

  const isStageUnlocked = (stageIndex) => {
    if (stageIndex === 0) return true;
    const prev = stages[stageIndex - 1];
    const { pct } = stageProgress(prev);
    return pct >= 60;
  };

  const milestones = [
    { level: 2, label: '🏅 EME B-BBEE Sworn Affidavit', desc: 'Qualify for B-BBEE Level 4 recognition as EME', achieved: overallPct > 20 },
    { level: 3, label: '🛡️ OHS Risk Assessment Completed', desc: 'Meet Occupational Health & Safety Act obligations', achieved: overallPct > 35 },
    { level: 4, label: '📊 B-BBEE QSE Formal Verification', desc: 'Upgrade to B-BBEE Level 2–3 with formal certificate', achieved: overallPct > 55 },
    { level: 4, label: '📋 Employment Equity EEA2 Filed', desc: 'Submit first Employment Equity report to DoEL', achieved: overallPct > 55 },
    { level: 5, label: '⚖️ PAIA Manual Lodged', desc: 'Lodge manual with Dept. of Justice under PAIA', achieved: overallPct > 70 },
    { level: 6, label: '🏆 ISO 37301 Compliance Alignment', desc: 'Achieve international compliance management standard', achieved: overallPct > 90 },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl p-8 border border-border"
        style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #0096b4 100%)' }}>
        <div className="relative flex items-start justify-between gap-4 flex-wrap">
          <div>
            <span className="inline-block px-3 py-1 bg-white/15 text-white text-xs font-semibold rounded-full mb-3">
              🏆 Compliance Maturity Framework
            </span>
            <h1 className="text-3xl font-bold font-grotesk text-white mb-2">Your Compliance Journey</h1>
            <p className="text-white/70 max-w-xl text-sm">Track your progress from Non-Compliant to Fully Optimized. Task statuses are derived from your AI-analysed compliance scores.</p>
          </div>
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto">
              <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="10" />
                <circle cx="50" cy="50" r="40" fill="none" stroke="#4ecb71" strokeWidth="10"
                  strokeDasharray={`${overallPct * 2.51} 251`} strokeLinecap="round" className="transition-all duration-700" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold text-white">{overallPct}%</span>
              </div>
            </div>
            <p className="text-white/70 text-xs mt-1">{totalDone}/{totalTasks} tasks</p>
          </div>
        </div>

        {/* Current level badge */}
        <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full border border-white/20">
          <currentStage.icon className="w-4 h-4 text-white" />
          <span className="text-sm font-medium text-white">Current Level: {currentStage.level}</span>
          <Star className="w-3 h-3 text-yellow-300 fill-yellow-300" />
        </div>
      </div>

      {/* Gauges row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stages.slice(0, 4).map(s => {
          const { pct } = stageProgress(s);
          return (
            <div key={s.id} className="glass-card rounded-xl p-4 flex flex-col items-center border border-border">
              <GaugeChart value={pct} color={s.color} size={110} />
              <p className="text-xs font-semibold text-foreground text-center mt-1">{s.level}</p>
            </div>
          );
        })}
      </div>

      {/* Suggested Milestones */}
      <div className="glass-card rounded-xl border border-primary/10 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Target className="w-4 h-4 text-primary" />
          <h2 className="font-grotesk font-semibold text-foreground">Suggested Compliance Milestones</h2>
          <span className="text-xs text-muted-foreground ml-1">based on your current progress</span>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          {milestones.map((m, i) => (
            <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border ${m.achieved ? 'bg-green-400/5 border-green-400/20' : 'bg-secondary/30 border-border'}`}>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold ${m.achieved ? 'bg-green-500 text-white' : 'bg-border text-muted-foreground'}`}>
                {m.achieved ? '✓' : m.level}
              </div>
              <div>
                <p className={`text-xs font-semibold ${m.achieved ? 'text-green-700 line-through' : 'text-foreground'}`}>{m.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{m.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Roadmap */}
      <div className="space-y-4">
        {stages.map((stage, si) => {
          const { done, total, pct } = stageProgress(stage);
          const unlocked = isStageUnlocked(si);
          const completed = pct === 100;
          const isCurrent = si === currentStageIndex;

          return (
            <div key={stage.id}
              className={`glass-card rounded-2xl border overflow-hidden transition-all ${completed ? 'border-green-200' : isCurrent ? `${stage.borderColor}` : 'border-border'} ${!unlocked ? 'opacity-50' : ''}`}>
              {/* Stage header */}
              <div className={`flex items-center gap-4 p-5 ${completed ? 'bg-green-50' : isCurrent ? stage.bgColor : 'bg-secondary/20'}`}>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${completed ? 'bg-green-500' : isCurrent ? 'bg-white shadow-sm' : 'bg-white/60'}`}
                  style={isCurrent && !completed ? { borderColor: stage.color, border: `2px solid ${stage.color}` } : {}}>
                  {completed ? <CheckCircle className="w-6 h-6 text-white" /> : !unlocked ? <Lock className="w-5 h-5 text-muted-foreground" /> : <stage.icon className="w-6 h-6" style={{ color: stage.color }} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-semibold rounded-full px-2 py-0.5" style={{ backgroundColor: `${stage.color}18`, color: stage.color }}>
                      Level {stage.id}
                    </span>
                    {isCurrent && <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-semibold">Current</span>}
                    {completed && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-semibold">✓ Complete</span>}
                  </div>
                  <h3 className="font-grotesk font-bold text-foreground mt-0.5">{stage.level}</h3>
                  <p className="text-xs text-muted-foreground">{stage.description}</p>
                </div>
                <div className="flex-shrink-0 text-right">
                  <div className="text-sm font-bold" style={{ color: stage.color }}>{pct}%</div>
                  <div className="text-xs text-muted-foreground">{done}/{total}</div>
                  <div className="w-20 h-1.5 bg-white/60 rounded-full mt-1.5 overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, backgroundColor: stage.color }} />
                  </div>
                </div>
              </div>

              {/* Tasks */}
              {unlocked && (
                <div className="px-5 pb-4 pt-2 space-y-2">
                  {stage.tasks.map(task => (
                    <button key={task.id} onClick={() => toggleTask(task.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all group ${tasks[task.id] ? 'bg-green-50 border-green-200' : 'bg-secondary/30 border-border hover:border-primary/30'}`}>
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${tasks[task.id] ? 'bg-green-500 border-green-500' : 'border-muted-foreground/40 group-hover:border-primary'}`}>
                        {tasks[task.id] && <CheckCircle className="w-3 h-3 text-white fill-white" />}
                      </div>
                      <span className={`text-sm flex-1 ${tasks[task.id] ? 'text-green-700 line-through' : 'text-foreground'}`}>{task.label}</span>
                      {!tasks[task.id] && <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />}
                    </button>
                  ))}
                  {!completed && pct >= 60 && si < stages.length - 1 && (
                    <div className="flex items-center gap-2 p-3 bg-primary/5 border border-primary/20 rounded-xl mt-1">
                      <Zap className="w-4 h-4 text-primary flex-shrink-0" />
                      <p className="text-xs text-primary font-medium">Level threshold met — <strong>Level {stages[si + 1].id}</strong> is now unlocked!</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}