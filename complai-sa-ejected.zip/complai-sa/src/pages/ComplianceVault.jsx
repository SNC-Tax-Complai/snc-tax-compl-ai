import { useState, useRef, useEffect } from 'react';
import { FolderOpen, Upload, FileText, Search, CheckCircle, Clock, AlertTriangle, X, Loader2, Sparkles, Tag, Trash2, Bot, Shield, Globe, CloudUpload } from 'lucide-react';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';
import LoadingCheckmark from '../components/LoadingCheckmark';
import MultiFileUpload from '../components/vault/MultiFileUpload';

const statusConfig = {
  valid: { color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/20', label: 'Valid', icon: CheckCircle },
  expiring: { color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/20', label: 'Expiring Soon', icon: Clock },
  urgent: { color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/20', label: 'Urgent', icon: AlertTriangle },
  pending: { color: 'text-blue-400', bg: 'bg-blue-400/10', border: 'border-blue-400/20', label: 'Pending', icon: Clock },
  analyzed: { color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/20', label: 'Analyzed', icon: CheckCircle },
  error: { color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/20', label: 'Error', icon: AlertTriangle },
  verified: { color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/20', label: 'Verified', icon: CheckCircle },
  needs_action: { color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/20', label: 'Needs Action', icon: AlertTriangle },
};

const categories = ['SARS', 'CIPC', 'COIDA', 'B-BBEE', 'OHS', 'FICA', 'Labour', 'POPIA', 'Municipal', 'Other'];

function computeStatus(doc) {
  if (doc.status === 'error') return 'error';
  if (doc.status === 'pending') return 'pending';
  if (doc.status === 'verified') return 'verified';
  if (doc.status === 'needs_action') return 'needs_action';
  if (doc.status === 'analyzed') return 'analyzed';
  const expiry = doc.expires;
  if (!expiry) return 'valid';
  const now = new Date();
  const exp = new Date(expiry);
  const daysLeft = Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
  if (daysLeft < 0) return 'urgent';
  if (daysLeft <= 30) return 'expiring';
  return 'valid';
}

function UploadModal({ onClose, onUpload, businessProfileId, userId }) {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [suggestion, setSuggestion] = useState(null);
  const [form, setForm] = useState({ category: '', expires: '', tags: '' });
  const fileRef = useRef();

  const handleFile = async (f) => {
    setFile(f);
    setSuggestion(null);
    setAnalyzing(true);

    let fileUrl = null;
    const isPdfOrImage = /\.(pdf|png|jpg|jpeg)$/i.test(f.name);
    if (isPdfOrImage) {
      const uploaded = await api.integrations.Core.UploadFile({ file: f });
      fileUrl = uploaded.file_url;
    }

    const result = await api.integrations.Core.InvokeLLM({
      prompt: `You are a South African compliance document specialist with OCR capability.
${fileUrl ? `Analyse the attached compliance document and extract all visible metadata.` : `A user is uploading: "${f.name}" (${(f.size / 1024).toFixed(0)} KB).`}
Extract: 1) Document category (from: ${categories.join(', ')}), 2) Issuing authority (SARS/CIPC/DoL/InfoReg/DTIC/etc), 3) Expiry or renewal date (YYYY-MM-DD or null), 4) Reference/certificate number (or null), 5) Entity name on document (or null), 6) 3-5 compliance tags, 7) One-sentence description, 8) Verification status — set to "verified" if the document is complete, valid, not expired, and all critical fields (reference number, entity name, dates) are legible and present; set to "needs_action" if the document is expired, incomplete, illegible, has discrepancies, or is missing critical information. Return JSON only.`,
      file_urls: fileUrl ? [fileUrl] : undefined,
      response_json_schema: {
        type: 'object',
        properties: {
          category: { type: 'string' },
          issuing_authority: { type: 'string' },
          expiry_date: { type: 'string' },
          reference_number: { type: 'string' },
          entity_name: { type: 'string' },
          tags: { type: 'array', items: { type: 'string' } },
          description: { type: 'string' },
            verification_status: { type: 'string' },
          }
          }
          });
          setSuggestion({ ...result, _fileUrl: fileUrl });
    setForm(prev => ({
      ...prev,
      category: result.category || '',
      tags: result.tags?.join(', ') || '',
      expires: result.expiry_date || '',
    }));
    setAnalyzing(false);
  };

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    const file_url = suggestion?._fileUrl || (await api.integrations.Core.UploadFile({ file })).file_url;
    const tags = form.tags.split(',').map(t => t.trim()).filter(Boolean);

    const created = await api.entities.ComplianceDocument.create({
      user_id: userId,
      business_profile_id: businessProfileId,
      document_type: form.category || 'Other',
      document_name: file.name,
      file_url,
      ai_extracted_data: JSON.stringify({
        issuing_authority: suggestion?.issuing_authority || null,
        reference_number: suggestion?.reference_number || null,
        entity_name: suggestion?.entity_name || null,
        tags,
        description: suggestion?.description || null,
        expires: form.expires || null,
      }),
      status: suggestion ? (suggestion.verification_status === 'needs_action' ? 'needs_action' : 'verified') : 'pending',
    });

    onUpload(created);
    setUploading(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-lg glass-card rounded-2xl border border-primary/20 neon-glow animate-slide-up">
        <div className="flex items-center justify-between p-5 border-b border-primary/20">
          <h2 className="font-grotesk font-semibold text-foreground flex items-center gap-2">
            <Upload className="w-4 h-4 text-primary" /> Upload Document
          </h2>
          <button onClick={onClose}><X className="w-4 h-4 text-muted-foreground hover:text-foreground" /></button>
        </div>

        <div className="p-5 space-y-4">
          <div
            onClick={() => fileRef.current.click()}
            onDragOver={e => e.preventDefault()}
            onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${file ? 'border-primary/40 bg-primary/5' : 'border-border hover:border-primary/40 hover:bg-secondary/50'}`}>
            <input ref={fileRef} type="file" className="hidden" onChange={e => e.target.files[0] && handleFile(e.target.files[0])} />
            {file ? (
              <div className="flex items-center gap-3 justify-center">
                <FileText className="w-6 h-6 text-primary" />
                <div className="text-left">
                  <p className="text-sm font-medium text-foreground">{file.name}</p>
                  <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(0)} KB</p>
                </div>
              </div>
            ) : (
              <div>
                <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Drop a file or <span className="text-primary">browse</span></p>
                <p className="text-xs text-muted-foreground mt-1">PDF, PNG, JPG, DOCX supported</p>
              </div>
            )}
          </div>

          {analyzing && (
            <div className="flex items-center gap-3 p-3 bg-primary/5 border border-primary/20 rounded-xl">
              <Loader2 className="w-4 h-4 text-primary animate-spin flex-shrink-0" />
              <p className="text-sm text-muted-foreground">Compl-i Assistant OCR is scanning and extracting metadata from your document...</p>
            </div>
          )}

          {suggestion && !analyzing && (
            <div className="p-3 bg-primary/5 border border-primary/30 rounded-xl space-y-2">
              <p className="text-xs font-medium text-primary flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Compl-i Assistant OCR Auto-Detection
              </p>
              <p className="text-xs text-foreground">{suggestion.description}</p>
              {suggestion.issuing_authority && <p className="text-xs text-muted-foreground">🏛 Authority: <strong className="text-foreground">{suggestion.issuing_authority}</strong></p>}
              {suggestion.expiry_date && <p className="text-xs text-muted-foreground">📅 Expiry: <strong className="text-foreground">{suggestion.expiry_date}</strong></p>}
              {suggestion.reference_number && <p className="text-xs text-muted-foreground">🔖 Ref: <strong className="text-foreground">{suggestion.reference_number}</strong></p>}
              {suggestion.entity_name && <p className="text-xs text-muted-foreground">🏢 Entity: <strong className="text-foreground">{suggestion.entity_name}</strong></p>}
              <div className="flex flex-wrap gap-1">
                {suggestion.tags?.map((t, i) => (
                  <span key={i} className="text-xs px-2 py-0.5 bg-primary/10 text-primary border border-primary/20 rounded-full">{t}</span>
                ))}
              </div>
            </div>
          )}

          {file && !analyzing && (
            <div className="space-y-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">Category</label>
                <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                  className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none">
                  <option value="">Select category...</option>
                  {categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">Expiry Date (optional)</label>
                <input type="date" value={form.expires} onChange={e => setForm(p => ({ ...p, expires: e.target.value }))}
                  className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">Tags (comma-separated)</label>
                <input value={form.tags} onChange={e => setForm(p => ({ ...p, tags: e.target.value }))}
                  placeholder="e.g. SARS, Tax, Certificate"
                  className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-1">
            <button onClick={onClose} className="flex-1 py-2.5 border border-border text-muted-foreground rounded-xl text-sm hover:bg-secondary transition-colors">Cancel</button>
            <button onClick={handleUpload} disabled={!file || uploading || analyzing}
              className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium neon-glow hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
              {uploading ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Uploading...</> : <><Upload className="w-3.5 h-3.5" /> Upload & Save</>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ComplianceVault() {
  const { user } = useAuth();
  const { isDemo, demoDocuments } = useDemo();
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('All');
  const [showUpload, setShowUpload] = useState(false);
  const [showBulkUpload, setShowBulkUpload] = useState(false);

  const loadDocuments = async () => {
    if (!user?.id) { setLoading(false); return; }
    try {
      const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
      if (profiles.length > 0) {
        const docs = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
        setDocuments(docs);
      }
    } catch (e) { console.error('Vault load error', e); }
    setLoading(false);
  };

  useEffect(() => {
    if (isDemo) { setDocuments(demoDocuments); setLoading(false); return; }
    setLoading(true);
    loadDocuments();
  }, [user?.id, isDemo]);

  // Real-time sync — refresh whenever this user's documents change (e.g. AI analysis completing).
  useEffect(() => {
    if (isDemo || !user?.id) return;
    const unsub = api.entities.ComplianceDocument.subscribe((event) => {
      if (event.data?.user_id === user.id) loadDocuments();
    });
    return () => unsub();
  }, [user?.id, isDemo]);

  const cats = ['All', ...new Set(documents.map(d => d.document_type || 'Other'))];

  const filtered = documents.filter(d => {
    const cat = d.document_type || 'Other';
    const name = d.document_name || '';
    const q = search.toLowerCase().trim();
    let meta = {};
    try { meta = JSON.parse(d.ai_extracted_data || '{}'); } catch (_) {}
    const tags = meta.tags || [];
    const authority = meta.issuing_authority || '';
    const refNum = meta.reference_number || '';
    const entityName = meta.entity_name || '';
    const description = meta.description || '';
    const matchesSearch = !q ||
      name.toLowerCase().includes(q) ||
      cat.toLowerCase().includes(q) ||
      tags.some(t => t.toLowerCase().includes(q)) ||
      authority.toLowerCase().includes(q) ||
      refNum.toLowerCase().includes(q) ||
      entityName.toLowerCase().includes(q) ||
      description.toLowerCase().includes(q);
    return (filterCat === 'All' || cat === filterCat) && matchesSearch;
  });

  const handleUpload = (doc) => setDocuments(prev => [doc, ...prev]);
  const handleDelete = async (id) => {
    if (isDemo) {
      setDocuments(prev => prev.filter(d => d.id !== id));
      return;
    }
    await api.entities.ComplianceDocument.delete(id);
    setDocuments(prev => prev.filter(d => d.id !== id));
  };

  const getDocMeta = (doc) => {
    try { return JSON.parse(doc.ai_extracted_data || '{}'); } catch (_) { return {}; }
  };

  const stats = {
    total: documents.length,
    expiring: documents.filter(d => computeStatus(d) === 'expiring').length,
    urgent: documents.filter(d => computeStatus(d) === 'urgent').length,
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      {showUpload && (
        <UploadModal
          onClose={() => setShowUpload(false)}
          onUpload={handleUpload}
          businessProfileId={documents[0]?.business_profile_id}
          userId={isDemo ? 'demo-user' : user?.id}
        />
      )}
      {showBulkUpload && (
        <MultiFileUpload
          onClose={() => setShowBulkUpload(false)}
          onComplete={(docs) => docs.forEach(d => handleUpload(d))}
          businessProfileId={documents[0]?.business_profile_id}
          userId={isDemo ? 'demo-user' : user?.id}
        />
      )}

      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">Compliance Vault</span>
        <h1 className="text-3xl font-bold font-grotesk text-foreground mb-2">Secure Document Vault</h1>
        <p className="text-muted-foreground">{isDemo ? 'You are viewing simulated documents in DEMO mode. Upload is disabled.' : 'Upload, categorize, and manage compliance documents. Compl-i Assistant auto-tags each document on upload.'}</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Documents', value: stats.total, color: 'text-primary' },
          { label: 'Expiring Soon', value: stats.expiring, color: 'text-yellow-400' },
          { label: 'Urgent Action', value: stats.urgent, color: 'text-red-400' },
        ].map((s, i) => (
          <div key={i} className="glass-card rounded-xl p-4 text-center">
            <div className={`text-2xl font-bold font-grotesk ${s.color}`}>{s.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, category, authority, reference, tag..."
            className="w-full bg-secondary pl-9 pr-4 py-2.5 rounded-lg text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {cats.map(c => (
            <button key={c} onClick={() => setFilterCat(c)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${filterCat === c ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}>
              {c}
            </button>
          ))}
        </div>
        <div className="flex gap-2 flex-shrink-0">
          <button onClick={() => !isDemo && setShowBulkUpload(true)} disabled={isDemo}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${isDemo ? 'bg-secondary text-muted-foreground cursor-not-allowed' : 'bg-primary text-primary-foreground neon-glow hover:bg-primary/90'}`}>
            <CloudUpload className="w-4 h-4" /> {isDemo ? 'Bulk (Demo)' : 'Bulk Upload'}
          </button>
          <button onClick={() => !isDemo && setShowUpload(true)} disabled={isDemo}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${isDemo ? 'bg-secondary text-muted-foreground cursor-not-allowed' : 'bg-primary text-primary-foreground neon-glow hover:bg-primary/90'}`}>
            <Upload className="w-4 h-4" /> {isDemo ? 'Upload (Demo)' : 'Upload Document'}
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {loading ? (
          <div className="glass-card rounded-xl p-8">
            <LoadingCheckmark
              size="sm"
              stepDuration={500}
              title="Loading your documents…"
              steps={[
                { label: 'Fetching your documents…', icon: FileText },
                { label: 'Analysing document metadata…', icon: Bot },
                { label: 'Checking expiry dates…', icon: Clock },
                { label: 'Securing your data…', icon: Shield },
              ]}
            />
          </div>
        ) : filtered.length === 0 ? (
          <div className="glass-card rounded-xl p-12 text-center">
            <FolderOpen className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground text-sm">{documents.length === 0 ? 'No documents uploaded yet. Upload your first compliance document.' : 'No documents found.'}</p>
          </div>
        ) : (
          filtered.map((doc) => {
            const status = computeStatus(doc);
            const meta = getDocMeta(doc);
            const s = statusConfig[status] || statusConfig.valid;
            return (
              <div key={doc.id} className={`glass-card rounded-xl p-4 border ${s.border} flex items-center justify-between gap-4`}>
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`p-2 rounded-lg ${s.bg} flex-shrink-0`}>
                    <FileText className={`w-5 h-5 ${s.color}`} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{doc.document_name || 'Untitled'}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="text-xs text-muted-foreground">{doc.document_type || 'Other'}</span>
                      {meta.expires && <span className="text-xs text-muted-foreground">Expires: {meta.expires}</span>}
                      {meta.issuing_authority && <span className="text-xs text-muted-foreground">· {meta.issuing_authority}</span>}
                      {meta.reference_number && <span className="text-xs text-muted-foreground font-mono">#{meta.reference_number}</span>}
                    </div>
                    {meta.tags?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {meta.tags.map((t, i) => (
                          <span key={i} className="inline-flex items-center gap-0.5 text-xs px-1.5 py-0.5 bg-secondary text-muted-foreground rounded-full">
                            <Tag className="w-2.5 h-2.5" />{t}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <div className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium ${s.bg} ${s.color}`}>
                    <s.icon className="w-3 h-3" />{s.label}
                  </div>
                  <button onClick={() => handleDelete(doc.id)} className="p-1.5 text-muted-foreground hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}