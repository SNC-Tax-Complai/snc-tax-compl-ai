import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import SNCBrandLogo from '../components/SNCBrandLogo';
import ComplianceNotifications from '../components/ComplianceNotifications';
import FilingIntegrationCard from '../components/FilingIntegrationCard';
import KPICard from '../components/KPICard';
import GaugeChart from '../components/GaugeChart';
import DeadlineCalendar from '../components/DeadlineCalendar';
import ComplianceProgressChart from '../components/ComplianceProgressChart';
import {
  TrendingUp, AlertCircle, FileText, Shield, Clock, CheckCircle,
  Building, Users, Zap, BarChart2, Award, Calendar, Loader2, Bot, ChevronRight,
  Globe, Database, Download
} from 'lucide-react';

import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';
import LoadingCheckmark from '../components/LoadingCheckmark';

const quickLinks = [
  { label: 'Risk Analytics', path: '/risk-analytics', icon: BarChart2, color: 'text-red-400' },
  { label: 'Maturity Roadmap', path: '/maturity', icon: Award, color: 'text-yellow-400' },
  { label: 'Compliance Calendar', path: '/calendar', icon: Calendar, color: 'text-blue-400' },
  { label: 'Document Vault', path: '/vault', icon: FileText, color: 'text-purple-400' },
  { label: 'Filing Workflows', path: '/filing', icon: Zap, color: 'text-green-400' },
  { label: 'Compl-i™ Chat', path: '/chat', icon: Shield, color: 'text-primary' },
];

function OnboardingPrompt() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
      <div className="w-20 h-20 rounded-full flex items-center justify-center mb-6" style={{ background: 'rgba(13,42,94,0.08)' }}>
        <Bot className="w-10 h-10 text-primary" />
      </div>
      <h2 className="text-2xl font-bold font-grotesk text-foreground mb-3">Set Up Your Compliance Profile</h2>
      <p className="text-sm text-muted-foreground max-w-md mb-6">
        Welcome to Compl-Ai™ SA. To get started, complete your onboarding so Compl-i Assistant can analyse your business and populate your personalised compliance dashboard.
      </p>
      <Link to="/onboarding" className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold text-sm neon-glow hover:bg-primary/90 transition-colors flex items-center gap-2">
        Get Started <ChevronRight className="w-4 h-4" />
      </Link>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [docCount, setDocCount] = useState(0);
  const [docVerified, setDocVerified] = useState(0);
  const [docNeedsAction, setDocNeedsAction] = useState(0);
  const [loading, setLoading] = useState(true);
  const [reportLoading, setReportLoading] = useState(false);

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocCount(demoDocuments.length); setDocVerified(demoDocuments.filter(d => d.status === 'verified').length); setDocNeedsAction(demoDocuments.filter(d => d.status === 'needs_action').length); setLoading(false); return; }
    if (user?.id) loadProfile();
  }, [user, isDemo]);

  // Real-time updates — refresh the dashboard whenever the user's business profile
  // or compliance documents change (e.g. new registration, Vault upload, AI analysis).
  useEffect(() => {
    if (isDemo || !user?.id) return;
    const unsubProfile = api.entities.BusinessProfile.subscribe((event) => {
      if (event.data?.user_id === user.id) loadProfile();
    });
    const unsubDocs = api.entities.ComplianceDocument.subscribe((event) => {
      if (event.data?.user_id === user.id) loadProfile();
    });
    return () => { unsubProfile(); unsubDocs(); };
  }, [user?.id, isDemo]);

  const loadProfile = async () => {
    setLoading(true);
    try {
      const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
      if (profiles.length > 0 && profiles[0].onboarding_complete) {
        const p = profiles[0];
        setProfile(p);
        // Count documents
        try {
          const docs = await api.entities.ComplianceDocument.filter({ business_profile_id: p.id });
          setDocCount(docs.length);
          setDocVerified(docs.filter(d => d.status === 'verified').length);
          setDocNeedsAction(docs.filter(d => d.status === 'needs_action').length);
        } catch (_) {}
      } else if (profiles.length > 0 && !profiles[0].onboarding_complete) {
        // Onboarding started but not complete — go back to onboarding
        navigate('/onboarding');
      }
      // else: no profile, will show OnboardingPrompt
    } catch (e) {
      console.error('Failed to load profile', e);
    }
    setLoading(false);
  };

  const handleDownloadReport = async () => {
    setReportLoading(true);
    try {
      const response = await api.functions.invoke('generateMonthlyReport', { profile_id: profile?.id });
      // response.data is ArrayBuffer when Content-Type is application/pdf
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const now = new Date();
      a.download = `ComplAi-Monthly-Report-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Report generation failed', e);
    }
    setReportLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-full max-w-sm">
          <LoadingCheckmark
            size="md"
            stepDuration={500}
            title="Loading your compliance dashboard…"
            steps={[
              { label: 'Fetching your business profile…', icon: Database },
              { label: 'Loading compliance documents…', icon: FileText },
              { label: 'AI analysing your compliance status…', icon: Bot },
              { label: 'Securing your data…', icon: Shield },
            ]}
          />
        </div>
      </div>
    );
  }

  if (!profile) {
    return <OnboardingPrompt />;
  }

  // Parse AI data
  let upcomingDeadlines = [];
  try {
    upcomingDeadlines = JSON.parse(profile.upcoming_deadlines || '[]');
  } catch (_) {}

  const recommendations = (profile.ai_recommendations || '').split('|').filter(Boolean);

  // Score trend is NOT simulated — only current score is available from AI analysis
  const currentScore = profile.compliance_score;

  const moduleScores = [
    { label: 'CIPC', score: profile.cipc_score || 0, color: '#0096b4' },
    { label: 'SARS', score: profile.sars_score || 0, color: '#3cb54a' },
    { label: 'Labour', score: profile.labour_score || 0, color: '#f59e0b' },
    { label: 'OHS', score: profile.ohs_score || 0, color: '#ef4444' },
    { label: 'POPIA', score: profile.popia_score || 0, color: '#8b5cf6' },
    { label: 'B-BBEE', score: profile.bbbee_score || 0, color: '#ec4899' },
    { label: 'FICA', score: profile.fica_score || 0, color: '#14b8a6' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">

      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl p-8 md:p-10"
        style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #1a3a6e 60%, #13b5ea 100%)', boxShadow: '0 4px 24px rgba(13,42,94,0.22)' }}>
        <div className="absolute top-0 right-0 w-72 h-72 rounded-full opacity-10" style={{ background: '#3cb54a', transform: 'translate(30%, -30%)' }} />
        <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full opacity-10" style={{ background: '#13b5ea', transform: 'translate(-20%, 30%)' }} />
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-4 mb-5">
              <SNCBrandLogo size="md" showTagline={false} light={true} />
            </div>
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full border"
                style={{ background: 'rgba(60,181,74,0.2)', color: '#7de88a', borderColor: 'rgba(60,181,74,0.4)' }}>
                🇿🇦 Proudly South African
              </span>
              <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full border"
                style={{ background: 'rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.8)', borderColor: 'rgba(255,255,255,0.2)' }}>
                {profile.entity_name}
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold font-grotesk text-white mb-1">
              Welcome back, {user?.full_name || profile.director_name || 'there'}
            </h1>
            <p className="max-w-xl text-sm" style={{ color: 'rgba(255,255,255,0.70)' }}>
              {profile.ai_analysis_summary || `Powered by Compl-i Assistant — your AI compliance navigator. MAICP Protocol · SA-iLabs®™.`}
            </p>
            <div className="flex gap-3 mt-5 flex-wrap items-center">
              <ComplianceNotifications />
              <button
                onClick={handleDownloadReport}
                disabled={reportLoading}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors disabled:opacity-60"
                style={{ background: 'rgba(60,181,74,0.2)', color: '#7de88a', border: '1px solid rgba(60,181,74,0.4)' }}>
                {reportLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                {reportLoading ? 'Generating…' : 'Monthly Report'}
              </button>
            </div>
          </div>
          <div className="hidden md:flex flex-col items-center justify-center rounded-2xl px-7 py-5 text-center flex-shrink-0"
            style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', minWidth: 210 }}>
            <SNCBrandLogo size="lg" showTagline={true} light={true} />
            <div className="mt-3 pt-3 w-full" style={{ borderTop: '1px solid rgba(255,255,255,0.15)' }}>
              <p className="text-xs font-semibold tracking-wider uppercase" style={{ color: '#3cb54a' }}>A SNC-TAX Product</p>
              <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.50)' }}>Developed by SA-iLabs®™</p>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KPICard title="Compliance Score" value={profile.compliance_score != null ? `${profile.compliance_score}%` : 'N/A'} subtitle={profile.risk_level ? `${profile.risk_level} risk level` : 'Not assessed yet'} icon={Shield} trend={null} />
        <KPICard title="Pending Filings" value={profile.pending_filings ?? 'N/A'} subtitle="Due this period" icon={FileText} color="text-yellow-400" />
        <KPICard title="Urgent Alerts" value={profile.urgent_alerts ?? 'N/A'} subtitle="Action required" icon={AlertCircle} color="text-red-400" />
        <KPICard title="Vault Documents" value={docCount} subtitle="Uploaded documents" icon={CheckCircle} color="text-green-400" />
      </div>

      {/* Document Verification Status */}
      {(docVerified > 0 || docNeedsAction > 0) && (
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(60,181,74,0.07)' }}>
            <div className="h-1" style={{ background: 'linear-gradient(90deg, #3cb54a, #3cb54a)' }} />
            <div className="p-5 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-green-400/10 flex-shrink-0">
                <CheckCircle className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-bold font-grotesk text-foreground">{docVerified}</p>
                <p className="text-xs text-muted-foreground">Document(s) Verified by Compl-i Assistant</p>
                <p className="text-xs text-green-400 mt-0.5">Complete &amp; valid ✓</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(239,68,68,0.07)' }}>
            <div className="h-1" style={{ background: 'linear-gradient(90deg, #ef4444, #ef4444)' }} />
            <div className="p-5 flex items-center gap-4">
              <div className="p-3 rounded-xl bg-red-400/10 flex-shrink-0">
                <AlertCircle className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <p className="text-2xl font-bold font-grotesk text-foreground">{docNeedsAction}</p>
                <p className="text-xs text-muted-foreground">Document(s) Needing Action</p>
                <Link to="/vault" className="text-xs text-red-400 mt-0.5 hover:underline">Review in Vault →</Link>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Score Trend + Overall Gauge + Deadlines */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.07)' }}>
          <div className="h-1" style={{ background: 'linear-gradient(90deg, #0d2a5e, #13b5ea)' }} />
          <div className="p-6">
            <h2 className="font-grotesk font-semibold text-foreground mb-4 text-sm">Compliance Score</h2>
            {currentScore != null ? (
              <div className="flex flex-col items-center justify-center h-[140px]">
                <p className="text-5xl font-bold font-grotesk text-primary">{currentScore}%</p>
                <p className="text-xs text-muted-foreground mt-2">Current score from AI analysis</p>
                <p className="text-xs text-muted-foreground mt-1">Historical trend will appear as scores are updated over time.</p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[140px] text-center">
                <p className="text-sm text-muted-foreground">Not Available</p>
                <p className="text-xs text-muted-foreground mt-1">Complete onboarding or upload documents for AI analysis.</p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-xl overflow-hidden flex flex-col items-center justify-center" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.07)' }}>
          <div className="h-1 w-full" style={{ background: 'linear-gradient(90deg, #3cb54a, #13b5ea)' }} />
          <div className="p-6 flex flex-col items-center w-full">
            <p className="text-xs text-muted-foreground mb-2 font-medium">Overall Compliance Score</p>
            <GaugeChart value={profile.compliance_score || 0} color="#0096b4" size={160} label="Compliance Health" sublabel={`${profile.risk_level || 'Medium'} Risk`} />
            <div className="flex gap-3 mt-3">
              {[{ label: 'Low', color: 'bg-green-400' }, { label: 'Med', color: 'bg-yellow-400' }, { label: 'High', color: 'bg-red-400' }].map(r => (
                <div key={r.label} className="flex items-center gap-1 text-xs text-muted-foreground">
                  <div className={`w-2.5 h-2.5 rounded-full ${r.color}`} />{r.label}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.07)' }}>
          <div className="h-1" style={{ background: 'linear-gradient(90deg, #13b5ea, #0d2a5e)' }} />
          <div className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-4 h-4 text-primary" />
              <h2 className="font-grotesk font-semibold text-foreground text-sm">Upcoming Deadlines</h2>
            </div>
            {upcomingDeadlines.length > 0 ? (
              <div className="space-y-2">
                {upcomingDeadlines.map((d, i) => (
                  <div key={i} className={`flex items-center justify-between p-2 rounded-lg ${d.urgent ? 'bg-red-400/10 border border-red-400/20' : 'bg-secondary/40'}`}>
                    <div>
                      <p className="text-xs font-medium text-foreground">{d.label}</p>
                      <p className="text-xs text-muted-foreground">{d.type}</p>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0 ${d.urgent ? 'bg-red-400/20 text-red-400' : 'bg-primary/20 text-primary'}`}>{d.date}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">No deadlines extracted yet. Upload compliance documents or ask Compl-i Assistant to analyse your profile.</p>
            )}
            <Link to="/calendar" className="mt-3 block text-center text-xs text-primary hover:underline">View all →</Link>
          </div>
        </div>
      </div>

      {/* Module Compliance Progress Chart */}
      <ComplianceProgressChart modules={moduleScores} />

      {/* Deadline Calendar */}
      <DeadlineCalendar aiDeadlines={upcomingDeadlines} />

      {/* AI Recommendations */}
      {recommendations.length > 0 && (
        <div className="bg-white rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.07)' }}>
          <div className="h-1" style={{ background: 'linear-gradient(90deg, #8b5cf6, #13b5ea)' }} />
          <div className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Bot className="w-4 h-4 text-primary" />
              <h2 className="font-grotesk font-semibold text-foreground text-sm">Compl-i Assistant Recommendations</h2>
            </div>
            <div className="space-y-2">
              {recommendations.map((rec, i) => (
                <div key={i} className="flex items-start gap-2 p-2 rounded-lg bg-primary/5 border border-primary/10">
                  <CheckCircle className="w-3.5 h-3.5 text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-foreground">{rec.trim()}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Business Profile Summary */}
      <div className="bg-white rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.07)' }}>
        <div className="h-1" style={{ background: 'linear-gradient(90deg, #3cb54a, #0d2a5e)' }} />
        <div className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Building className="w-4 h-4 text-primary" />
            <h2 className="font-grotesk font-semibold text-foreground text-sm">Business Profile</h2>
            <Link to="/onboarding" className="ml-auto text-xs text-primary hover:underline">Edit Profile →</Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            {[
              { label: 'Entity', value: profile.entity_name },
              { label: 'Type', value: profile.entity_type },
              { label: 'Industry', value: profile.industry },
              { label: 'Province', value: profile.province },
              { label: 'Registration', value: profile.reg_number || '—' },
              { label: 'VAT', value: profile.vat_registered === 'Yes' ? `Registered (${profile.vat_number || '—'})` : 'Not Registered' },
              { label: 'Employees', value: profile.employee_count || '—' },
              { label: 'Turnover', value: profile.turnover || '—' },
            ].map(item => (
              <div key={item.label}>
                <p className="text-xs text-muted-foreground">{item.label}</p>
                <p className="text-xs font-medium text-foreground mt-0.5">{item.value || '—'}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filing Integrations */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-grotesk font-semibold text-foreground">Online Filing Integrations</h2>
          <Link to="/filing-automation" className="text-xs text-primary hover:underline">Full Filing Module →</Link>
        </div>
        <FilingIntegrationCard compact={true} />
      </div>

      {/* Quick Links */}
      <div>
        <h2 className="font-grotesk font-semibold text-foreground mb-3 text-sm">Quick Navigation</h2>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
          {quickLinks.map((q) => (
            <Link key={q.path} to={q.path}
              className="bg-white rounded-xl p-4 flex flex-col items-center gap-2.5 transition-all group hover:-translate-y-0.5"
              style={{ border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(13,42,94,0.06)' }}
              onMouseEnter={e => e.currentTarget.style.boxShadow = '0 4px 16px rgba(13,42,94,0.14)'}
              onMouseLeave={e => e.currentTarget.style.boxShadow = '0 2px 8px rgba(13,42,94,0.06)'}>
              <div className="p-2 rounded-lg" style={{ background: 'rgba(13,42,94,0.07)' }}>
                <q.icon className={`w-4 h-4 ${q.color}`} />
              </div>
              <span className="text-xs font-medium text-muted-foreground group-hover:text-foreground text-center leading-tight">{q.label}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* Footer Banner */}
      <div className="relative overflow-hidden rounded-xl p-6 flex items-center justify-between"
        style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #1a3a6e 100%)', boxShadow: '0 4px 20px rgba(13,42,94,0.18)' }}>
        <div className="absolute right-0 top-0 w-40 h-40 rounded-full opacity-10" style={{ background: '#3cb54a', transform: 'translate(20%, -20%)' }} />
        <div className="relative">
          <p className="text-xs font-medium mb-1" style={{ color: 'rgba(255,255,255,0.6)' }}>In-App AI Assistant</p>
          <p className="font-grotesk font-bold text-xl text-white">Compl-i™</p>
          <p className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.65)' }}>Accuracy &amp; Ethics Engine: <strong className="text-white">Compl-i Assistant</strong></p>
          <p className="text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>MAICP Protocol · SA-iLabs®™ · Compl-Ai™ SA</p>
        </div>
        <div className="relative flex items-center gap-3">
          <div className="w-14 h-14 rounded-full border-2 border-white/20 flex items-center justify-center"
            style={{ background: 'rgba(19,181,234,0.25)' }}>
            <span className="text-2xl">🤖</span>
          </div>
        </div>
      </div>
    </div>
  );
}