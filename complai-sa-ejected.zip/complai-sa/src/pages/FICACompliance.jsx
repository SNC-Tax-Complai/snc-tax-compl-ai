import { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem } from '../components/ComplianceSection';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

export default function FICACompliance() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocs(demoDocuments); setLoading(false); return; }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
          setDocs(d);
        }
      } catch (e) { console.error('FICA load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const score = profile?.fica_score ?? 0;
  const hasDoc = (cat) => docs.some(d => (d.document_type || '').toLowerCase().includes(cat.toLowerCase()));
  const st = (threshold) => score >= threshold ? 'done' : score > 0 ? 'pending' : 'urgent';

  if (loading) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero badge="FICA Compliance" title="Financial Intelligence Centre Act"
        subtitle="KYC, AML, RMCP, PEP screening, STR reporting, and Accountable Institution obligations under FICA (Act 38 of 2001)." />

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { label: 'STR Filing', value: '15 Days', sub: 'After suspicion arises', color: 'text-red-400' },
          { label: 'CTR Threshold', value: 'R49,999', sub: 'Cash Threshold Reporting', color: 'text-yellow-400' },
          { label: 'Max Penalty', value: 'R10M', sub: 'For FICA non-compliance', color: 'text-orange-400' },
        ].map((c, i) => (
          <div key={i} className="glass-card rounded-xl p-4 neon-glow text-center">
            <div className={`text-2xl font-bold font-grotesk ${c.color}`}>{c.value}</div>
            <div className="text-sm font-medium text-foreground mt-1">{c.label}</div>
            <div className="text-xs text-muted-foreground">{c.sub}</div>
          </div>
        ))}
      </div>

      {profile && (
        <div className="glass-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-grotesk font-semibold text-foreground">Your FICA Compliance Score</h2>
            <span className="text-2xl font-bold font-grotesk text-primary">{score}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${score}%` }} />
          </div>
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">FICA/KYC Document Requirements</h2>
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground mb-3">Required for all bank accounts, financial products, and Accountable Institutions.</p>
          <ChecklistItem label="Certified copy of ID for all directors/members" status={profile?.director_id ? 'done' : st(30)} detail={profile?.director_id ? 'Director ID on file' : 'Upload to vault'} />
          <ChecklistItem label="CIPC registration documents (CoR14.3)" status={profile?.reg_number ? 'done' : st(35)} detail={profile?.reg_number ? `Reg: ${profile.reg_number}` : ''} />
          <ChecklistItem label="Proof of registered address (not older than 3 months)" status={hasDoc('FICA') ? st(40) : 'pending'} />
          <ChecklistItem label="Share register / beneficial ownership declaration" status={st(45)} />
          <ChecklistItem label="Memorandum of Incorporation (MOI)" status={hasDoc('MOI') || hasDoc('CIPC') ? 'done' : st(50)} />
          <ChecklistItem label="Latest bank statement or financial statements" status={st(55)} />
          <ChecklistItem label="Tax clearance / SARS compliance status" status={hasDoc('SARS') || hasDoc('Tax') ? st(50) : 'pending'} />
          <ChecklistItem label="Beneficial ownership register filed with CIPC" status={st(60)} detail="Required from 1 April 2024" />
        </div>
      </div>

      <ExpandableSection title="Accountable Institutions — Are You One?" defaultOpen>
        <p className="text-sm text-muted-foreground mb-3">Schedule 1 of FICA lists Accountable Institutions with full compliance obligations including RMCP, KYC, and STR filing.</p>
        {['Banks and Financial Services Providers', 'Estate Agents and Property Developers', 'Attorneys (trust accounts)', 'Accountants and Auditors', 'Dealers in Motor Vehicles', 'Dealers in Precious Metals and Stones', 'Trust and Company Service Providers (TCSPs)', 'Casinos and Gambling Houses', 'Credit Providers', 'Crypto Asset Service Providers (CASPs)'].map((s, i) => (
          <ChecklistItem key={i} label={s} status="pending" />
        ))}
      </ExpandableSection>

      <ExpandableSection title="Risk Management & Compliance Programme (RMCP)">
        <ChecklistItem label="Formal RMCP document compiled" status={st(50)} />
        <ChecklistItem label="Money Laundering Reporting Officer (MLRO) appointed" status={st(55)} />
        <ChecklistItem label="Customer risk rating methodology defined" status={st(60)} />
        <ChecklistItem label="Enhanced Due Diligence (EDD) for high-risk clients" status={st(65)} />
        <ChecklistItem label="PEP (Politically Exposed Persons) screening process" status={st(70)} />
        <ChecklistItem label="Sanctions screening against UN, OFAC, EU lists" status={st(75)} />
        <ChecklistItem label="Staff training on AML/CTF conducted annually" status={st(80)} />
        <ChecklistItem label="RMCP reviewed annually" status={st(85)} />
      </ExpandableSection>

      <ExpandableSection title="Suspicious Transaction Reports (STR) & CTR">
        <ChecklistItem label="STR filed with FIC within 15 days of suspicion" status="pending" />
        <ChecklistItem label="Cash Threshold Reports (CTR) for transactions ≥ R49,999" status="pending" />
        <ChecklistItem label="Terrorist Property Reports filed if applicable" status="pending" />
        <ChecklistItem label="All reports submitted via FIC goAML portal" status="pending" />
        <ChecklistItem label="Records retained for minimum 5 years" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Beneficial Ownership Register (CIPC)">
        <p className="text-sm text-muted-foreground mb-3">From 1 April 2024, all companies must file a beneficial ownership register with CIPC identifying persons with 5%+ ownership.</p>
        <ChecklistItem label="Identify all persons holding 5%+ beneficial interest" status="pending" />
        <ChecklistItem label="File BO register on CIPC e-Services" status="pending" />
        <ChecklistItem label="Update register within 30 days of any change" status="pending" />
        <ChecklistItem label="Provide register to banks/institutions on request" status="pending" />
      </ExpandableSection>
    </div>
  );
}