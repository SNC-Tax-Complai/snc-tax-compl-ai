import { useState, useEffect } from 'react';
import { Zap, CheckCircle, Clock, AlertTriangle, ExternalLink, Loader2, ChevronRight, RefreshCw, FileText, Building } from 'lucide-react';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

// Filing workflow templates — statutory requirements (NOT mock data)
const WORKFLOW_TEMPLATES = [
  {
    id: 'emp201', name: 'EMP201 — PAYE/SDL/UIF', authority: 'SARS', portal: 'https://efiling.sars.gov.za',
    steps: ['Log in to SARS eFiling', 'Navigate to Returns > Employer > EMP201', 'Enter payroll figures for the month', 'Submit and note reference number', 'Make payment via SARS eFiling or bank'],
    description: 'Monthly payroll tax return for all employers.', act: 'Income Tax Act s11(a) & Fourth Schedule',
    penalty: 'R1,000 per month overdue',
    scoreField: 'sars_score',
  },
  {
    id: 'vat201', name: 'VAT201 Bi-Monthly Return', authority: 'SARS', portal: 'https://efiling.sars.gov.za',
    steps: ['Log in to SARS eFiling', 'Navigate to Returns > VAT > VAT201', 'Enter output and input tax figures', 'Upload supporting documents if required', 'Submit and pay any VAT due'],
    description: 'Bi-monthly VAT return for registered vendors.', act: 'Value-Added Tax Act 89 of 1991 s28',
    penalty: '10% of VAT payable + interest',
    scoreField: 'sars_score',
  },
  {
    id: 'cipc_ar', name: 'CIPC Annual Return', authority: 'CIPC', portal: 'https://eservices.cipc.co.za',
    steps: ['Log in to CIPC e-Services', 'Select Annual Return under Compliance', 'Verify company details and financial year end', 'Pay annual return fee', 'Download and store confirmation receipt'],
    description: 'Annual compliance return for all registered companies.', act: 'Companies Act 71 of 2008 s33',
    penalty: 'R50 – R450 + deregistration risk',
    scoreField: 'cipc_score',
  },
  {
    id: 'coida', name: 'COIDA Return of Earnings (W.As.8)', authority: 'CF', portal: 'https://www.labour.gov.za',
    steps: ['Log in to DoL Compensation Fund portal', 'Complete W.As.8 return of earnings form', 'Calculate and pay annual assessment', 'Submit before penalty accrual', 'Store CF compliance certificate'],
    description: 'Annual return of earnings for all employers under COIDA.', act: 'Compensation for Occupational Injuries Act 130 of 1993 s82',
    penalty: '10% surcharge + claim rejection risk',
    scoreField: 'labour_score',
  },
  {
    id: 'emp501', name: 'EMP501 Annual Reconciliation', authority: 'SARS', portal: 'https://efiling.sars.gov.za',
    steps: ['Download e@syFile Employer software', 'Import payroll data and employee certificates', 'Reconcile EMP201 submissions vs IRP5s', 'Submit reconciliation via e@syFile', 'Issue IRP5/IT3(a) certificates to employees'],
    description: 'Annual PAYE reconciliation matching payroll to tax certificates.', act: 'Income Tax Act Fourth Schedule para 14',
    penalty: 'R1,000 per month + admin penalty',
    scoreField: 'sars_score',
  },
  {
    id: 'irp6', name: 'IRP6 — 1st Provisional Tax', authority: 'SARS', portal: 'https://efiling.sars.gov.za',
    steps: ['Log in to SARS eFiling', 'Navigate to Returns > Income Tax > IRP6', 'Estimate taxable income for the year', 'Calculate provisional tax payable', 'Submit and pay 1st provisional amount'],
    description: 'First provisional tax payment for companies and individuals.', act: 'Income Tax Act Fourth Schedule para 19',
    penalty: '20% underestimation penalty if < 90% of actual tax',
    scoreField: 'sars_score',
  },
];

const statusConfig = {
  overdue: { label: 'Overdue', color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/30', dot: 'bg-red-400' },
  upcoming: { label: 'Upcoming', color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/30', dot: 'bg-yellow-400' },
  pending: { label: 'Pending', color: 'text-blue-400', bg: 'bg-blue-400/10', border: 'border-blue-400/30', dot: 'bg-blue-400' },
  completed: { label: 'Completed', color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/30', dot: 'bg-green-400' },
};

const authorityColor = {
  SARS: 'bg-green-400/10 text-green-400',
  CIPC: 'bg-blue-400/10 text-blue-400',
  CF: 'bg-orange-400/10 text-orange-400',
};

function WorkflowModal({ wf, onClose, onComplete }) {
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [guidance, setGuidance] = useState('');

  const getGuidance = async () => {
    setLoading(true);
    const result = await api.integrations.Core.InvokeLLM({
      prompt: `Compl-i Assistant SA compliance assistant. Provide a concise, practical one-click automation guide for completing "${wf.name}" via ${wf.portal}. 

Include:
- Exact URL path within the portal
- Required information to have ready
- Common errors and how to avoid them
- What to do after submission

Keep it under 200 words. SA-specific, practical guidance only.`,
    });
    setGuidance(result);
    setLoading(false);
  };

  const cfg = statusConfig[wf.status] || statusConfig.pending;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-lg glass-card rounded-2xl border border-primary/20 neon-glow animate-slide-up max-h-[90vh] flex flex-col">
        <div className="flex items-start justify-between p-5 border-b border-primary/20 flex-shrink-0">
          <div>
            <p className="font-grotesk font-bold text-foreground">{wf.name}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className={`text-xs px-2 py-0.5 rounded-full ${authorityColor[wf.authority]}`}>{wf.authority}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color} ${cfg.border}`}>{cfg.label}</span>
              <span className="text-xs text-muted-foreground">Due: {wf.dueDate || 'Date not specified'}</span>
            </div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-lg leading-none">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg text-xs text-foreground">
            <p className="font-medium text-primary mb-1">Legislative Basis</p>
            <p>{wf.act}</p>
            <p className="mt-1 text-red-400">⚠ Penalty: {wf.penalty}</p>
          </div>

          {/* Step tracker */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Filing Steps</p>
              <span className="text-xs text-primary">{step}/{wf.steps.length} complete</span>
            </div>
            <div className="space-y-2">
              {wf.steps.map((s, i) => (
                <button key={i} onClick={() => setStep(i >= step ? i + 1 : i)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border text-left transition-all ${i < step ? 'border-green-400/30 bg-green-400/5' : i === step ? 'border-primary/40 bg-primary/5' : 'border-border bg-secondary/20'}`}>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold ${i < step ? 'bg-green-400 text-white' : i === step ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'}`}>
                    {i < step ? '✓' : i + 1}
                  </div>
                  <p className={`text-xs ${i < step ? 'text-green-400 line-through' : i === step ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>{s}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Compl-i Assistant guidance */}
          {!guidance ? (
            <button onClick={getGuidance} disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2.5 border border-primary/30 text-primary rounded-xl text-sm hover:bg-primary/10 transition-colors disabled:opacity-50">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {loading ? 'Loading Compl-i Assistant guidance...' : 'Get Compl-i Assistant One-Click Guide'}
            </button>
          ) : (
            <div className="p-4 bg-secondary/40 border border-primary/20 rounded-xl text-xs text-foreground leading-relaxed">
              <p className="font-medium text-primary mb-2">Compl-i Assistant Portal Guide</p>
              {guidance}
            </div>
          )}
        </div>

        <div className="p-4 border-t border-primary/20 flex gap-2 flex-shrink-0">
          <a href={wf.portal} target="_blank" rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-primary/30 text-primary rounded-xl text-sm font-medium hover:bg-primary/10 transition-colors">
            <ExternalLink className="w-4 h-4" /> Open {wf.authority} Portal
          </a>
          <button onClick={() => { onComplete(wf.id); onClose(); }}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-green-400/10 border border-green-400/30 text-green-400 rounded-xl text-sm font-medium hover:bg-green-400/20 transition-colors">
            <CheckCircle className="w-4 h-4" /> Mark Complete
          </button>
        </div>
      </div>
    </div>
  );
}

export default function FilingAutomation() {
  const { user } = useAuth();
  const { isDemo, demoProfile } = useDemo();
  const [profile, setProfile] = useState(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [statuses, setStatuses] = useState({});
  const [dueDates, setDueDates] = useState({});
  const [active, setActive] = useState(null);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    if (isDemo) { loadDemoProfile(); return; }
    if (user?.id) loadProfile();
  }, [user, isDemo]);

  const loadProfile = async () => {
    setProfileLoading(true);
    try {
      const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
      if (profiles.length > 0) {
        const p = profiles[0];
        setProfile(p);
        // Derive filing statuses from real compliance scores
        const newStatuses = {};
        const newDates = {};
        WORKFLOW_TEMPLATES.forEach(w => {
          const score = p[w.scoreField] || 0;
          if (score >= 80) {
            newStatuses[w.id] = 'completed';
          } else if (score >= 40) {
            newStatuses[w.id] = 'pending';
          } else {
            newStatuses[w.id] = 'overdue';
          }
          // Get due date from AI-extracted deadlines if available
          let deadlines = [];
          try { deadlines = JSON.parse(p.upcoming_deadlines || '[]'); } catch {}
          const matched = deadlines.find(d => d.label && d.label.toLowerCase().includes(w.id.toLowerCase().split('_')[0]));
          newDates[w.id] = matched?.date || null;
        });
        setStatuses(newStatuses);
        setDueDates(newDates);
      }
    } catch (e) {
      console.error('Failed to load profile', e);
    }
    setProfileLoading(false);
  };

  const loadDemoProfile = () => {
    setProfile(demoProfile);
    const newStatuses = {};
    const newDates = {};
    WORKFLOW_TEMPLATES.forEach(w => {
      const score = demoProfile[w.scoreField] || 0;
      if (score >= 80) newStatuses[w.id] = 'completed';
      else if (score >= 40) newStatuses[w.id] = 'pending';
      else newStatuses[w.id] = 'overdue';
      let deadlines = [];
      try { deadlines = JSON.parse(demoProfile.upcoming_deadlines || '[]'); } catch (_) {}
      const matched = deadlines.find(d => d.label && d.label.toLowerCase().includes(w.id.toLowerCase().split('_')[0]));
      newDates[w.id] = matched?.date || null;
    });
    setStatuses(newStatuses);
    setDueDates(newDates);
    setProfileLoading(false);
  };

  const complete = (id) => setStatuses(p => ({ ...p, [id]: 'completed' }));

  const counts = {
    overdue: WORKFLOW_TEMPLATES.filter(w => statuses[w.id] === 'overdue').length,
    upcoming: WORKFLOW_TEMPLATES.filter(w => statuses[w.id] === 'upcoming').length,
    pending: WORKFLOW_TEMPLATES.filter(w => statuses[w.id] === 'pending').length,
    completed: WORKFLOW_TEMPLATES.filter(w => statuses[w.id] === 'completed').length,
  };

  const shown = WORKFLOW_TEMPLATES.filter(w => filter === 'all' || statuses[w.id] === filter);
  const activeWf = active ? WORKFLOW_TEMPLATES.find(w => w.id === active) : null;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      {activeWf && (
        <WorkflowModal wf={{ ...activeWf, status: statuses[activeWf.id] }}
          onClose={() => setActive(null)} onComplete={complete} />
      )}

      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <div className="relative">
          <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">⚡ Filing Automation Engine</span>
          <h1 className="text-2xl font-bold font-grotesk text-foreground mb-1">Automated Filing Workflow Engine</h1>
          <p className="text-sm text-muted-foreground max-w-xl">Step-by-step guided workflows for SARS eFiling & CIPC e-Services. Track filings, get Compl-i Assistant portal guidance, and mark completions in one place.</p>
          <p className="text-xs text-muted-foreground mt-3 opacity-70">Note: Direct portal integration requires SARS/CIPC API access. This module provides guided workflow automation and deep-links to official portals.</p>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Overdue', count: counts.overdue, color: 'text-red-400', bg: 'bg-red-400/10' },
          { label: 'Upcoming', count: counts.upcoming, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
          { label: 'Pending', count: counts.pending, color: 'text-blue-400', bg: 'bg-blue-400/10' },
          { label: 'Completed', count: counts.completed, color: 'text-green-400', bg: 'bg-green-400/10' },
        ].map(k => (
          <div key={k.label} className="glass-card rounded-xl p-4 text-center border border-primary/10">
            <div className={`text-2xl font-bold font-grotesk ${k.color}`}>{k.count}</div>
            <div className="text-xs text-muted-foreground mt-1">{k.label}</div>
          </div>
        ))}
      </div>

      {/* Filter tabs */}
      <div className="flex gap-1 flex-wrap">
        {['all', 'overdue', 'upcoming', 'pending', 'completed'].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all ${filter === f ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}>
            {f === 'all' ? `All (${WORKFLOW_TEMPLATES.length})` : `${f} (${counts[f] ?? 0})`}
          </button>
        ))}
      </div>

      {/* Workflow cards */}
      <div className="space-y-3">
        {profileLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 text-primary animate-spin" />
          </div>
        ) : !profile ? (
          <div className="glass-card rounded-xl p-8 text-center border border-primary/10">
            <FileText className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No business profile found. Complete onboarding to see your filing workflows.</p>
          </div>
        ) : shown.length === 0 ? (
          <div className="glass-card rounded-xl p-8 text-center border border-primary/10">
            <CheckCircle className="w-10 h-10 text-green-400 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No filings in this category.</p>
          </div>
        ) : shown.map(wf => {
          const st = statuses[wf.id] || 'pending';
          const cfg = statusConfig[st] || statusConfig.pending;
          const dueDateStr = dueDates[wf.id];

          return (
            <button key={wf.id} onClick={() => st !== 'completed' && setActive(wf.id)}
              disabled={st === 'completed'}
              className={`w-full glass-card rounded-xl border p-4 flex items-center gap-4 text-left transition-all ${cfg.border} ${st !== 'completed' ? 'hover:neon-glow cursor-pointer' : 'opacity-60 cursor-default'}`}>
              <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${cfg.dot} ${st === 'overdue' ? 'animate-pulse' : ''}`} />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground text-sm">{wf.name}</p>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <span className={`text-xs px-1.5 py-0.5 rounded ${authorityColor[wf.authority] || 'bg-secondary text-muted-foreground'}`}>{wf.authority}</span>
                  <span className="text-xs text-muted-foreground">{wf.description}</span>
                </div>
              </div>
              <div className="text-right flex-shrink-0 space-y-1">
                <p className="text-xs font-mono text-muted-foreground">{dueDateStr || 'Date not specified'}</p>
              </div>
              <div className={`flex items-center gap-1.5 text-xs font-medium flex-shrink-0 ${cfg.color}`}>
                {cfg.label}
                {st !== 'completed' && <ChevronRight className="w-3.5 h-3.5" />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Portal quick links */}
      <div className="glass-card rounded-xl p-5 border border-primary/10">
        <h3 className="font-grotesk font-semibold text-foreground text-sm mb-4 flex items-center gap-2">
          <ExternalLink className="w-4 h-4 text-primary" /> Official Portal Quick Links
        </h3>
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { name: 'SARS eFiling', url: 'https://efiling.sars.gov.za', desc: 'VAT, PAYE, Income Tax', color: 'text-green-400' },
            { name: 'CIPC e-Services', url: 'https://eservices.cipc.co.za', desc: 'Annual Returns, Directors', color: 'text-blue-400' },
            { name: 'DoL CF Portal', url: 'https://www.labour.gov.za', desc: 'COIDA, UIF, EE Reports', color: 'text-orange-400' },
            { name: 'FIC goAML', url: 'https://goaml.fic.gov.za', desc: 'STRs, CTRs, FICA', color: 'text-purple-400' },
          ].map(p => (
            <a key={p.name} href={p.url} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 bg-secondary/40 rounded-xl border border-border hover:border-primary/30 transition-colors group">
              <ExternalLink className={`w-4 h-4 flex-shrink-0 ${p.color}`} />
              <div>
                <p className="text-xs font-semibold text-foreground group-hover:text-primary transition-colors">{p.name}</p>
                <p className="text-xs text-muted-foreground">{p.desc}</p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}