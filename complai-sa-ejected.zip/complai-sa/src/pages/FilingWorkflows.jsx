import { FileText, ChevronRight, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const workflows = [
  {
    title: 'EMP201 Monthly Payroll', category: 'SARS', status: 'due', urgency: 'urgent',
    steps: ['Capture employee hours & salaries', 'Calculate PAYE, SDL, UIF', 'Submit EMP201 on eFiling', 'Make payment by 7th of month'],
    nextDue: '7 April 2026'
  },
  {
    title: 'IRP6 Provisional Tax (2nd)', category: 'SARS', status: 'pending', urgency: 'warning',
    steps: ['Estimate annual taxable income', 'Calculate provisional tax amount', 'Submit IRP6 on eFiling', 'Pay by 28 February'],
    nextDue: '28 Feb 2026'
  },
  {
    title: 'CIPC Annual Return', category: 'CIPC', status: 'pending', urgency: 'normal',
    steps: ['Log in to CIPC e-Services', 'Confirm company details & turnover', 'Pay annual return fee', 'Confirm submission'],
    nextDue: '15 May 2026'
  },
  {
    title: 'EMP501 Annual Reconciliation', category: 'SARS', status: 'pending', urgency: 'normal',
    steps: ['Reconcile EMP201 submissions', 'Generate IRP5 certificates', 'Submit EMP501 on eFiling', 'Issue IRP5s to employees'],
    nextDue: '31 May 2026'
  },
  {
    title: 'B-BBEE Affidavit Renewal', category: 'B-BBEE', status: 'pending', urgency: 'normal',
    steps: ['Confirm turnover < R10M (EME)', 'Complete sworn affidavit template', 'Sign before Commissioner of Oaths', 'Store in Compliance Vault'],
    nextDue: '30 June 2026'
  },
  {
    title: 'COIDA Return of Earnings', category: 'Labour', status: 'overdue', urgency: 'urgent',
    steps: ['Calculate total payroll for year', 'Complete W.As.8 form online', 'Submit to Compensation Fund', 'Pay annual assessment'],
    nextDue: '31 March 2026'
  },
];

const urgencyStyle = {
  urgent: 'border-red-400/30 bg-red-400/5',
  warning: 'border-yellow-400/30 bg-yellow-400/5',
  normal: 'border-primary/20 bg-primary/5',
};

const statusIcon = { due: Clock, pending: FileText, overdue: AlertCircle, done: CheckCircle };
const statusColor = { due: 'text-yellow-400', pending: 'text-blue-400', overdue: 'text-red-400', done: 'text-green-400' };

export default function FilingWorkflows() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">Filing Workflows</span>
        <h1 className="text-3xl font-bold font-grotesk text-foreground mb-2">Guided Filing Workflows</h1>
        <p className="text-muted-foreground">Step-by-step guides for all statutory filings. Never miss a deadline again.</p>
      </div>

      <div className="grid gap-4">
        {workflows.map((wf, i) => {
          const Icon = statusIcon[wf.status];
          return (
            <div key={i} className={`glass-card rounded-xl border ${urgencyStyle[wf.urgency]} overflow-hidden`}>
              <div className="p-5">
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">{wf.category}</span>
                      <span className={`flex items-center gap-1 text-xs font-medium ${statusColor[wf.status]}`}>
                        <Icon className="w-3 h-3" /> {wf.status.charAt(0).toUpperCase() + wf.status.slice(1)}
                      </span>
                    </div>
                    <h3 className="font-grotesk font-semibold text-foreground">{wf.title}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">Next due: {wf.nextDue}</p>
                  </div>
                  <button className="flex-shrink-0 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:bg-primary/90 transition-colors">
                    Start Filing
                  </button>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {wf.steps.map((step, si) => (
                    <div key={si} className="flex items-center gap-2">
                      <div className="flex items-center gap-1.5 px-2 py-1 bg-secondary rounded-lg">
                        <span className="w-4 h-4 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center font-mono">{si + 1}</span>
                        <span className="text-xs text-muted-foreground">{step}</span>
                      </div>
                      {si < wf.steps.length - 1 && <ChevronRight className="w-3 h-3 text-muted-foreground flex-shrink-0" />}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}