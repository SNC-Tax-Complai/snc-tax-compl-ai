import { useState, useEffect } from 'react';
import { TrendingUp, AlertTriangle, BookOpen, Loader2, RefreshCw, ChevronRight, Zap, Shield, Globe } from 'lucide-react';
import { api } from '@/api/apiClient';

const sectors = [
  { id: 'construction', label: 'Construction', emoji: '🏗️' },
  { id: 'food_beverage', label: 'Food & Beverage', emoji: '🍽️' },
  { id: 'healthcare', label: 'Healthcare', emoji: '⚕️' },
  { id: 'technology', label: 'Technology & ICT', emoji: '💻' },
  { id: 'transport', label: 'Transport & Logistics', emoji: '🚚' },
  { id: 'retail', label: 'Retail & Wholesale', emoji: '🛒' },
  { id: 'agriculture', label: 'Agriculture', emoji: '🌾' },
  { id: 'financial', label: 'Financial Services', emoji: '💰' },
  { id: 'property', label: 'Property & Real Estate', emoji: '🏘️' },
  { id: 'energy', label: 'Energy & Utilities', emoji: '⚡' },
  { id: 'hospitality', label: 'Hospitality & Tourism', emoji: '🏨' },
  { id: 'manufacturing', label: 'Manufacturing', emoji: '🏭' },
];

const riskColors = {
  high: 'text-red-400 bg-red-400/10 border-red-400/30',
  medium: 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30',
  low: 'text-green-400 bg-green-400/10 border-green-400/30',
};

function RiskBadge({ level }) {
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${riskColors[level]}`}>
      {level.charAt(0).toUpperCase() + level.slice(1)} Risk
    </span>
  );
}

function UpdateCard({ update, index }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className={`glass-card rounded-xl border p-4 transition-all ${update.risk === 'high' ? 'border-red-400/20' : update.risk === 'medium' ? 'border-yellow-400/20' : 'border-primary/10'}`}>
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex items-start gap-2 flex-1">
          <div className={`w-2 h-2 rounded-full flex-shrink-0 mt-1.5 ${update.risk === 'high' ? 'bg-red-400 animate-pulse' : update.risk === 'medium' ? 'bg-yellow-400' : 'bg-green-400'}`} />
          <div>
            <p className="text-sm font-semibold text-foreground">{update.title}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{update.legislation} · {update.effective_date}</p>
          </div>
        </div>
        <RiskBadge level={update.risk} />
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed ml-4">{update.summary}</p>
      {update.impact && (
        <>
          <button onClick={() => setExpanded(!expanded)} className="ml-4 mt-2 text-xs text-primary hover:underline flex items-center gap-1">
            {expanded ? 'Hide' : 'Show'} business impact <ChevronRight className={`w-3 h-3 transition-transform ${expanded ? 'rotate-90' : ''}`} />
          </button>
          {expanded && (
            <div className="ml-4 mt-2 p-3 bg-primary/5 border border-primary/20 rounded-lg text-xs text-foreground leading-relaxed">
              <p className="font-medium text-primary mb-1">Impact on your business:</p>
              {update.impact}
            </div>
          )}
        </>
      )}
      {update.action && (
        <div className="ml-4 mt-3 flex items-start gap-2 p-2.5 bg-green-400/5 border border-green-400/20 rounded-lg">
          <Zap className="w-3 h-3 text-green-400 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-green-400 font-medium">{update.action}</p>
        </div>
      )}
    </div>
  );
}

function RiskMatrix({ risks }) {
  if (!risks?.length) return null;
  return (
    <div className="glass-card rounded-xl p-5 border border-primary/10">
      <h3 className="font-grotesk font-semibold text-foreground mb-3 flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 text-yellow-400" /> Compliance Risk Matrix
      </h3>
      <div className="space-y-2">
        {risks.map((r, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-foreground">{r.area}</span>
                <span className={`text-xs font-medium ${r.score >= 70 ? 'text-red-400' : r.score >= 40 ? 'text-yellow-400' : 'text-green-400'}`}>{r.score}%</span>
              </div>
              <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                <div className={`h-full rounded-full transition-all duration-700 ${r.score >= 70 ? 'bg-red-400' : r.score >= 40 ? 'bg-yellow-400' : 'bg-green-400'}`}
                  style={{ width: `${r.score}%` }} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function IndustryDashboard() {
  const [selectedSector, setSelectedSector] = useState(sectors[0]);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);

  const fetchUpdates = async (sector) => {
    setLoading(true);
    setData(null);
    const result = await api.integrations.Core.InvokeLLM({
      prompt: `You are a South African compliance expert. Generate a realistic, detailed compliance intelligence report for the "${sector.label}" sector as of April 2026.

Return JSON with this exact structure:
{
  "headline_risk": "one sentence summary of the biggest compliance risk right now",
  "overall_risk_level": "high|medium|low",
  "updates": [
    {
      "title": "Short title of regulatory update",
      "legislation": "Act name + section",
      "effective_date": "date or 'In Effect'",
      "risk": "high|medium|low",
      "summary": "2-3 sentence summary of the change",
      "impact": "How this specifically impacts a ${sector.label} business in SA",
      "action": "One immediate corrective action to take"
    }
  ],
  "risks": [
    { "area": "Risk area name", "score": 0-100 }
  ],
  "deadlines": [
    { "name": "Filing name", "due": "Month Year", "authority": "SARS|CIPC|DoL|etc" }
  ],
  "quick_wins": ["Quick compliance win 1", "Quick compliance win 2", "Quick compliance win 3"]
}

Provide 5 updates, 5 risks, 4 deadlines, 3 quick wins. All must be specific to South African law and the ${sector.label} sector.`,
      response_json_schema: {
        type: 'object',
        properties: {
          headline_risk: { type: 'string' },
          overall_risk_level: { type: 'string' },
          updates: { type: 'array', items: { type: 'object', properties: { title: { type: 'string' }, legislation: { type: 'string' }, effective_date: { type: 'string' }, risk: { type: 'string' }, summary: { type: 'string' }, impact: { type: 'string' }, action: { type: 'string' } } } },
          risks: { type: 'array', items: { type: 'object', properties: { area: { type: 'string' }, score: { type: 'number' } } } },
          deadlines: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, due: { type: 'string' }, authority: { type: 'string' } } } },
          quick_wins: { type: 'array', items: { type: 'string' } },
        }
      }
    });
    setData(result);
    setLastUpdated(new Date().toLocaleTimeString('en-ZA'));
    setLoading(false);
  };

  useEffect(() => { fetchUpdates(selectedSector); }, []);

  const handleSectorChange = (sector) => {
    setSelectedSector(sector);
    fetchUpdates(sector);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-blue-500/5 pointer-events-none" />
        <div className="relative flex items-start justify-between gap-4 flex-wrap">
          <div>
            <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">
              🇿🇦 Live Regulatory Intelligence
            </span>
            <h1 className="text-3xl font-bold font-grotesk text-foreground mb-2">Industry Compliance Dashboard</h1>
            <p className="text-muted-foreground max-w-xl">AI-powered legislative updates, risk alerts, and regulatory changes tailored to your sector.</p>
          </div>
          {lastUpdated && (
            <div className="text-xs text-muted-foreground flex items-center gap-1.5 flex-shrink-0">
              <Globe className="w-3 h-3 text-primary" /> Updated {lastUpdated}
            </div>
          )}
        </div>
      </div>

      {/* Sector picker */}
      <div className="glass-card rounded-xl p-5 border border-primary/10">
        <p className="text-xs text-muted-foreground mb-3 font-medium uppercase tracking-wider">Select Your Industry</p>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
          {sectors.map(s => (
            <button key={s.id} onClick={() => handleSectorChange(s)}
              className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border text-center transition-all text-xs font-medium ${selectedSector.id === s.id ? 'border-primary bg-primary/10 text-primary neon-glow' : 'border-border bg-secondary/30 text-muted-foreground hover:border-primary/40 hover:text-foreground'}`}>
              <span className="text-xl">{s.emoji}</span>
              <span className="leading-tight">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="glass-card rounded-xl p-16 flex flex-col items-center gap-4 border border-primary/10">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <div className="text-center">
            <p className="text-foreground font-medium">Scanning SA regulatory landscape...</p>
            <p className="text-sm text-muted-foreground mt-1">Analysing legislation for {selectedSector.label} sector</p>
          </div>
        </div>
      ) : data ? (
        <div className="space-y-6">
          {/* Headline risk banner */}
          <div className={`rounded-xl p-4 border flex items-start gap-3 ${riskColors[data.overall_risk_level] || 'border-primary/20 bg-primary/5 text-primary'}`}>
            <Shield className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold">Sector Risk Summary · {selectedSector.label}</p>
              <p className="text-xs mt-0.5 opacity-90">{data.headline_risk}</p>
            </div>
            <RiskBadge level={data.overall_risk_level || 'medium'} />
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Legislative updates — takes 2 cols */}
            <div className="lg:col-span-2 space-y-4">
              <h2 className="font-grotesk font-semibold text-foreground flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" /> Recent Regulatory Updates
                <button onClick={() => fetchUpdates(selectedSector)} className="ml-auto p-1 text-muted-foreground hover:text-primary transition-colors">
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </h2>
              {data.updates?.map((u, i) => <UpdateCard key={i} update={u} index={i} />)}
            </div>

            {/* Sidebar */}
            <div className="space-y-4">
              <RiskMatrix risks={data.risks} />

              {/* Upcoming deadlines */}
              {data.deadlines?.length > 0 && (
                <div className="glass-card rounded-xl p-4 border border-primary/10">
                  <h3 className="font-grotesk font-semibold text-foreground mb-3 text-sm flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-primary" /> Key Deadlines
                  </h3>
                  <div className="space-y-2">
                    {data.deadlines.map((d, i) => (
                      <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-secondary/30">
                        <div>
                          <p className="text-xs font-medium text-foreground">{d.name}</p>
                          <p className="text-xs text-muted-foreground">{d.authority}</p>
                        </div>
                        <span className="text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full">{d.due}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick wins */}
              {data.quick_wins?.length > 0 && (
                <div className="glass-card rounded-xl p-4 border border-green-400/20">
                  <h3 className="font-grotesk font-semibold text-foreground mb-3 text-sm flex items-center gap-2">
                    <Zap className="w-4 h-4 text-green-400" /> Quick Compliance Wins
                  </h3>
                  <div className="space-y-2">
                    {data.quick_wins.map((w, i) => (
                      <div key={i} className="flex items-start gap-2 p-2 rounded-lg bg-green-400/5">
                        <span className="w-4 h-4 rounded-full bg-green-400/20 text-green-400 text-xs flex items-center justify-center font-bold flex-shrink-0">{i + 1}</span>
                        <p className="text-xs text-foreground">{w}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}