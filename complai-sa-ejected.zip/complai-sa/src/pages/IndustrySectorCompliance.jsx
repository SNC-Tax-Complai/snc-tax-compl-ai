import { Zap, Building, Truck, Coffee, Cpu, Heart, Hammer, ShoppingBag, Leaf, DollarSign } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem, DeadlineBadge } from '../components/ComplianceSection';
import { useState, useEffect } from 'react';
import { api } from '@/api/apiClient';

const sectors = [
  { id: 'construction', label: 'Construction', icon: Hammer, color: 'text-yellow-400' },
  { id: 'food', label: 'Food & Beverage', icon: Coffee, color: 'text-orange-400' },
  { id: 'health', label: 'Healthcare', icon: Heart, color: 'text-red-400' },
  { id: 'tech', label: 'Technology & ICT', icon: Cpu, color: 'text-blue-400' },
  { id: 'transport', label: 'Transport & Logistics', icon: Truck, color: 'text-green-400' },
  { id: 'retail', label: 'Retail & Wholesale', icon: ShoppingBag, color: 'text-pink-400' },
  { id: 'agriculture', label: 'Agriculture', icon: Leaf, color: 'text-emerald-400' },
  { id: 'financial', label: 'Financial Services', icon: DollarSign, color: 'text-cyan-400' },
  { id: 'property', label: 'Property & Real Estate', icon: Building, color: 'text-purple-400' },
  { id: 'energy', label: 'Energy & Utilities', icon: Zap, color: 'text-yellow-300' },
];

const sectorData = {
  construction: {
    regulator: 'Department of Employment & Labour / NHBRC / CIDB',
    items: [
      { label: 'CIDB Registration (grade 1–9 depending on contract value)', status: 'pending' },
      { label: 'NHBRC Enrolment (home builders)', status: 'pending', detail: 'Mandatory under Housing Consumers Protection Act' },
      { label: 'Construction Regulations 2014 (OHS) compliance', status: 'pending' },
      { label: 'Health & Safety Plan for each project', status: 'pending' },
      { label: 'Construction Work Permit (projects > R13.5M or 30 days)', status: 'pending' },
      { label: 'Principal Contractor designation and appointment', status: 'pending' },
      { label: 'Site-specific risk assessment', status: 'pending' },
      { label: 'COID registration and Return of Earnings', status: 'pending' },
      { label: 'Professional indemnity / public liability insurance', status: 'pending' },
      { label: 'Building plans approved by local municipality', status: 'pending' },
      { label: 'Certificate of Occupancy on completion', status: 'pending' },
    ]
  },
  food: {
    regulator: 'DAFF / DoH / Municipal Health / NRCS',
    items: [
      { label: 'Registration of Foodstuffs, Cosmetics & Disinfectants Act compliance', status: 'pending' },
      { label: 'Certificate of Acceptability (R638 Food Regulations)', status: 'pending', detail: 'Annual renewal' },
      { label: 'HACCP plan (Hazard Analysis Critical Control Points)', status: 'pending' },
      { label: 'National Regulator for Compulsory Specifications (NRCS) compliance', status: 'pending' },
      { label: 'Labelling compliance per R146 Food Labelling Regulations', status: 'pending' },
      { label: 'Liquor license if serving alcohol', status: 'pending' },
      { label: 'Food handler certificates (annual hygiene training)', status: 'pending' },
      { label: 'Municipal business license for food establishment', status: 'pending' },
      { label: 'Pest control contract and log', status: 'pending' },
      { label: 'Cold chain and temperature monitoring records', status: 'pending' },
    ]
  },
  health: {
    regulator: 'HPCSA / DoH / SAHPRA / NDoH',
    items: [
      { label: 'HPCSA registration for all healthcare practitioners', status: 'pending' },
      { label: 'SAHPRA license for medicines and medical devices', status: 'pending' },
      { label: 'Department of Health: facility registration', status: 'pending' },
      { label: 'National Health Act compliance (patient rights)', status: 'pending' },
      { label: 'Medical Waste disposal plan (Hazardous Substances Act)', status: 'pending' },
      { label: 'Occupational Health regulations for clinical staff', status: 'pending' },
      { label: 'POPIA — health data: explicit patient consent', status: 'pending' },
      { label: 'Pharmacy license (SAPC) if dispensing medicines', status: 'pending' },
      { label: 'Radiation Safety Officer (if X-ray equipment)', status: 'pending' },
      { label: 'Professional indemnity insurance', status: 'pending' },
    ]
  },
  tech: {
    regulator: 'ICASA / POPIA Regulator / FSCA (fintechs)',
    items: [
      { label: 'ICASA license if providing electronic communications services', status: 'pending' },
      { label: 'POPIA compliance (data-heavy business)', status: 'pending' },
      { label: 'FSCA registration if providing financial services / fintech', status: 'pending' },
      { label: 'Consumer Protection Act (CPA) website terms compliance', status: 'pending' },
      { label: 'Electronic Communications & Transactions Act (ECTA) compliance', status: 'pending' },
      { label: 'Copyright Act compliance for software', status: 'pending' },
      { label: 'Cybersecurity policy and incident response plan', status: 'pending' },
      { label: 'SARS: R&D tax incentive (Section 11D) if applicable', status: 'pending' },
    ]
  },
  transport: {
    regulator: 'RTMC / CBRTA / SAMSA / NDoT',
    items: [
      { label: 'Operating license from Provincial Regulatory Entity (PRE)', status: 'pending' },
      { label: 'Cross-Border Road Transport Permit (CBRTA) for cross-border ops', status: 'pending' },
      { label: 'Vehicle roadworthiness certificates current', status: 'pending' },
      { label: 'Driver PDP (Professional Driving Permit) valid', status: 'pending' },
      { label: 'Dangerous Goods transport permit (if applicable)', status: 'pending' },
      { label: 'National Land Transport Act compliance', status: 'pending' },
      { label: 'Fleet insurance (goods in transit + public liability)', status: 'pending' },
      { label: 'Tachograph / logbook records maintained', status: 'pending' },
      { label: 'SAMSA certificate if maritime operations', status: 'pending' },
    ]
  },
  retail: {
    regulator: 'NRCS / NCC / CPA / Municipal',
    items: [
      { label: 'Consumer Protection Act (CPA) compliance', status: 'pending', detail: 'Returns policy, warranty obligations, pricing' },
      { label: 'NRCS compulsory specifications for products', status: 'pending' },
      { label: 'Liquor license if selling alcohol (retail bottle store)', status: 'pending' },
      { label: 'Tobacco Products Control Act compliance', status: 'pending' },
      { label: 'Price display regulations complied with', status: 'pending' },
      { label: 'National Credit Act (NCA) if providing credit/lay-by', status: 'pending' },
      { label: 'PCI DSS compliance if processing card payments', status: 'pending' },
      { label: 'Import/export permits for regulated goods', status: 'pending' },
    ]
  },
  agriculture: {
    regulator: 'DAFF / SARS / PPECB / NDoA',
    items: [
      { label: 'Farming entity registration with DAFF', status: 'pending' },
      { label: 'PPECB certification for fresh produce exports', status: 'pending' },
      { label: 'Pesticide / agrochemical registration and use records', status: 'pending' },
      { label: 'Water use license (DWS) for irrigation', status: 'pending' },
      { label: 'Animal health and veterinary compliance (DALRRD)', status: 'pending' },
      { label: 'Organic certification if marketing as organic', status: 'pending' },
      { label: 'Labour law compliance (farm workers — BCEA Section 8)', status: 'pending' },
      { label: 'Environmental compliance (alien invasive plant management)', status: 'pending' },
      { label: 'AgriSETA registration for skills development', status: 'pending' },
    ]
  },
  financial: {
    regulator: 'FSCA / SARB / FIC / PA',
    items: [
      { label: 'FSP license from FSCA (Financial Services Provider)', status: 'pending' },
      { label: 'Key Individual (KI) and Representative qualifications', status: 'pending' },
      { label: 'Fit and proper requirements met (FAIS)', status: 'pending' },
      { label: 'FICA Accountable Institution registration', status: 'pending' },
      { label: 'RMCP and AML/CTF programme in place', status: 'pending' },
      { label: 'PI insurance (Professional Indemnity) for FSPs', status: 'pending' },
      { label: 'Credit provider registration with NCR (NCA)', status: 'pending' },
      { label: 'Crypto Asset Service Provider (CASP) — FSCA licensing', status: 'pending' },
      { label: 'Annual compliance report to FSCA', status: 'pending' },
    ]
  },
  property: {
    regulator: 'PPRA / EAAB / Conveyancing / Municipal',
    items: [
      { label: 'PPRA registration (Property Practitioners Regulatory Authority)', status: 'pending' },
      { label: 'Valid Fidelity Fund Certificate (FFC)', status: 'pending', detail: 'Annual renewal — mandatory' },
      { label: 'Trust account audit (annual) for rental management', status: 'pending' },
      { label: 'FICA compliance (estate agents are Accountable Institutions)', status: 'pending' },
      { label: 'Municipal rates clearance certificate on transfer', status: 'pending' },
      { label: 'Electrical CoC, Gas CoC, Beetle CoC on sale', status: 'pending' },
      { label: 'Rental Housing Act compliance (Rental Housing Tribunal)', status: 'pending' },
      { label: 'Sectional Titles Act compliance if managing body corporate', status: 'pending' },
    ]
  },
  energy: {
    regulator: 'NERSA / DoE / DMRE',
    items: [
      { label: 'NERSA license for electricity generation/trading', status: 'pending' },
      { label: 'Small-scale embedded generation (SSEG) — municipal notification', status: 'pending', detail: 'Feed-in tariff agreement if exporting' },
      { label: 'Gas installation CoC (SAQCC Gas)', status: 'pending' },
      { label: 'Petroleum Products Act compliance for fuel retail', status: 'pending' },
      { label: 'Environmental Impact Assessment for large installations', status: 'pending' },
      { label: 'SANS 10142 electrical installation compliance', status: 'pending' },
      { label: 'Grid tie-in agreement with municipality/Eskom', status: 'pending' },
    ]
  }
};

export default function IndustrySectorCompliance() {
  const [selected, setSelected] = useState('construction');
  const data = sectorData[selected];

  // Load user's industry from their BusinessProfile and auto-select matching sector
  useEffect(() => {
    (async () => {
      try {
        const { user } = await api.auth.me();
        if (!user?.id) return;
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0 && profiles[0].industry) {
          const ind = profiles[0].industry.toLowerCase();
          const match = sectors.find(s => ind.includes(s.label.toLowerCase().split(' ')[0]) || s.label.toLowerCase().includes(ind.split(' ')[0]));
          if (match) setSelected(match.id);
        }
      } catch (_) {}
    })();
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero
        badge="Industry & Sector Compliance"
        title="Cross-Industry Regulatory Compliance"
        subtitle="Select your industry to view specific regulatory bodies, permits, licenses, and inspections required in South Africa."
      />

      {/* Sector selector */}
      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">Select Your Industry / Sector</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {sectors.map((s) => (
            <button key={s.id} onClick={() => setSelected(s.id)}
              className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all text-center ${selected === s.id ? 'border-primary bg-primary/10 neon-glow' : 'border-border bg-secondary/30 hover:border-primary/40'}`}>
              <s.icon className={`w-6 h-6 ${s.color}`} />
              <span className="text-xs font-medium text-foreground leading-tight">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Regulator badge */}
      <div className="glass-card rounded-xl p-4 border border-primary/20">
        <p className="text-xs text-muted-foreground">Primary Regulatory Bodies</p>
        <p className="text-sm font-semibold text-primary mt-1">{data.regulator}</p>
      </div>

      {/* Checklist */}
      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">
          {sectors.find(s => s.id === selected)?.label} — Compliance Checklist
        </h2>
        <div className="space-y-2">
          {data.items.map((item, i) => (
            <ChecklistItem key={i} label={item.label} status={item.status} detail={item.detail} />
          ))}
        </div>
      </div>

      {/* Cross-sector obligations */}
      <ExpandableSection title="Cross-Sector Obligations (All Industries)" defaultOpen>
        <p className="text-sm text-muted-foreground mb-3">Regardless of sector, all South African businesses must comply with:</p>
        {[
          'CIPC Annual Return',
          'SARS Income / Company Tax (ITR12/ITR14)',
          'PAYE/UIF/SDL via EMP201 monthly',
          'POPIA — Protection of personal information',
          'FICA — if Accountable Institution',
          'OHS Act No. 85 of 1993',
          'Consumer Protection Act (CPA) No. 68 of 2008',
          'B-BBEE — affidavit or certificate',
          'Municipal business license where applicable',
          'COIDA — Compensation Fund registration',
          'National Minimum Wage Act compliance',
        ].map((s, i) => <ChecklistItem key={i} label={s} status="pending" />)}
      </ExpandableSection>

      <ExpandableSection title="Workmen's Compensation Fund (COIDA) — All Sectors">
        <p className="text-sm text-muted-foreground mb-3">The Compensation for Occupational Injuries and Diseases Act (COIDA) applies to ALL employers with employees.</p>
        <ChecklistItem label="Register with Compensation Fund (CF) — Department of Labour" status="pending" />
        <ChecklistItem label="Submit Return of Earnings (W.As.8) by 31 March annually" status="pending" />
        <ChecklistItem label="Pay annual assessment based on payroll and risk category" status="pending" />
        <ChecklistItem label="Report accidents within 7 days (W.CL.1 form)" status="pending" detail="Serious injuries: notify immediately" urgent />
        <ChecklistItem label="Medical aid expenses for work-related injuries covered by CF" status="pending" />
        <ChecklistItem label="Keep accident register accessible on-site" status="pending" />
        <ChecklistItem label="No opt-out: COIDA is mandatory for all employers" status="done" />
      </ExpandableSection>

      <ExpandableSection title="National Regulator for Compulsory Specifications (NRCS)">
        <p className="text-sm text-muted-foreground mb-3">Products sold in SA must meet NRCS standards. Applies to manufacturers, importers, and retailers.</p>
        <ChecklistItem label="Identify if your products are subject to compulsory specs" status="pending" />
        <ChecklistItem label="Apply for Letter of Authority (LoA) from NRCS" status="pending" />
        <ChecklistItem label="Product testing at SANAS-accredited laboratory" status="pending" />
        <ChecklistItem label="NRCS mark of approval on product/packaging" status="pending" />
        <ChecklistItem label="Market surveillance compliance (inspections)" status="pending" />
      </ExpandableSection>
    </div>
  );
}