import { useState } from 'react';
import { Link2, CheckCircle, Clock, Zap, Database, RefreshCw } from 'lucide-react';
import SageConnect from '@/components/SageConnect';

const integrations = [
  {
    name: 'Sage Business Cloud', logo: '🟢', status: 'available', category: 'Accounting',
    desc: 'Two-way sync: contacts, invoices, bank transactions, chart of accounts, payments.',
    features: ['OAuth2 Authentication', 'Contacts & Suppliers', 'Sales/Purchase Invoices', 'Bank Reconciliation', 'VAT Returns'],
  },
  {
    name: 'SARS eFiling', logo: '🔵', status: 'coming', category: 'Tax',
    desc: 'Direct integration with SARS eFiling portal for EMP201, VAT201, IRP6 submissions.',
    features: ['EMP201 Auto-submit', 'VAT201 Filing', 'IRP6 Provisional Tax', 'Tax Clearance'],
  },
  {
    name: 'Xero', logo: '🔷', status: 'coming', category: 'Accounting',
    desc: 'Alternative accounting integration for Xero users. Same features as Sage.',
    features: ['Invoices & Bills', 'Bank Feeds', 'Contacts', 'Reports'],
  },
  {
    name: 'QuickBooks', logo: '🟦', status: 'coming', category: 'Accounting',
    desc: 'QuickBooks Online integration for full accounting sync.',
    features: ['Invoices', 'Expenses', 'Bank Sync', 'Reports'],
  },
  {
    name: 'CIPC e-Services', logo: '🏛️', status: 'coming', category: 'Corporate',
    desc: 'Auto-retrieve company status, file annual returns, submit director changes.',
    features: ['Company Status Check', 'Annual Returns', 'Director Amendments'],
  },
  {
    name: 'FIC goAML Portal', logo: '🔐', status: 'planned', category: 'FICA',
    desc: 'Suspicious Transaction Reports and Cash Threshold Reports via goAML.',
    features: ['STR Filing', 'CTR Reporting', 'Audit Trail'],
  },
  {
    name: 'Compensation Fund', logo: '⚕️', status: 'planned', category: 'Labour',
    desc: 'COIDA Return of Earnings submission and annual assessment payment.',
    features: ['W.As.8 Filing', 'Assessment Payment', 'Incident Reports'],
  },
  {
    name: 'WhatsApp Business API', logo: '💬', status: 'available', category: 'Notifications',
    desc: 'Emma-i™ compliance assistant via WhatsApp. Deadline reminders and quick filings.',
    features: ['Compliance Alerts', 'Deadline Reminders', 'Emma-i™ Chat', 'Document Sharing'],
  },
];

const statusStyle = {
  available: { label: 'Available', color: 'text-green-400', bg: 'bg-green-400/10 border-green-400/30' },
  coming: { label: 'Coming Soon', color: 'text-yellow-400', bg: 'bg-yellow-400/10 border-yellow-400/30' },
  planned: { label: 'Planned', color: 'text-blue-400', bg: 'bg-blue-400/10 border-blue-400/30' },
};

export default function Integrations() {
  const [sageOpen, setSageOpen] = useState(false);
  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      {sageOpen && <SageConnect onClose={() => setSageOpen(false)} />}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">Integrations</span>
        <h1 className="text-3xl font-bold font-grotesk text-foreground mb-2">Platform Integrations</h1>
        <p className="text-muted-foreground">Connect AfriCompliance™ with your accounting, tax, and government portals. Provider-agnostic architecture.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {integrations.map((int, i) => {
          const s = statusStyle[int.status];
          return (
            <div key={i} className="glass-card rounded-xl p-5 border border-primary/10 hover:border-primary/30 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{int.logo}</span>
                  <div>
                    <p className="font-grotesk font-semibold text-foreground">{int.name}</p>
                    <p className="text-xs text-muted-foreground">{int.category}</p>
                  </div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full border font-medium ${s.bg} ${s.color}`}>{s.label}</span>
              </div>
              <p className="text-sm text-muted-foreground mb-3">{int.desc}</p>
              <div className="flex flex-wrap gap-1.5">
                {int.features.map((f, fi) => (
                  <span key={fi} className="text-xs px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">{f}</span>
                ))}
              </div>
              {int.status === 'available' && (
                <button
                  onClick={() => int.name === 'Sage Business Cloud' && setSageOpen(true)}
                  className="mt-4 w-full py-2 bg-primary/10 border border-primary/30 text-primary rounded-lg text-sm font-medium hover:bg-primary hover:text-primary-foreground transition-colors flex items-center justify-center gap-2">
                  <Link2 className="w-4 h-4" /> Connect
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}