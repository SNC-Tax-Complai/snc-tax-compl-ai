import { useState, useEffect } from 'react';
import { Calendar, Loader2 } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem, DeadlineBadge } from '../components/ComplianceSection';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

export default function LabourCompliance() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocs(demoDocuments); setLoading(false); return; }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
          setDocs(d);
        }
      } catch (e) { console.error('Labour load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const score = profile?.labour_score ?? 0;
  const hasEmployees = profile?.employee_count && parseInt(profile.employee_count) > 0;
  const hasDoc = (cat) => docs.some(d => (d.document_type || '').toLowerCase().includes(cat.toLowerCase()));
  const st = (threshold) => score >= threshold ? 'done' : score > 0 ? 'pending' : 'urgent';

  if (loading) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero badge="Labour Law Compliance" title="Employment & Labour Compliance"
        subtitle="BCEA, LRA, UIF, SDL, COIDA, Employment Equity, and all employer obligations under South African labour law." />

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: 'Min Wage (2026)', value: 'R28.79', sub: 'Per hour (NMW)', color: 'text-green-400' },
          { label: 'UIF Contribution', value: '2%', sub: '1% employer + 1% employee', color: 'text-blue-400' },
          { label: 'SDL Threshold', value: 'R500K', sub: 'Annual payroll', color: 'text-yellow-400' },
          { label: 'Annual Leave', value: '21 days', sub: 'Minimum per year (BCEA)', color: 'text-purple-400' },
        ].map((c, i) => (
          <div key={i} className="glass-card rounded-xl p-4 neon-glow text-center">
            <div className={`text-2xl font-bold font-grotesk ${c.color}`}>{c.value}</div>
            <div className="text-sm font-medium text-foreground mt-1">{c.label}</div>
            <div className="text-xs text-muted-foreground">{c.sub}</div>
          </div>
        ))}
      </div>

      {profile && (
        <div className="glass-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-grotesk font-semibold text-foreground">Your Labour Compliance Score</h2>
            <span className="text-2xl font-bold font-grotesk text-primary">{score}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${score}%` }} />
          </div>
          {hasEmployees && <p className="text-xs text-muted-foreground mt-2">Employees: {profile.employee_count}</p>}
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4 flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> Labour Filing Deadlines</h2>
        <div className="space-y-2">
          <DeadlineBadge label="UIF Declarations (UI-19) — Monthly" date="7th of each month" urgent />
          <DeadlineBadge label="SDL via EMP201 — Monthly" date="7th of each month" urgent />
          <DeadlineBadge label="Employment Equity Report (EEA2/EEA4)" date="15 January 2027" />
          <DeadlineBadge label="COIDA Return of Earnings (W.As.8)" date="31 March 2027" />
          <DeadlineBadge label="Workplace Skills Plan (WSP)" date="30 April 2026" />
          <DeadlineBadge label="Annual Training Report (ATR)" date="30 April 2026" />
        </div>
      </div>

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">Compliance Checklist</h2>
        <div className="space-y-2">
          <ChecklistItem label="Written employment contracts for all staff" status={st(40)} detail="Required by BCEA Section 29" />
          <ChecklistItem label="Registered as employer with Dept of Employment & Labour" status={hasEmployees ? st(30) : 'pending'} />
          <ChecklistItem label="UIF registered and declarations submitted monthly" status={st(50)} />
          <ChecklistItem label="SDL registered if payroll exceeds R500K" status={st(55)} />
          <ChecklistItem label="COIDA registered with Compensation Fund" status={hasDoc('COIDA') || hasDoc('Labour') ? 'done' : st(45)} />
          <ChecklistItem label="National Minimum Wage compliance" status={st(60)} detail="R28.79/hr from 1 March 2026" />
          <ChecklistItem label="Leave records maintained (BCEA)" status={st(65)} />
          <ChecklistItem label="Payslips issued to all employees monthly" status={st(70)} />
          <ChecklistItem label="Employment Equity Plan in place (50+ employees)" status={st(75)} />
          <ChecklistItem label="Workplace Skills Plan submitted to SETA" status={st(80)} />
        </div>
      </div>

      <ExpandableSection title="Basic Conditions of Employment Act (BCEA)" defaultOpen>
        <ChecklistItem label="Working hours: max 45 hrs/week, 9 hrs/day (5-day week)" status={st(50)} />
        <ChecklistItem label="Overtime: max 10 hrs/week at 1.5x rate" status="pending" />
        <ChecklistItem label="Annual leave: 21 consecutive days per year" status={st(60)} />
        <ChecklistItem label="Sick leave: 30 days over 3-year cycle" status="pending" />
        <ChecklistItem label="Family responsibility leave: 3 days per year" status="pending" />
        <ChecklistItem label="Maternity leave: 4 consecutive months (unpaid BCEA)" status="pending" />
        <ChecklistItem label="Notice period: per contract (minimum per BCEA schedule)" status="pending" />
        <ChecklistItem label="Certificate of service on termination" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Labour Relations Act (LRA) — Dismissals & Disputes">
        <ChecklistItem label="Fair dismissal procedures followed (substantive & procedural)" status="pending" />
        <ChecklistItem label="Disciplinary code and procedure in place" status="pending" />
        <ChecklistItem label="Retrenchment process per Section 189 if applicable" status="pending" />
        <ChecklistItem label="CCMA referral rights communicated to employees" status="pending" />
        <ChecklistItem label="Union recognition if 50%+ members in workplace" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="COIDA — Compensation for Occupational Injuries">
        <ChecklistItem label="Register with Compensation Fund within 7 days of first hire" status={hasDoc('COIDA') ? 'done' : 'pending'} />
        <ChecklistItem label="Submit Return of Earnings (W.As.8) annually by 31 March" status="pending" />
        <ChecklistItem label="Report workplace accidents within 7 days (W.CL.1)" status="pending" />
        <ChecklistItem label="Keep accident register on-site" status="pending" />
        <ChecklistItem label="Pay annual COIDA assessment" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Employment Equity Act (EEA)">
        <ChecklistItem label="Designate if 50+ employees (or turnover threshold met)" status="pending" />
        <ChecklistItem label="Conduct workforce analysis (EEA1)" status="pending" />
        <ChecklistItem label="Develop Employment Equity Plan (EEA2)" status="pending" />
        <ChecklistItem label="Submit annual EEA report by 15 January" status="pending" />
        <ChecklistItem label="Assign EE manager/committee" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Skills Development — SETA & WSP">
        <ChecklistItem label="Identify relevant SETA for your industry" status="pending" />
        <ChecklistItem label="Register with SETA before 30 April" status="pending" />
        <ChecklistItem label="Submit Workplace Skills Plan (WSP)" status="pending" />
        <ChecklistItem label="Submit Annual Training Report (ATR)" status="pending" />
        <ChecklistItem label="Claim 20% mandatory grant from SETA" status="pending" />
      </ExpandableSection>
    </div>
  );
}