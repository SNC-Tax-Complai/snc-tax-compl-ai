import { useState } from 'react';
import { Shield, ChevronDown, ChevronUp, FileText, Lock, AlertTriangle, Copyright, Users, Server, Globe, Zap } from 'lucide-react';

const sections = [
  {
    id: 'ownership',
    icon: Copyright,
    title: 'Ownership & Copyright',
    color: 'text-primary',
    content: `© 2024–${new Date().getFullYear()} SNC-TAX. All Rights Reserved.

COMPL-AI™ SA is the exclusive intellectual property of SNC-TAX, a registered South African tax practice. The Compl-Ai™ SA platform, brand name, all associated content, modules, workflows, AI logic, and user interfaces are protected under South African copyright law and the Copyright Act No. 98 of 1978 (as amended).

Developer Agency: SA-iLabs®™ (Registered in South Africa)
In-App AI: Compl-i™ — the AI assistant embedded in the Compl-Ai™ SA platform.
Accuracy & Ethics Engine: Emma-i™ (MAICP Protocol) — a proprietary AI framework deployed and operated exclusively by SA-iLabs®™ on behalf of SNC-TAX. Emma-i™ is the implementation framework for the MAICP protocol by SA-iLabs®™ and serves as the Accuracy and Ethical Engine for the In-App AI, Compl-i™.

Unauthorised reproduction, copying, distribution, modification, or commercial use of any part of this platform — including its code, design, brand assets, or content — is strictly prohibited without prior written consent from SNC-TAX.

All trademarks, including Compl-Ai™, Compl-i™, Emma-i™, SA-iLabs®™, and SNC-TAX are the property of their respective owners.`
  },
  {
    id: 'tos',
    icon: FileText,
    title: 'Terms of Service',
    color: 'text-blue-500',
    content: `By accessing or using the Compl-Ai™ SA platform ("the Platform"), you ("the User") agree to be bound by these Terms of Service. If you do not agree, you must immediately cease use of the Platform.

1. ACCEPTANCE OF TERMS
Your continued use of the Platform constitutes acceptance of these Terms, the Privacy Policy, and all applicable South African laws.

2. LICENSE TO USE
SNC-TAX grants you a limited, non-exclusive, non-transferable, revocable license to access and use the Platform solely for your internal compliance management purposes, subject to these Terms.

3. PROHIBITED USES
You may not: (a) use the Platform for any unlawful purpose; (b) attempt to gain unauthorized access to any portion of the Platform; (c) reverse engineer, decompile, or disassemble any part of the Platform; (d) resell, sublicense, or commercially exploit the Platform without written consent; (e) upload malicious code or interfere with Platform operations.

4. USER ACCOUNTS
You are responsible for maintaining the confidentiality of your login credentials. You agree to notify SNC-Tax | SNC-NPC immediately of any unauthorized use of your account.

5. MODIFICATIONS
SNC-TAX reserves the right to modify, suspend, or discontinue the Platform (or any part thereof) at any time with 30 days notice where reasonably practicable.

6. GOVERNING LAW
These Terms are governed by the laws of the Republic of South Africa. Any disputes shall be subject to the exclusive jurisdiction of the South African courts.`
  },
  {
    id: 'terms_of_use',
    icon: Globe,
    title: 'Terms of Use',
    color: 'text-cyan-500',
    content: `The following Terms of Use apply to all visitors and registered users of Compl-Ai™ SA.

ACCEPTABLE USE
The Platform is designed to assist South African SMMEs in tracking and managing statutory compliance obligations. It is intended for lawful, good-faith use only.

ACCURACY OF INFORMATION
While SNC-TAX and SA-iLabs®™ make reasonable efforts to ensure information is current and accurate, compliance requirements change frequently. Users are solely responsible for verifying all compliance obligations with the relevant regulatory bodies (SARS, CIPC, Department of Employment & Labour, etc.) or a registered professional.

THIRD-PARTY LINKS
The Platform may contain links to external government portals and third-party websites. SNC-TAX does not endorse or take responsibility for the content of third-party sites.

SYSTEM AVAILABILITY
The Platform is provided on an "as available" basis. Planned maintenance, load-shedding, or force majeure events may result in downtime. SNC-TAX will endeavour to provide advance notice where possible.

FEEDBACK AND CONTENT
Any feedback, suggestions, or content you submit to the Platform may be used by SNC-TAX to improve the service without obligation to you.`
  },
  {
    id: 'popia',
    icon: Lock,
    title: 'POPIA Privacy Notice & Consent',
    color: 'text-green-500',
    content: `This Privacy Notice is issued in accordance with the Protection of Personal Information Act, No. 4 of 2013 ("POPIA") and the Information Regulator's guidelines.

RESPONSIBLE PARTY
SNC-TAX (hereinafter "we", "us", "our")
Contact: [privacy@snctax.co.za]

INFORMATION OFFICER
As required by POPIA, SNC-TAX has appointed a designated Information Officer responsible for ensuring compliance with POPIA.

PERSONAL INFORMATION WE COLLECT
We may collect: full name, email address, contact number, business name, CIPC registration number, tax reference numbers, director information, FICA/KYC documentation, and compliance-related business data.

PURPOSE OF PROCESSING
Your personal information is processed to: (a) provide compliance tracking and filing services; (b) send compliance deadline reminders; (c) generate compliance reports; (d) improve the Platform; (e) comply with our own legal obligations.

LAWFUL BASIS
Processing is based on: (a) your consent; (b) contractual necessity; (c) legitimate interests of SNC-TAX.

DATA RETENTION
We retain your personal information for as long as your account is active, or as required by South African law (generally 5 years for financial records).

DATA SECURITY
We implement appropriate technical and organisational measures to protect your personal information against unauthorised access, alteration, disclosure, or destruction.

DATA RESIDENCY
Your data is stored on South African servers in compliance with POPIA's data residency principles.

YOUR RIGHTS UNDER POPIA
You have the right to: access your personal information; request correction of inaccurate data; request deletion (subject to legal retention requirements); object to processing; lodge a complaint with the Information Regulator (inforeg.org.za).

COOKIES
We use essential cookies to maintain session security. No third-party advertising cookies are used.

CONTACT
To exercise your POPIA rights, contact: privacy@snctax.co.za`
  },
  {
    id: 'disclaimer',
    icon: AlertTriangle,
    title: 'Legal Disclaimer & Waiver',
    color: 'text-yellow-500',
    content: `IMPORTANT — PLEASE READ CAREFULLY

NOT LEGAL OR TAX ADVICE
The information, outputs, checklists, reports, and AI-generated content provided by Compl-Ai™ SA and Compl-i™ (powered by Emma-i™ MAICP Protocol) are for general informational and guidance purposes ONLY. Nothing on this Platform constitutes legal advice, tax advice, accounting advice, or professional opinion of any kind.

PROFESSIONAL VERIFICATION REQUIRED
All compliance outputs must be verified with a qualified South African attorney, chartered accountant, tax practitioner registered with the South African Institute of Tax Professionals (SAIT), or the relevant regulatory authority before reliance or action.

LIMITATION OF LIABILITY
To the maximum extent permitted by South African law, SNC-TAX, SA-iLabs®™, and their respective officers, directors, employees, and agents shall not be liable for any direct, indirect, incidental, special, or consequential damages arising from:
(a) your use of or inability to use the Platform;
(b) any errors or omissions in Platform content;
(c) reliance on AI-generated compliance outputs;
(d) changes in South African legislation not yet reflected on the Platform;
(e) decisions made based on Platform guidance.

AI LIMITATIONS
Compl-i™ is the in-app AI assistant, with its accuracy and ethics governed by the Emma-i™ MAICP Protocol (SA-iLabs®™). Outputs are generated algorithmically and may not reflect the latest legislative amendments, SARS binding rulings, or regulatory guidance. Always verify AI outputs against official government sources.

WAIVER
By using this Platform, you expressly waive any and all claims against SNC-TAX and SA-iLabs®™ arising from reliance on Platform content, to the fullest extent permitted by law.`
  },
  {
    id: 'developer',
    icon: Server,
    title: 'Developer Disclaimer & Waiver (SA-iLabs®™)',
    color: 'text-purple-500',
    content: `SA-iLabs®™ is the development agency and technology provider for Compl-Ai™ SA. This disclaimer governs the relationship between SA-iLabs®™, SNC-TAX, and end users.

DEVELOPMENT ROLE
SA-iLabs®™ developed, deployed, and maintains the Compl-Ai™ SA platform on behalf of and under the ownership of SNC-TAX. SA-iLabs®™ acts as a technology service provider only.

INTELLECTUAL PROPERTY ASSIGNMENT
All intellectual property created during the development of Compl-Ai™ SA is owned exclusively by SNC-TAX, unless otherwise agreed in writing.

COMPL-i™ IN-APP AI & EMMA-i™ MAICP PROTOCOL
Compl-i™ is the in-app AI assistant embedded within the Compl-Ai™ SA platform. Its accuracy and ethical behaviour are governed by the Emma-i™ MAICP Protocol — a proprietary AI framework that is the implementation of the MAICP protocol by SA-iLabs®™, serving as the Accuracy and Ethical Engine for Compl-i™. SA-iLabs®™ retains intellectual property rights to both the Emma-i™ MAICP framework and the Compl-i™ implementation.

NO WARRANTY
SA-iLabs®™ provides the Platform on an "as is" and "as available" basis. SA-iLabs®™ makes no warranties, express or implied, regarding fitness for a particular purpose, accuracy of outputs, or uninterrupted availability.

DEVELOPER LIABILITY WAIVER
SA-iLabs®™ expressly disclaims all liability to end users for any loss, damage, or claim arising from use of the Platform. All end-user recourse must be directed to SNC-TAX as the Platform owner and operator.

SECURITY
SA-iLabs®™ implements industry-standard security measures but cannot guarantee absolute security of data transmitted over the internet.

CONTACT
For technical issues: support@sailabs.co.za`
  },
  {
    id: 'subscription',
    icon: Zap,
    title: 'Subscription, Licensing & Distribution',
    color: 'text-orange-500',
    content: `SUBSCRIPTION PLANS
Compl-Ai™ SA is offered on a subscription basis. Subscription tiers, pricing, and features are as published on the Platform at time of subscription. SNC-TAX reserves the right to change subscription pricing with 30 days written notice.

FREE TRIAL
Where a free trial is offered, it is subject to the terms stated at sign-up. Credit card details may be required and will be charged automatically at the end of the trial period unless cancelled.

PAYMENT
Payments are processed securely. SNC-TAX does not store payment card details. All payments are in South African Rand (ZAR) and are subject to South African VAT at the prevailing rate.

CANCELLATION & REFUNDS
You may cancel your subscription at any time. Cancellation takes effect at the end of the current billing period. Refunds are subject to SNC-TAX's refund policy as communicated at time of purchase.

DISTRIBUTION RESTRICTIONS
The Platform and its content may not be redistributed, resold, sublicensed, or white-labelled without prior written agreement with SNC-TAX. White-label partnerships are available under separate commercial agreements.

VENDOR / PARTNER ACCOUNTS
Accounting firms and compliance practitioners may subscribe to partner/vendor accounts. Partner usage is subject to this Agreement and any additional Partner Terms issued by SNC-TAX.

LICENCE SCOPE
Your subscription grants a licence to use the Platform for your own business compliance needs. The licence does not transfer to third parties and terminates upon cancellation or breach of these Terms.`
  },
  {
    id: 'user_compliance',
    icon: Users,
    title: 'User Compliance Obligations',
    color: 'text-red-500',
    content: `As a user of Compl-Ai™ SA, you agree to the following compliance obligations:

1. ACCURATE INFORMATION
You will provide accurate, complete, and up-to-date information about your business, directors, tax references, and compliance status. Providing false information may result in account suspension and potential legal liability.

2. COMPLIANCE RESPONSIBILITY
You remain solely responsible for your business's actual compliance with all applicable South African laws, regulations, and statutory requirements. The Platform is a tool to assist — not replace — your compliance obligations.

3. PROFESSIONAL ADVICE
You acknowledge that Platform outputs do not constitute professional advice and that you will consult qualified professionals for binding compliance determinations.

4. DOCUMENT SECURITY
You are responsible for the accuracy and security of documents uploaded to the Compliance Vault. Do not upload documents containing third-party personal information without the consent of those individuals.

5. ACCOUNT SECURITY
You must not share login credentials with unauthorized persons. You are responsible for all activity conducted under your account.

6. REPORTING OBLIGATIONS
Where the Platform assists with statutory filings (SARS eFiling, CIPC, etc.), you remain legally responsible for the accuracy and timeliness of those submissions. The Platform provides guidance only.

7. REGULATORY CHANGES
You acknowledge that legislation changes frequently and agree to independently verify compliance deadlines and requirements with the relevant authorities.

8. BREACH
Breach of these obligations may result in suspension of your account, termination of your subscription, and/or legal action where warranted.`
  },
];

function Section({ section }) {
  const [open, setOpen] = useState(false);
  const Icon = section.icon;
  return (
    <div className="glass-card rounded-xl border border-border overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-secondary/30 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg bg-secondary`}>
            <Icon className={`w-5 h-5 ${section.color}`} />
          </div>
          <span className="font-grotesk font-semibold text-foreground">{section.title}</span>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-muted-foreground flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
      </button>
      {open && (
        <div className="px-5 pb-5 border-t border-border">
          <pre className="mt-4 text-sm text-foreground leading-relaxed whitespace-pre-wrap font-sans">{section.content}</pre>
        </div>
      )}
    </div>
  );
}

export default function LegalCompliance() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-10 space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <div className="relative flex items-start gap-4">
          <div className="p-3 bg-primary/10 border border-primary/30 rounded-xl flex-shrink-0">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <div>
            <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-2 border border-primary/30">Full Legal Disclosure</span>
            <h1 className="text-3xl font-bold font-grotesk text-foreground mb-1">Legal, Compliance & Disclosure Centre</h1>
            <p className="text-sm text-muted-foreground">Compl-Ai™ SA · Owned by <strong className="text-foreground">SNC-TAX</strong> · Developed by SA-iLabs®™ · <em>Re-imagining Compliance Intelligence</em></p>
            <p className="text-xs text-muted-foreground mt-2 max-w-2xl">
              This page contains all mandatory legal documents, terms, policies, and disclosures governing your use of the Compl-Ai™ SA platform.
              Please read each document carefully. By using the Platform you confirm acceptance of all terms herein.
            </p>
          </div>
        </div>
      </div>

      {/* Quick summary bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'POPIA Compliant', color: 'text-green-500', bg: 'bg-green-500/10 border-green-500/20' },
          { label: 'FICA Aware', color: 'text-blue-500', bg: 'bg-blue-500/10 border-blue-500/20' },
          { label: 'SA Law Governed', color: 'text-primary', bg: 'bg-primary/10 border-primary/20' },
          { label: 'SA-iLabs®™ Powered', color: 'text-purple-500', bg: 'bg-purple-500/10 border-purple-500/20' },
        ].map((b, i) => (
          <div key={i} className={`rounded-xl border px-3 py-2.5 text-center text-xs font-semibold ${b.color} ${b.bg}`}>{b.label}</div>
        ))}
      </div>

      {/* Sections */}
      <div className="space-y-3">
        {sections.map(s => <Section key={s.id} section={s} />)}
      </div>

      {/* Footer note */}
      <div className="glass-card rounded-xl p-5 border border-primary/10 text-xs text-muted-foreground space-y-1 text-center">
        <p>© {new Date().getFullYear()} <strong className="text-foreground">SNC-TAX</strong> — All Rights Reserved.</p>
        <p>Platform developed by <strong className="text-foreground">SA-iLabs®™</strong> · Compl-i™ In-App AI · Emma-i™ MAICP Protocol (Accuracy &amp; Ethics Engine)</p>
        <p className="mt-2 text-muted-foreground/70">Last reviewed: April 2026 · Governed by the laws of the Republic of South Africa · Republic of South Africa</p>
      </div>
    </div>
  );
}