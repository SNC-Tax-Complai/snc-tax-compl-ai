import { useState, useEffect } from 'react';
import { MapPin, Calendar, Loader2 } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem, DeadlineBadge } from '../components/ComplianceSection';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

const municipalities = ['Cape Town', 'Johannesburg', 'Tshwane (Pretoria)', 'eThekwini (Durban)', 'Ekurhuleni', 'Buffalo City (East London)', 'Nelson Mandela Bay'];

export default function MunicipalCompliance() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMuni, setSelectedMuni] = useState('Cape Town');

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocs(demoDocuments); setLoading(false); return; }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          if (profiles[0].province) {
            const prov = profiles[0].province.toLowerCase();
            if (prov.includes('cape')) setSelectedMuni('Cape Town');
            else if (prov.includes('gauteng')) setSelectedMuni('Johannesburg');
            else if (prov.includes('kwazulu') || prov.includes('natal')) setSelectedMuni('eThekwini (Durban)');
          }
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
          setDocs(d);
        }
      } catch (e) { console.error('Municipal load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const hasDoc = (cat) => docs.some(d => (d.document_type || '').toLowerCase().includes(cat.toLowerCase()));
  const st = (score, threshold) => (score ?? 0) >= threshold ? 'done' : (score ?? 0) > 0 ? 'pending' : 'urgent';
  const overallScore = profile?.compliance_score ?? 0;

  if (loading) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero badge="Municipal Compliance" title="Municipal & Local Government Compliance"
        subtitle="Business licenses, zoning permits, signage, health certificates, trading permits, rates, and all local authority requirements." />

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-3 flex items-center gap-2"><MapPin className="w-4 h-4 text-primary" /> Select Your Municipality</h2>
        <div className="flex flex-wrap gap-2">
          {municipalities.map(m => (
            <button key={m} onClick={() => setSelectedMuni(m)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${selectedMuni === m ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}>
              {m}
            </button>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-3">Showing requirements for: <span className="text-primary">{selectedMuni}</span></p>
      </div>

      {profile && (
        <div className="glass-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-grotesk font-semibold text-foreground">Your Overall Compliance Score</h2>
            <span className="text-2xl font-bold font-grotesk text-primary">{overallScore}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${overallScore}%` }} />
          </div>
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">Municipal Compliance Checklist — {selectedMuni}</h2>
        <div className="space-y-2">
          <ChecklistItem label="Business license/trading permit obtained" status={hasDoc('Municipal') ? 'done' : st(overallScore, 30)} detail="National Businesses Act 71 of 1991" />
          <ChecklistItem label="Zoning certificate confirms business use of premises" status={st(overallScore, 35)} />
          <ChecklistItem label="Municipal rates and levies account up to date" status={st(overallScore, 40)} />
          <ChecklistItem label="Water and sanitation account current" status={st(overallScore, 45)} />
          <ChecklistItem label="Electricity account/CoC current" status={st(overallScore, 50)} />
          <ChecklistItem label="Building plans approved (if renovations/new builds)" status="pending" />
          <ChecklistItem label="Outdoor advertising / signage permit" status="pending" />
          <ChecklistItem label="Noise regulation compliance" status={st(overallScore, 55)} />
          <ChecklistItem label="Waste management compliance (recycling plan if required)" status="pending" />
          <ChecklistItem label="Storm water and drainage compliance" status={st(overallScore, 60)} />
        </div>
      </div>

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4 flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> Municipal Renewal Deadlines</h2>
        <div className="space-y-2">
          <DeadlineBadge label="Business License Renewal (annual)" date="Varies by municipality" />
          <DeadlineBadge label="Food Establishment License — Annual" date="1 April annually" urgent />
          <DeadlineBadge label="Liquor License Renewal" date="Per Provincial Liquor Authority" />
          <DeadlineBadge label="Municipal Rates Account" date="30th of each month" urgent />
          <DeadlineBadge label="Health Certificate of Acceptability" date="Annual — food businesses" />
          <DeadlineBadge label="Signage Permit Renewal" date="Annual" />
        </div>
      </div>

      <ExpandableSection title="Business Licenses — National Businesses Act" defaultOpen>
        <p className="text-sm text-muted-foreground mb-3">Required for businesses in food, health services, hospitality, entertainment, and other regulated categories.</p>
        {[
          'Food Establishment License (restaurants, food vendors, caterers)',
          'Health Facility License (clinics, beauty salons, tattoo studios)',
          'Entertainment License (nightclubs, venues, events)',
          'Accommodation License (B&Bs, guesthouses, lodges)',
          'Automotive Workshop License',
          'Scrapyard / Recycling Facility License',
        ].map((s, i) => <ChecklistItem key={i} label={s} status="pending" />)}
      </ExpandableSection>

      <ExpandableSection title="Zoning & Land Use Management">
        <ChecklistItem label="Confirm zoning allows intended business use" status="pending" detail="Check municipal zoning map or SG plan" />
        <ChecklistItem label="Home Occupation permit (if working from home)" status="pending" detail="Required in most metro municipalities" />
        <ChecklistItem label="Departure/consent use application if zoning does not permit" status="pending" />
        <ChecklistItem label="Environmental impact assessment (EIA) if required" status="pending" />
        <ChecklistItem label="Heritage site approval if premises is heritage-listed" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Health & Food Safety (DoH + Municipal)">
        <ChecklistItem label="Certificate of Acceptability (Regulation R638 Food) — annual" status={hasDoc('Municipal') ? 'done' : 'pending'} urgent />
        <ChecklistItem label="Food handlers trained on hygiene practices" status="pending" />
        <ChecklistItem label="Pest control records maintained (quarterly minimum)" status="pending" />
        <ChecklistItem label="Temperature logs for food storage" status="pending" />
        <ChecklistItem label="Kitchen equipment service records" status="pending" />
        <ChecklistItem label="HACCP plan if supplying to retail/hospitality" status="pending" />
        <ChecklistItem label="Liquor license from Provincial Liquor Authority (if applicable)" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Outdoor Advertising & Signage Permits">
        <ChecklistItem label="Application to municipality for outdoor signage" status="pending" />
        <ChecklistItem label="SABC Media Authority approval for large billboards" status="pending" />
        <ChecklistItem label="Sign complies with municipal by-laws on size and illumination" status="pending" />
        <ChecklistItem label="Annual renewal of signage permit" status="pending" />
        <ChecklistItem label="No signage on public roads without Road Authority approval" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Environmental Compliance — Municipal">
        <ChecklistItem label="Effluent discharge permit (if applicable)" status="pending" />
        <ChecklistItem label="Industrial waste disposal plan submitted" status="pending" />
        <ChecklistItem label="NEMA: Basic Assessment for activities listed in GN 327" status="pending" />
        <ChecklistItem label="Air quality registration (if emissions above threshold)" status="pending" />
        <ChecklistItem label="Listed installation: APPA registration" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Liquor Licensing">
        <ChecklistItem label="Application to Provincial Liquor Authority" status="pending" />
        <ChecklistItem label="Community notification and objection period met" status="pending" />
        <ChecklistItem label="Responsible alcohol sales training" status="pending" />
        <ChecklistItem label="License displayed at premises" status="pending" />
        <ChecklistItem label="Annual license fee paid" status="pending" />
        <ChecklistItem label="Staff trained on minors and over-service regulations" status="pending" />
      </ExpandableSection>
    </div>
  );
}