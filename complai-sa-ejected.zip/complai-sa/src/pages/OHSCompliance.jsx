import { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem, DeadlineBadge } from '../components/ComplianceSection';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

export default function OHSCompliance() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocs(demoDocuments); setLoading(false); return; }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
          setDocs(d);
        }
      } catch (e) { console.error('OHS load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const score = profile?.ohs_score ?? 0;
  const hasDoc = (cat) => docs.some(d => (d.document_type || '').toLowerCase().includes(cat.toLowerCase()));
  const st = (threshold) => score >= threshold ? 'done' : score > 0 ? 'pending' : 'urgent';

  if (loading) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero badge="OHS Compliance" title="Occupational Health & Safety"
        subtitle="OHS Act No. 85 of 1993 compliance — workplace safety, risk assessments, incident reporting, and mandatory inspections." />

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { label: 'Max Fine (non-compliance)', value: 'R100K', sub: 'Per contravention', color: 'text-red-400' },
          { label: 'Imprisonment Risk', value: '2 Years', sub: 'For serious violations', color: 'text-yellow-400' },
          { label: 'Risk Assessment', value: 'Annual', sub: 'Minimum frequency', color: 'text-green-400' },
        ].map((c, i) => (
          <div key={i} className="glass-card rounded-xl p-4 neon-glow text-center">
            <div className={`text-2xl font-bold font-grotesk ${c.color}`}>{c.value}</div>
            <div className="text-sm font-medium text-foreground mt-1">{c.label}</div>
            <div className="text-xs text-muted-foreground">{c.sub}</div>
          </div>
        ))}
      </div>

      {profile && (
        <div className="glass-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-grotesk font-semibold text-foreground">Your OHS Compliance Score</h2>
            <span className="text-2xl font-bold font-grotesk text-primary">{score}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${score}%` }} />
          </div>
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">OHS Compliance Checklist</h2>
        <div className="space-y-2">
          <ChecklistItem label="OHS Policy signed by CEO/MD and displayed" status={st(30)} urgent />
          <ChecklistItem label="OHS Representative appointed (if 20+ employees)" status={st(40)} />
          <ChecklistItem label="OHS Committee established (if 20+ employees)" status={st(45)} />
          <ChecklistItem label="Baseline risk assessment completed and documented" status={hasDoc('OHS') ? 'done' : st(35)} />
          <ChecklistItem label="First aid kit available and stocked" status={st(50)} />
          <ChecklistItem label="Fire extinguishers serviced (annual)" status={st(55)} />
          <ChecklistItem label="Emergency evacuation plan displayed" status={st(60)} />
          <ChecklistItem label="Accident/incident register maintained" status={st(65)} />
          <ChecklistItem label="Hazardous substances register" status={st(70)} />
          <ChecklistItem label="Machinery and equipment inspection log" status={st(75)} />
          <ChecklistItem label="PPE issued and recorded" status={st(80)} />
          <ChecklistItem label="OHS induction for all new employees" status={st(85)} />
        </div>
      </div>

      <ExpandableSection title="General Machinery Regulations" defaultOpen>
        <ChecklistItem label="Pressure vessels registered with DoL" status="pending" />
        <ChecklistItem label="Lifting equipment inspected (annually or per regulation)" status="pending" />
        <ChecklistItem label="Electrical installations Certificate of Compliance (CoC)" status="pending" />
        <ChecklistItem label="Machinery guarded per Driven Machinery Regulations" status="pending" />
        <ChecklistItem label="Operator competency certificates on file" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Construction Regulations (CR 2014)">
        <ChecklistItem label="Health & Safety Plan submitted before project start" status="pending" />
        <ChecklistItem label="Principal Contractor appointed in writing" status="pending" />
        <ChecklistItem label="Construction work permit (projects > R13.5M or 30 days)" status="pending" />
        <ChecklistItem label="Fall protection plan for work at heights" status="pending" />
        <ChecklistItem label="Scaffold inspection and tagging" status="pending" />
        <ChecklistItem label="Excavation permit and inspection" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Incident Reporting — COID & OHS Act">
        <p className="text-sm text-muted-foreground mb-3">All workplace incidents must be reported. Serious injuries reported to DoL within 7 days.</p>
        <ChecklistItem label="Incident reported in accident register immediately" status="pending" />
        <ChecklistItem label="W.CL.1 form submitted to Compensation Fund within 7 days" status="pending" />
        <ChecklistItem label="Serious injury: notify DoL inspector immediately" status="pending" />
        <ChecklistItem label="Investigation report completed within 14 days" status="pending" />
        <ChecklistItem label="Corrective action implemented and documented" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Hazardous Chemical Substances (HCS) Regulations">
        <ChecklistItem label="Inventory of all hazardous substances maintained" status="pending" />
        <ChecklistItem label="Safety Data Sheets (SDS) available for all chemicals" status="pending" />
        <ChecklistItem label="Employees trained on chemical hazards" status="pending" />
        <ChecklistItem label="Biological monitoring where required" status="pending" />
        <ChecklistItem label="Chemical storage compliant with HCS regulations" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="OHS Inspections Schedule">
        <div className="space-y-2">
          <DeadlineBadge label="Annual Risk Assessment Review" date="Annually" />
          <DeadlineBadge label="Fire Equipment Service" date="Annually" />
          <DeadlineBadge label="OHS Committee Meeting" date="Quarterly" />
          <DeadlineBadge label="First Aid Kit Inspection" date="Monthly" urgent />
          <DeadlineBadge label="Electrical CoC Renewal" date="Every 2 years" />
          <DeadlineBadge label="Pressure Vessel Inspection" date="Per SABS standards" />
        </div>
      </ExpandableSection>
    </div>
  );
}