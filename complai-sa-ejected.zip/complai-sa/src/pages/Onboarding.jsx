import { useState, useEffect } from 'react';
import { Building, User, ChevronRight, CheckCircle, Upload, FileText, Loader2, X, AlertCircle, Shield, Bot, Globe, Database, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';
import LoadingCheckmark from '../components/LoadingCheckmark';

const industries = ['Construction', 'Food & Beverage', 'Healthcare', 'Technology & ICT', 'Transport & Logistics', 'Retail & Wholesale', 'Agriculture', 'Financial Services', 'Property & Real Estate', 'Energy & Utilities', 'Professional Services', 'Manufacturing', 'Education', 'Hospitality & Tourism', 'Other'];
const entityTypes = ['Sole Proprietor / Freelancer', 'Private Company (PTY Ltd)', 'Close Corporation (CC)', 'Partnership', 'Non-Profit Company (NPC)', 'Trust'];
const provinces = ['Western Cape', 'Gauteng', 'KwaZulu-Natal', 'Eastern Cape', 'Limpopo', 'Mpumalanga', 'North West', 'Free State', 'Northern Cape'];

const documentTypes = [
  { key: 'cipc_certificate', label: 'CIPC Registration Certificate', description: 'Proof of company registration', required: false },
  { key: 'tax_clearance', label: 'SARS Tax Clearance / PIN', description: 'Tax compliance certificate', required: false },
  { key: 'vat_certificate', label: 'VAT Registration Certificate', description: 'If VAT registered', required: false },
  { key: 'bbbee_certificate', label: 'B-BBEE Certificate / Affidavit', description: 'Broad-Based Black Economic Empowerment', required: false },
  { key: 'emp_registration', label: 'EMP Registration / UIF Letter', description: 'Employment / PAYE registration', required: false },
  { key: 'other', label: 'Other Compliance Document', description: 'Any other relevant document', required: false },
];

export default function Onboarding() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isDemo } = useDemo();
  const [step, setStep] = useState(1); // 1=terms, 2=business, 3=director, 4=industry, 5=documents, 6=analyzing, 7=done
  const [data, setData] = useState({
    entityName: '', regNumber: '', entityType: '', province: '', industry: '', turnover: '',
    directorName: '', directorId: '', directorEmail: '',
    vatRegistered: '', vatNumber: '', employeeCount: '', whatsappNumber: '',
  });
  const [uploadedDocs, setUploadedDocs] = useState({}); // key -> { file, url, name }
  const [uploading, setUploading] = useState({});
  const [saving, setSaving] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState('');
  const [profileId, setProfileId] = useState(null);
  const [showSkipWarning, setShowSkipWarning] = useState(false);

  const totalSteps = 7;
  const update = (k, v) => setData(p => ({ ...p, [k]: v }));

  // Redirect to login if not authenticated and not in demo mode
  useEffect(() => {
    if (!isDemo && !user?.id) {
      api.auth.redirectToLogin(window.location.href);
    }
  }, [user, isDemo]);

  // Check if user already has an onboarding profile
  useEffect(() => {
    if (isDemo) return;
    if (user?.id) {
      checkExistingProfile();
    }
  }, [user, isDemo]);

  const checkExistingProfile = async () => {
    try {
      const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
      if (profiles.length > 0 && profiles[0].onboarding_complete) {
        navigate('/');
      }
    } catch (e) {
      // no profile yet, that's fine
    }
  };

  const handleFileUpload = async (docKey, file) => {
    setUploading(p => ({ ...p, [docKey]: true }));
    setError('');
    try {
      const { file_url } = await api.integrations.Core.UploadFile({ file });
      setUploadedDocs(p => ({ ...p, [docKey]: { file, url: file_url, name: file.name } }));
    } catch (e) {
      setError('Failed to upload file. Please try again.');
    }
    setUploading(p => ({ ...p, [docKey]: false }));
  };

  const removeDoc = (docKey) => {
    setUploadedDocs(p => {
      const next = { ...p };
      delete next[docKey];
      return next;
    });
  };

  const handleSkipAccept = async () => {
    setShowSkipWarning(false);
    await saveProfileAndDocs(true);
  };

  const handleSkipReject = () => {
    setShowSkipWarning(false);
  };

  const saveProfileAndDocs = async (skipDocuments = false) => {
    setSaving(true);
    setError('');
    try {
      if (!isDemo && !user?.id) {
        setError('Authentication required. Please sign in to continue.');
        setSaving(false);
        return;
      }
      if (isDemo) {
        // Demo mode — can't create real profiles, go straight to dashboard
        navigate('/');
        return;
      }
      const userId = user?.id;
      // Save business profile
      const profile = await api.entities.BusinessProfile.create({
        user_id: userId,
        entity_name: data.entityName,
        reg_number: data.regNumber,
        entity_type: data.entityType,
        province: data.province,
        industry: data.industry,
        turnover: data.turnover,
        vat_registered: data.vatRegistered,
        vat_number: data.vatNumber,
        employee_count: data.employeeCount,
        director_name: data.directorName,
        director_id: data.directorId,
        director_email: data.directorEmail,
        whatsapp_number: data.whatsappNumber || '',
        terms_accepted: true,
        onboarding_complete: false,
      });
      setProfileId(profile.id);

      // Save each uploaded document record
      for (const [docKey, docData] of Object.entries(uploadedDocs)) {
        await api.entities.ComplianceDocument.create({
          user_id: userId,
          business_profile_id: profile.id,
          document_type: docKey,
          document_name: docData.name,
          file_url: docData.url,
          status: 'pending',
        });
      }

      setStep(6); // analyzing step
      await runAIAnalysis(profile.id, userId);
    } catch (e) {
      setError('Failed to save your profile. Please try again. ' + e.message);
      setSaving(false);
    }
  };

  const runAIAnalysis = async (profId, userId) => {
    setAnalyzing(true);
    try {
      // Fetch saved documents
      const docs = await api.entities.ComplianceDocument.filter({ business_profile_id: profId });

      // Build context for AI
      const docContext = docs.length > 0
        ? docs.map(d => `- ${d.document_type}: ${d.document_name} (uploaded)`).join('\n')
        : 'No documents uploaded — user skipped document upload during onboarding. Compliance scores should reflect missing documentation.';
      const businessContext = `
Business Name: ${data.entityName}
Registration Number: ${data.regNumber}
Entity Type: ${data.entityType}
Province: ${data.province}
Industry: ${data.industry}
Annual Turnover: ${data.turnover}
VAT Registered: ${data.vatRegistered}
VAT Number: ${data.vatNumber || 'N/A'}
Number of Employees: ${data.employeeCount}
Director: ${data.directorName}
Director Email: ${data.directorEmail}

Documents Uploaded:
${docContext || 'No documents uploaded yet'}
      `.trim();

      const prompt = `You are Compl-i Assistant, the AI compliance engine for Compl-Ai™ SA, a South African compliance platform.

Analyze the following South African business profile and provide a comprehensive compliance assessment.

BUSINESS PROFILE:
${businessContext}

Based on this information, provide a detailed compliance analysis. Return a JSON object with EXACTLY these fields:
- compliance_score: number 0-100 (overall compliance health score based on entity type, industry, documents provided)
- cipc_score: number 0-100 (CIPC / company registration compliance)
- sars_score: number 0-100 (SARS / tax compliance)
- labour_score: number 0-100 (Labour / UIF / PAYE compliance)
- ohs_score: number 0-100 (Occupational Health & Safety compliance)
- popia_score: number 0-100 (POPIA data protection compliance)
- bbbee_score: number 0-100 (B-BBEE compliance score)
- fica_score: number 0-100 (FICA compliance score)
- risk_level: string "Low", "Medium", or "High"
- pending_filings: number (estimated pending filings based on entity type and industry)
- urgent_alerts: number (number of urgent compliance items)
- ai_analysis_summary: string (2-3 sentence summary of the compliance status, mentioning specific SA regulations)
- ai_recommendations: string (3-5 bullet point recommendations as a pipe-separated string, e.g. "Register for EMP501|Submit VAT201 by month-end|Renew CIPC annual return")
- upcoming_deadlines: string (JSON array string of up to 5 upcoming compliance deadlines relevant to this business, format: [{"label":"EMP201","date":"15 Jul 2026","urgent":true,"type":"SARS"}])

Be realistic and specific to South African compliance requirements. If documents are provided, give higher scores in those areas.`;

      const result = await api.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            compliance_score: { type: 'number' },
            cipc_score: { type: 'number' },
            sars_score: { type: 'number' },
            labour_score: { type: 'number' },
            ohs_score: { type: 'number' },
            popia_score: { type: 'number' },
            bbbee_score: { type: 'number' },
            fica_score: { type: 'number' },
            risk_level: { type: 'string' },
            pending_filings: { type: 'number' },
            urgent_alerts: { type: 'number' },
            ai_analysis_summary: { type: 'string' },
            ai_recommendations: { type: 'string' },
            upcoming_deadlines: { type: 'string' },
          }
        }
      });

      // Update profile with AI analysis results
      await api.entities.BusinessProfile.update(profId, {
        compliance_score: result.compliance_score,
        cipc_score: result.cipc_score,
        sars_score: result.sars_score,
        labour_score: result.labour_score,
        ohs_score: result.ohs_score,
        popia_score: result.popia_score,
        bbbee_score: result.bbbee_score,
        fica_score: result.fica_score,
        risk_level: result.risk_level,
        pending_filings: result.pending_filings,
        urgent_alerts: result.urgent_alerts,
        ai_analysis_summary: result.ai_analysis_summary,
        ai_recommendations: result.ai_recommendations,
        upcoming_deadlines: result.upcoming_deadlines,
        onboarding_complete: true,
      });

      // Mark documents as analyzed
      for (const doc of docs) {
        await api.entities.ComplianceDocument.update(doc.id, { status: 'analyzed' });
      }

      setStep(7);
    } catch (e) {
      // Still complete onboarding even if AI analysis fails partially
      try {
        await api.entities.BusinessProfile.update(profId, {
          compliance_score: 50,
          risk_level: 'Medium',
          pending_filings: 3,
          urgent_alerts: 1,
          ai_analysis_summary: 'Initial compliance profile created. Full AI analysis will be available shortly.',
          onboarding_complete: true,
        });
      } catch (_) {}
      setStep(7);
    }
    setAnalyzing(false);
    setSaving(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-lg glass-card rounded-2xl border border-primary/20 p-8 neon-glow animate-slide-up">
        {/* Progress */}
        {step < 6 && (
          <>
            <div className="flex items-center gap-1.5 mb-6">
              {[1, 2, 3, 4, 5].map(s => (
                <div key={s} className={`flex-1 h-1.5 rounded-full transition-all ${s <= step ? 'bg-primary' : 'bg-secondary'}`} />
              ))}
            </div>
            <p className="text-xs text-muted-foreground mb-1">Step {step} of 5</p>
          </>
        )}

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-400/10 border border-red-400/20 text-xs text-red-400 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            {error}
          </div>
        )}

        {/* Step 1: Terms & Welcome */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-2xl font-bold font-grotesk text-foreground">Welcome to Compl-Ai™ SA</h2>
              <p className="text-sm text-muted-foreground mt-2">Let's set up your compliance profile. This takes about 3 minutes.</p>
            </div>
            <div className="bg-secondary/40 rounded-xl p-4 space-y-3 text-sm">
              {[
                { icon: '🏢', text: 'Enter your business & director details' },
                { icon: '📄', text: 'Upload key compliance documents' },
                { icon: '🤖', text: 'AI analyses your compliance status' },
                { icon: '📊', text: 'Get your personalised compliance dashboard' },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-lg">{item.icon}</span>
                  <span className="text-muted-foreground">{item.text}</span>
                </div>
              ))}
            </div>
            <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 text-xs text-muted-foreground">
              <p className="font-semibold text-foreground mb-1">By continuing you confirm:</p>
              <p>✓ You accept our Terms of Service, POPIA consent, and AI Usage Agreement (agreed during registration)</p>
              <p className="mt-1">✓ Information provided will be used to generate your compliance profile</p>
            </div>
            <button onClick={() => setStep(2)} className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold text-sm neon-glow hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
              Get Started <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Step 2: Business Details */}
        {step === 2 && (
          <div className="space-y-4">
            <div>
              <Building className="w-6 h-6 text-primary mb-3" />
              <h2 className="text-xl font-bold font-grotesk text-foreground">Business Details</h2>
              <p className="text-sm text-muted-foreground">Tell us about your business entity.</p>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">Registered Business Name *</label>
              <input value={data.entityName} onChange={e => update('entityName', e.target.value)} placeholder="e.g. My Business (Pty) Ltd"
                className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">CIPC Registration Number</label>
              <input value={data.regNumber} onChange={e => update('regNumber', e.target.value)} placeholder="e.g. 2024/123456/07"
                className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">Entity Type *</label>
              <select value={data.entityType} onChange={e => update('entityType', e.target.value)}
                className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none">
                <option value="">Select entity type...</option>
                {entityTypes.map(e => <option key={e}>{e}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">Province *</label>
              <select value={data.province} onChange={e => update('province', e.target.value)}
                className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none">
                <option value="">Select province...</option>
                {provinces.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
          </div>
        )}

        {/* Step 3: Director Details */}
        {step === 3 && (
          <div className="space-y-4">
            <div>
              <User className="w-6 h-6 text-primary mb-3" />
              <h2 className="text-xl font-bold font-grotesk text-foreground">Director / Owner Details</h2>
              <p className="text-sm text-muted-foreground">Primary director or business owner information.</p>
            </div>
            {[
              { label: 'Full Name *', key: 'directorName', ph: 'Director full name' },
              { label: 'SA ID Number', key: 'directorId', ph: 'SA ID number (13 digits)' },
              { label: 'Email Address', key: 'directorEmail', ph: 'director@email.com' },
            ].map(f => (
              <div key={f.key}>
                <label className="text-xs text-muted-foreground mb-1.5 block">{f.label}</label>
                <input value={data[f.key]} onChange={e => update(f.key, e.target.value)} placeholder={f.ph}
                  className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
              </div>
            ))}
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block flex items-center gap-1">
                WhatsApp Number <span className="text-muted-foreground/60 font-normal">(optional — for compliance reminders)</span>
              </label>
              <input value={data.whatsappNumber} onChange={e => update('whatsappNumber', e.target.value)} placeholder="e.g. +27 82 123 4567"
                className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
              <p className="text-xs text-muted-foreground mt-1">If provided, we'll send compliance filing reminders and deadline alerts to your WhatsApp.</p>
            </div>
          </div>
        )}

        {/* Step 4: Industry & Tax */}
        {step === 4 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-bold font-grotesk text-foreground">Industry & Tax Configuration</h2>
              <p className="text-sm text-muted-foreground">Help us tailor your compliance profile.</p>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-2 block">Industry / Sector *</label>
              <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                {industries.map(ind => (
                  <button key={ind} onClick={() => update('industry', ind)}
                    className={`text-left px-3 py-2 rounded-lg text-xs border transition-colors ${data.industry === ind ? 'border-primary bg-primary/10 text-primary' : 'border-border bg-secondary/30 text-muted-foreground hover:border-primary/40'}`}>
                    {ind}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">Annual Turnover (approximate)</label>
              <select value={data.turnover} onChange={e => update('turnover', e.target.value)}
                className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none">
                <option value="">Select range...</option>
                <option>Below R1 million</option>
                <option>R1M – R5M</option>
                <option>R5M – R10M (EME threshold)</option>
                <option>R10M – R50M (QSE)</option>
                <option>Above R50M</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">VAT Registered?</label>
              <div className="flex gap-3">
                {['Yes', 'No'].map(v => (
                  <button key={v} onClick={() => update('vatRegistered', v)}
                    className={`flex-1 py-2 rounded-lg text-sm border transition-colors ${data.vatRegistered === v ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                    {v}
                  </button>
                ))}
              </div>
            </div>
            {data.vatRegistered === 'Yes' && (
              <div>
                <label className="text-xs text-muted-foreground mb-1.5 block">VAT Number</label>
                <input value={data.vatNumber} onChange={e => update('vatNumber', e.target.value)} placeholder="e.g. 4123456789"
                  className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
              </div>
            )}
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">Number of Employees</label>
              <select value={data.employeeCount} onChange={e => update('employeeCount', e.target.value)}
                className="w-full bg-secondary rounded-lg px-4 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none">
                <option value="">Select...</option>
                <option>0 (Sole Proprietor / No Employees)</option>
                <option>1 – 5</option>
                <option>6 – 20</option>
                <option>21 – 50</option>
                <option>51 – 200</option>
                <option>200+</option>
              </select>
            </div>
          </div>
        )}

        {/* Step 5: Document Upload (Optional) */}
        {step === 5 && (
          <div className="space-y-4">
            <div>
              <FileText className="w-6 h-6 text-primary mb-3" />
              <h2 className="text-xl font-bold font-grotesk text-foreground">Upload Documents <span className="text-sm font-normal text-muted-foreground">(Optional)</span></h2>
              <p className="text-sm text-muted-foreground">Upload your compliance documents now or skip this step — you can upload them anytime in the Document Vault after registration.</p>
            </div>
            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {documentTypes.map(docType => {
                const uploaded = uploadedDocs[docType.key];
                const isUploading = uploading[docType.key];
                return (
                  <div key={docType.key} className={`rounded-xl border p-3 transition-colors ${uploaded ? 'border-green-400/30 bg-green-400/5' : 'border-border bg-secondary/20'}`}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          {uploaded ? <CheckCircle className="w-3.5 h-3.5 text-green-400 flex-shrink-0" /> : <FileText className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />}
                          <p className="text-xs font-medium text-foreground truncate">{docType.label}</p>
                          {docType.required && <span className="text-xs text-red-400">*</span>}
                        </div>
                        <p className="text-xs text-muted-foreground ml-5">{docType.description}</p>
                        {uploaded && <p className="text-xs text-green-400 ml-5 mt-0.5 truncate">✓ {uploaded.name}</p>}
                      </div>
                      <div className="flex-shrink-0">
                        {uploaded ? (
                          <button onClick={() => removeDoc(docType.key)} className="text-muted-foreground hover:text-red-400 transition-colors">
                            <X className="w-4 h-4" />
                          </button>
                        ) : (
                          <label className={`cursor-pointer px-2 py-1 rounded-lg text-xs border transition-colors flex items-center gap-1 ${isUploading ? 'border-primary/30 text-muted-foreground' : 'border-primary/40 text-primary hover:bg-primary/10'}`}>
                            {isUploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Upload className="w-3 h-3" />}
                            {isUploading ? 'Uploading…' : 'Upload'}
                            <input
                              type="file"
                              className="hidden"
                              accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                              disabled={isUploading}
                              onChange={e => e.target.files[0] && handleFileUpload(docType.key, e.target.files[0])}
                            />
                          </label>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="text-xs text-muted-foreground">All documents are optional during onboarding — you can upload them anytime in the Document Vault after your account is set up.</p>
            <button
              onClick={() => saveProfileAndDocs(false)}
              disabled={saving}
              className={`w-full py-3 rounded-lg font-semibold text-sm mt-2 transition-all flex items-center justify-center gap-2 ${!saving ? 'bg-primary text-primary-foreground neon-glow hover:bg-primary/90' : 'bg-secondary text-muted-foreground cursor-not-allowed'}`}>
              {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving & Analyzing…</> : 'Complete Setup & Analyse →'}
            </button>
            <button
              onClick={() => setShowSkipWarning(true)}
              disabled={saving}
              className="w-full py-2.5 mt-2 text-sm text-muted-foreground hover:text-foreground border border-border rounded-lg transition-colors disabled:opacity-50">
              Skip Document Upload
            </button>
          </div>
        )}

        {/* Skip Warning Modal */}
        {showSkipWarning && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="w-full max-w-md glass-card rounded-2xl border border-yellow-400/30 p-6 animate-slide-up">
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 bg-yellow-400/10 rounded-full flex items-center justify-center mb-4">
                  <AlertTriangle className="w-7 h-7 text-yellow-400" />
                </div>
                <h3 className="text-lg font-bold font-grotesk text-foreground mb-2">Skip Document Upload?</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Without your compliance documents, your dashboard will <strong className="text-foreground">lack accurate data</strong>. Here's what will be affected:
                </p>
                <div className="w-full space-y-2 mb-4 text-left">
                  {[
                    'Compliance scores will be estimated, not verified',
                    'Document verification status (verified / needs action) will be empty',
                    'AI recommendations will be generic, not document-specific',
                    'Module scores (CIPC, SARS, B-BBEE, etc.) will be lower and less precise',
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-2 p-2 rounded-lg bg-yellow-400/5 border border-yellow-400/15">
                      <AlertTriangle className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-muted-foreground">{item}</p>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mb-4">
                  You can upload documents anytime from the Document Vault after setup.
                </p>
                <div className="flex gap-3 w-full">
                  <button
                    onClick={handleSkipReject}
                    className="flex-1 py-2.5 border border-border text-muted-foreground rounded-lg text-sm font-medium hover:bg-secondary transition-colors">
                    Cancel
                  </button>
                  <button
                    onClick={handleSkipAccept}
                    className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium neon-glow hover:bg-primary/90 transition-colors">
                    Skip & Continue
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 6: Analyzing */}
        {step === 6 && (
          <div className="text-center space-y-6 py-4">
            <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto" style={{ background: 'rgba(19,181,234,0.15)' }}>
              <Bot className="w-10 h-10 text-primary animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-grotesk text-foreground mb-2">Compl-i Assistant is Analysing Your Profile</h2>
              <p className="text-sm text-muted-foreground">Our AI compliance engine is reviewing your business profile and documents to generate your personalised compliance score.</p>
            </div>
            <LoadingCheckmark
              size="sm"
              stepDuration={900}
              steps={[
                { label: 'Reviewing business registration details…', icon: Database },
                { label: 'Checking SARS compliance requirements…', icon: Shield },
                { label: 'Analysing uploaded documents…', icon: FileText },
                { label: 'Calculating compliance scores per module…', icon: Bot },
                { label: 'Generating personalised recommendations…', icon: Globe },
              ]}
            />
            <p className="text-xs text-muted-foreground">This usually takes 15–30 seconds…</p>
          </div>
        )}

        {/* Step 7: Complete */}
        {step === 7 && (
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-green-400/10 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
            <h2 className="text-xl font-bold font-grotesk text-foreground">Your Profile is Ready!</h2>
            <p className="text-sm text-muted-foreground">Compl-i Assistant has analysed your compliance profile. Your personalised dashboard is now populated with real data.</p>
            <div className="bg-primary/5 border border-primary/20 rounded-xl p-3 text-left space-y-1.5">
              <p className="text-xs font-semibold text-foreground">✅ Email verification pending — check your inbox</p>
              {data.whatsappNumber && <p className="text-xs font-semibold text-foreground">✅ WhatsApp verification — reminders will be sent to {data.whatsappNumber}</p>}
              <p className="text-xs text-muted-foreground">📄 You can upload your compliance documents anytime from the Document Vault in your dashboard.</p>
            </div>
            <div className="bg-secondary/40 rounded-xl p-4 text-left space-y-2 text-sm">
              <p><span className="text-muted-foreground">Business:</span> <span className="text-foreground font-medium">{data.entityName || 'Your Business'}</span></p>
              <p><span className="text-muted-foreground">Entity Type:</span> <span className="text-foreground font-medium">{data.entityType || '—'}</span></p>
              <p><span className="text-muted-foreground">Industry:</span> <span className="text-foreground font-medium">{data.industry || '—'}</span></p>
              <p><span className="text-muted-foreground">Province:</span> <span className="text-foreground font-medium">{data.province || '—'}</span></p>
            </div>
            <button onClick={() => navigate('/')} className="block w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold text-sm neon-glow hover:bg-primary/90 transition-colors">
              Go to My Dashboard →
            </button>
          </div>
        )}

        {/* Navigation buttons */}
        {step >= 2 && step < 5 && (
          <>
            <button
              onClick={() => {
                if (step === 2 && !data.entityName.trim()) {
                  setError('Please enter your business name.');
                  return;
                }
                setError('');
                setStep(s => s + 1);
              }}
              className="w-full mt-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold text-sm neon-glow hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
              Continue <ChevronRight className="w-4 h-4" />
            </button>
            <button onClick={() => { setError(''); setStep(s => s - 1); }} className="w-full mt-2 text-xs text-muted-foreground hover:text-foreground">← Back</button>
          </>
        )}
        {step === 5 && (
          <button onClick={() => { setError(''); setStep(4); }} className="w-full mt-2 text-center text-xs text-muted-foreground hover:text-foreground">← Back</button>
        )}
      </div>
    </div>
  );
}