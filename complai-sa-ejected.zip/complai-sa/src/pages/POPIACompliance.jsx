import { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem } from '../components/ComplianceSection';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

export default function POPIACompliance() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocs(demoDocuments); setLoading(false); return; }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
          setDocs(d);
        }
      } catch (e) { console.error('POPIA load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const score = profile?.popia_score ?? 0;
  const hasDoc = (cat) => docs.some(d => (d.document_type || '').toLowerCase().includes(cat.toLowerCase()));
  const st = (threshold) => score >= threshold ? 'done' : score > 0 ? 'pending' : 'urgent';

  if (loading) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero badge="POPIA & PAIA Compliance" title="Protection of Personal Information & Access to Information"
        subtitle="POPIA (Act 4 of 2013) and PAIA obligations — data privacy, information officer, consent, breach notification, and access requests." />

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: 'Max Admin Fine', value: 'R10M', sub: 'Per contravention', color: 'text-red-400' },
          { label: 'Imprisonment', value: '10 Years', sub: 'Serious offences', color: 'text-yellow-400' },
          { label: 'Breach Notification', value: '72 Hours', sub: 'To Regulator & data subject', color: 'text-orange-400' },
          { label: 'Access Request', value: '30 Days', sub: 'PAIA response window', color: 'text-blue-400' },
        ].map((c, i) => (
          <div key={i} className="glass-card rounded-xl p-4 neon-glow text-center">
            <div className={`text-2xl font-bold font-grotesk ${c.color}`}>{c.value}</div>
            <div className="text-sm font-medium text-foreground mt-1">{c.label}</div>
            <div className="text-xs text-muted-foreground">{c.sub}</div>
          </div>
        ))}
      </div>

      {profile && (
        <div className="glass-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-grotesk font-semibold text-foreground">Your POPIA Compliance Score</h2>
            <span className="text-2xl font-bold font-grotesk text-primary">{score}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${score}%` }} />
          </div>
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">POPIA Compliance Checklist</h2>
        <div className="space-y-2">
          <ChecklistItem label="Information Officer designated and registered with Regulator" status={st(30)} detail="Deputy IO also recommended" />
          <ChecklistItem label="Privacy Policy published on website" status={st(40)} />
          <ChecklistItem label="POPIA compliance framework documented" status={st(45)} />
          <ChecklistItem label="Data inventory and processing register maintained" status={st(50)} />
          <ChecklistItem label="Consent mechanisms in place for marketing communications" status={st(55)} />
          <ChecklistItem label="Operator (third-party processor) agreements signed" status={st(60)} />
          <ChecklistItem label="Data breach response plan documented" status={st(65)} />
          <ChecklistItem label="Employee training on data handling conducted" status={st(70)} />
          <ChecklistItem label="PAIA Manual compiled and published" status={hasDoc('POPIA') ? st(50) : 'pending'} />
          <ChecklistItem label="Security measures (technical & organisational) implemented" status={st(75)} />
        </div>
      </div>

      <ExpandableSection title="8 Conditions for Lawful Processing" defaultOpen>
        {['Accountability — Responsible Party must be identifiable',
          'Processing Limitation — Collect only what is necessary',
          'Purpose Specification — Specific explicit purpose stated',
          'Further Processing Limitation — No use beyond original purpose',
          'Information Quality — Accurate and complete records',
          'Openness — Privacy notice provided to data subjects',
          'Security Safeguards — Technical and organisational measures',
          'Data Subject Participation — Allow access, correction, deletion requests'
        ].map((item, i) => <ChecklistItem key={i} label={item} status={st(50)} />)}
      </ExpandableSection>

      <ExpandableSection title="PAIA — Access to Information Manual">
        <ChecklistItem label="Compile PAIA Manual per Section 51" status={hasDoc('POPIA') ? 'done' : 'pending'} />
        <ChecklistItem label="Register Manual with South African Human Rights Commission" status="pending" />
        <ChecklistItem label="Publish Manual on company website" status="pending" />
        <ChecklistItem label="Appoint PAIA Deputy Information Officer" status="pending" />
        <ChecklistItem label="Process access requests within 30 days (extend to 30 days if needed)" status="pending" />
        <ChecklistItem label="Maintain records of all access requests received" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Data Breach Response Protocol">
        <ChecklistItem label="Identify and contain the breach immediately" status="pending" />
        <ChecklistItem label="Notify Information Regulator within 72 hours" status="pending" detail="regulator@inforegulator.org.za" urgent />
        <ChecklistItem label="Notify affected data subjects without undue delay" status="pending" />
        <ChecklistItem label="Document the breach and remedial actions" status="pending" />
        <ChecklistItem label="Review and update security controls post-breach" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Employee & HR Data Obligations">
        <ChecklistItem label="Employee consent obtained for data processing" status="pending" />
        <ChecklistItem label="Payroll data secured and access restricted" status="pending" />
        <ChecklistItem label="CCTV signage and retention policy documented" status="pending" />
        <ChecklistItem label="Biometric data: explicit consent required" status="pending" />
        <ChecklistItem label="Health data: additional conditions apply" status="pending" />
      </ExpandableSection>
    </div>
  );
}