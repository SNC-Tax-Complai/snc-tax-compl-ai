import { useState, useEffect } from 'react';
import { AlertTriangle, Shield, TrendingUp, FileText, Zap, Loader2, ChevronRight, RefreshCw, Building } from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import GaugeChart from '../components/GaugeChart';

const riskColors = {
  critical: { bg: 'bg-red-400/10', border: 'border-red-400/30', text: 'text-red-400', dot: 'bg-red-400' },
  high: { bg: 'bg-orange-400/10', border: 'border-orange-400/30', text: 'text-orange-400', dot: 'bg-orange-400' },
  medium: { bg: 'bg-yellow-400/10', border: 'border-yellow-400/30', text: 'text-yellow-400', dot: 'bg-yellow-400' },
  low: { bg: 'bg-green-400/10', border: 'border-green-400/30', text: 'text-green-400', dot: 'bg-green-400' },
};

function RiskCard({ risk, onGenerate, generating }) {
  const c = riskColors[risk.severity] || riskColors.medium;
  return (
    <div className={`glass-card rounded-xl border p-5 ${c.border} space-y-3`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 mt-1.5 ${c.dot} ${risk.severity === 'critical' ? 'animate-pulse' : ''}`} />
          <div>
            <p className="font-semibold text-foreground text-sm">{risk.title}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{risk.area} · Predicted: {risk.predicted_date}</p>
          </div>
        </div>
        <span className={`text-xs px-2 py-0.5 rounded-full border font-medium flex-shrink-0 ${c.bg} ${c.text} ${c.border}`}>
          {risk.severity.charAt(0).toUpperCase() + risk.severity.slice(1)}
        </span>
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed ml-5">{risk.description}</p>

      {risk.mitigations?.length > 0 && (
        <div className="ml-5 space-y-1.5">
          <p className="text-xs font-medium text-foreground">Mitigation Tasks</p>
          {risk.mitigations.map((m, i) => (
            <div key={i} className="flex items-start gap-2 p-2 bg-green-400/5 border border-green-400/20 rounded-lg">
              <span className="w-4 h-4 rounded-full bg-green-400/20 text-green-400 text-xs flex items-center justify-center font-bold flex-shrink-0">{i + 1}</span>
              <p className="text-xs text-foreground">{m}</p>
            </div>
          ))}
        </div>
      )}

      {risk.legislation && (
        <div className="ml-5 flex items-center gap-2 text-xs text-primary">
          <FileText className="w-3 h-3 flex-shrink-0" /> {risk.legislation}
        </div>
      )}

      <div className="ml-5 pt-1">
        <button onClick={() => onGenerate(risk)} disabled={generating}
          className="flex items-center gap-1.5 text-xs px-3 py-1.5 bg-primary/10 border border-primary/20 text-primary rounded-lg hover:bg-primary/20 transition-colors disabled:opacity-50">
          {generating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
          Auto-generate Resolution Doc
        </button>
      </div>
    </div>
  );
}

function NoProfileState() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <div className="relative">
          <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">🔮 Predictive Risk Analytics</span>
          <h1 className="text-2xl font-bold font-grotesk text-foreground mb-1">Compliance Risk Intelligence</h1>
          <p className="text-sm text-muted-foreground">AI-powered predictive analysis — identifies risks before they occur and auto-generates resolution documents.</p>
        </div>
      </div>
      <div className="glass-card rounded-xl p-12 flex flex-col items-center gap-4 border border-primary/10 text-center">
        <Building className="w-12 h-12 text-primary/40" />
        <h2 className="font-grotesk font-bold text-foreground">No Business Profile Found</h2>
        <p className="text-sm text-muted-foreground max-w-md">
          Risk analytics requires your business profile and uploaded compliance documents.
          Complete your onboarding or upload documents so Compl-i Assistant can analyse your risk exposure.
        </p>
        <div className="flex gap-3 mt-2">
          <Link to="/onboarding" className="px-5 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors">
            Complete Onboarding
          </Link>
          <Link to="/vault" className="px-5 py-2.5 border border-primary/30 text-primary rounded-xl text-sm font-medium hover:bg-primary/5 transition-colors">
            Upload Documents
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function RiskAnalytics() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [risks, setRisks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [profileLoading, setProfileLoading] = useState(true);
  const [generatingId, setGeneratingId] = useState(null);
  const [generatedDoc, setGeneratedDoc] = useState(null);
  const [riskScore, setRiskScore] = useState(null);
  const [fineProbabilities, setFineProbabilities] = useState([]);

  useEffect(() => {
    if (user?.id) loadProfile();
  }, [user]);

  const loadProfile = async () => {
    setProfileLoading(true);
    try {
      const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
      if (profiles.length > 0) {
        const p = profiles[0];
        setProfile(p);
        try {
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: p.id });
          setDocs(d);
        } catch {}
      }
    } catch (e) {
      console.error('Failed to load profile', e);
    }
    setProfileLoading(false);
  };

  const analyzeRisks = async () => {
    if (!profile) return;
    setLoading(true);
    setRisks([]);
    setRiskScore(null);
    setFineProbabilities([]);

    // Build real company profile from DB data
    const docSummary = docs.map(d => `${d.document_type}: ${d.status}`).join(', ') || 'No documents uploaded';
    const overdueFilings = profile.pending_filings ? `${profile.pending_filings} pending filing(s)` : 'None reported';
    const riskLevel = profile.risk_level || 'Unknown';

    const result = await api.integrations.Core.InvokeLLM({
      prompt: `You are a South African compliance risk analyst for Compl-Ai™ SA.

Company profile (from user's registered business data):
- Name: ${profile.entity_name || 'Not specified'}
- Sector: ${profile.industry || 'Not specified'}
- Entity Type: ${profile.entity_type || 'Not specified'}
- Province: ${profile.province || 'Not specified'}
- Employees: ${profile.employee_count || 'Not specified'}
- VAT Registered: ${profile.vat_registered || 'Not specified'}
- VAT Number: ${profile.vat_number || 'Not specified'}
- Registration Number: ${profile.reg_number || 'Not specified'}
- Turnover: ${profile.turnover || 'Not specified'}
- Current Compliance Score: ${profile.compliance_score || 'Not available'}%
- Risk Level: ${riskLevel}
- Pending Filings: ${overdueFilings}
- Urgent Alerts: ${profile.urgent_alerts || 0}
- Documents on file: ${docSummary}
- AI Analysis Summary: ${profile.ai_analysis_summary || 'Not available'}

Identify predictive compliance risks that are likely to occur in the next 90 days based on this REAL profile data. For each risk, provide specific South African legislative references, severity, predicted date, and 3 actionable mitigation tasks.

Also provide fine probability scores for SARS, CIPC, OHS, and Labour based on the actual profile data (not generic numbers).

Return JSON:
{
  "overall_risk_score": 0-100,
  "risk_grade": "A|B|C|D|F",
  "fine_probabilities": [
    { "label": "SARS Penalty", "value": 0-100, "sublabel": "reason based on profile" },
    { "label": "CIPC Fine", "value": 0-100, "sublabel": "reason based on profile" },
    { "label": "OHS Risk", "value": 0-100, "sublabel": "reason based on profile" },
    { "label": "Labour DoEL", "value": 0-100, "sublabel": "reason based on profile" }
  ],
  "risks": [
    {
      "id": "r1",
      "title": "Short risk title",
      "area": "SARS|CIPC|Labour|OHS|POPIA|FICA|B-BBEE|COIDA",
      "severity": "critical|high|medium|low",
      "predicted_date": "Month YYYY",
      "description": "Why this risk is predicted, 2 sentences",
      "mitigations": ["Action 1", "Action 2", "Action 3"],
      "legislation": "Specific Act + section reference"
    }
  ]
}`,
      response_json_schema: {
        type: 'object',
        properties: {
          overall_risk_score: { type: 'number' },
          risk_grade: { type: 'string' },
          fine_probabilities: {
            type: 'array', items: {
              type: 'object', properties: {
                label: { type: 'string' }, value: { type: 'number' }, sublabel: { type: 'string' }
              }
            }
          },
          risks: {
            type: 'array', items: {
              type: 'object', properties: {
                id: { type: 'string' }, title: { type: 'string' }, area: { type: 'string' },
                severity: { type: 'string' }, predicted_date: { type: 'string' },
                description: { type: 'string' }, mitigations: { type: 'array', items: { type: 'string' } },
                legislation: { type: 'string' },
              }
            }
          }
        }
      }
    });
    setRisks(result.risks || []);
    setRiskScore({ score: result.overall_risk_score, grade: result.risk_grade });
    setFineProbabilities(result.fine_probabilities || []);
    setLoading(false);
  };

  useEffect(() => { if (profile) analyzeRisks(); }, [profile, docs]);

  const generateDoc = async (risk) => {
    setGeneratingId(risk.id);
    const result = await api.integrations.Core.InvokeLLM({
      prompt: `Generate a formal compliance resolution document for: "${risk.title}" in the context of ${profile.entity_name || 'the company'} (${profile.industry || 'Unknown'} sector, ${profile.province || 'South Africa'}).

Include:
1. Document title, date, company details
2. Executive summary of the risk
3. Applicable South African legislation (${risk.legislation})
4. Detailed remediation steps
5. Timeline and responsible parties
6. Sign-off declaration

Write as a formal professional document. Plain text, no markdown.`,
    });
    setGeneratedDoc({ title: risk.title, content: result });
    setGeneratingId(null);
  };

  if (profileLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return <NoProfileState />;
  }

  const scoreColor = riskScore
    ? riskScore.score >= 70 ? 'text-red-400' : riskScore.score >= 40 ? 'text-yellow-400' : 'text-green-400'
    : 'text-primary';

  const fineGaugeColors = ['#ef4444', '#f97316', '#eab308', '#0096b4'];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <div className="relative flex items-start justify-between gap-4 flex-wrap">
          <div>
            <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">🔮 Predictive Risk Analytics</span>
            <h1 className="text-2xl font-bold font-grotesk text-foreground mb-1">Compliance Risk Intelligence</h1>
            <p className="text-sm text-muted-foreground">AI-powered predictive analysis — identifies risks before they occur and auto-generates resolution documents.</p>
          </div>
          {riskScore && (
            <div className="text-center glass-card rounded-xl p-4 border border-primary/20 flex-shrink-0">
              <p className="text-xs text-muted-foreground mb-1">Risk Score</p>
              <p className={`text-4xl font-bold font-grotesk ${scoreColor}`}>{riskScore.score}</p>
              <p className={`text-sm font-bold ${scoreColor}`}>Grade {riskScore.grade}</p>
            </div>
          )}
        </div>
      </div>

      {/* Fine probability gauges — from AI analysis */}
      {fineProbabilities.length > 0 && (
        <div className="glass-card rounded-xl p-5 border border-primary/10">
          <h2 className="font-grotesk font-semibold text-foreground text-sm mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" /> Penalty Fine Probability — Next 90 Days
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {fineProbabilities.map((g, i) => (
              <div key={i} className="flex flex-col items-center p-3 bg-secondary/40 rounded-xl border border-border">
                <GaugeChart value={g.value} color={fineGaugeColors[i % fineGaugeColors.length]} size={120} />
                <p className="text-xs font-semibold text-foreground text-center mt-1">{g.label}</p>
                <p className="text-xs text-muted-foreground text-center">{g.sublabel}</p>
                <span className={`text-xs px-2 py-0.5 rounded-full font-bold mt-1 ${g.value >= 70 ? 'bg-red-400/10 text-red-400' : g.value >= 45 ? 'bg-yellow-400/10 text-yellow-500' : 'bg-green-400/10 text-green-500'}`}>
                  {g.value >= 70 ? 'HIGH' : g.value >= 45 ? 'MEDIUM' : 'LOW'} RISK
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Company profile snapshot — real data */}
      <div className="glass-card rounded-xl p-5 border border-primary/10">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-grotesk font-semibold text-foreground text-sm flex items-center gap-2"><Shield className="w-4 h-4 text-primary" /> Company Profile</h2>
          <button onClick={analyzeRisks} disabled={loading} className="flex items-center gap-1.5 text-xs text-primary hover:underline disabled:opacity-50">
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} /> Re-analyse
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          {[
            { label: 'Company', value: profile.entity_name || 'Not Available' },
            { label: 'Sector', value: profile.industry || 'Not Available' },
            { label: 'Employees', value: profile.employee_count || 'Not Available' },
            { label: 'Pending Filings', value: profile.pending_filings ?? 'Not Available', color: profile.pending_filings > 0 ? 'text-red-400' : '' },
          ].map((f, i) => (
            <div key={i} className="bg-secondary/40 rounded-lg p-3">
              <p className="text-muted-foreground">{f.label}</p>
              <p className={`font-semibold text-sm mt-0.5 ${f.color || 'text-foreground'}`}>{f.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Risks */}
      {loading ? (
        <div className="glass-card rounded-xl p-16 flex flex-col items-center gap-4 border border-primary/10">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <div className="text-center">
            <p className="text-foreground font-medium">Compl-i Assistant is analysing your compliance profile...</p>
            <p className="text-sm text-muted-foreground mt-1">Predicting risks for the next 90 days</p>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <h2 className="font-grotesk font-semibold text-foreground flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-yellow-400" /> Predicted Compliance Risks — Next 90 Days
            <span className="text-xs text-muted-foreground ml-1">{risks.length} identified</span>
          </h2>
          {risks.length === 0 ? (
            <div className="glass-card rounded-xl p-8 text-center border border-primary/10">
              <p className="text-sm text-muted-foreground">No risks identified. Click "Re-analyse" to run the risk assessment.</p>
            </div>
          ) : (
            risks.map(r => (
              <RiskCard key={r.id} risk={r} onGenerate={generateDoc} generating={generatingId === r.id} />
            ))
          )}
        </div>
      )}

      {/* Generated document */}
      {generatedDoc && (
        <div className="glass-card rounded-xl border border-primary/20 overflow-hidden">
          <div className="flex items-center! justify-between p-4 border-b border-primary/10 bg-primary/5">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-primary" />
              <p className="font-semibold text-foreground text-sm">Auto-generated Resolution Document</p>
            </div>
            <button onClick={() => setGeneratedDoc(null)} className="text-xs text-muted-foreground hover:text-foreground">✕ Close</button>
          </div>
          <div className="p-6">
            <h3 className="font-bold text-foreground mb-4">{generatedDoc.title}</h3>
            <pre className="text-xs text-foreground leading-relaxed whitespace-pre-wrap font-sans bg-secondary/30 p-4 rounded-lg border border-border max-h-96 overflow-y-auto">
              {generatedDoc.content}
            </pre>
            <div className="mt-3 flex gap-2">
              <button onClick={() => navigator.clipboard.writeText(generatedDoc.content)}
                className="px-4 py-2 text-xs bg-secondary border border-border text-foreground rounded-lg hover:bg-secondary/80 transition-colors">
                Copy to Clipboard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}