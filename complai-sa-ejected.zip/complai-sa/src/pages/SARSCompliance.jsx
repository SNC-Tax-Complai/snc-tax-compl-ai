import { useState, useEffect } from 'react';
import { Calendar, Loader2 } from 'lucide-react';
import { PageHero, ExpandableSection, ChecklistItem, DeadlineBadge } from '../components/ComplianceSection';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

export default function SARSCompliance() {
  const { user } = useAuth();
  const { isDemo, demoProfile, demoDocuments } = useDemo();
  const [profile, setProfile] = useState(null);
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isDemo) { setProfile(demoProfile); setDocs(demoDocuments); setLoading(false); return; }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          const d = await api.entities.ComplianceDocument.filter({ business_profile_id: profiles[0].id });
          setDocs(d);
        }
      } catch (e) { console.error('SARS load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const score = profile?.sars_score ?? 0;
  const vatRegistered = profile?.vat_registered === 'Yes';
  const hasDoc = (cat) => docs.some(d => (d.document_type || '').toLowerCase().includes(cat.toLowerCase()));
  const st = (threshold) => score >= threshold ? 'done' : score > 0 ? 'pending' : 'urgent';

  if (loading) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <PageHero badge="SARS Tax Compliance" title="South African Revenue Service"
        subtitle="Income tax, VAT, PAYE, provisional tax, and all SARS filing obligations for individuals, sole proprietors, and companies." />

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: 'VAT Threshold', value: 'R1.1M', sub: 'Compulsory registration', color: 'text-green-400' },
          { label: 'Corporate Tax Rate', value: '27%', sub: 'Effective 1 Apr 2022', color: 'text-blue-400' },
          { label: 'SBC Threshold', value: 'R20M', sub: 'Small Business Corp', color: 'text-purple-400' },
          { label: 'Turnover Tax', value: 'R1M', sub: 'Qualifying small entities', color: 'text-yellow-400' },
        ].map((c, i) => (
          <div key={i} className="glass-card rounded-xl p-4 neon-glow text-center">
            <div className={`text-2xl font-bold font-grotesk ${c.color}`}>{c.value}</div>
            <div className="text-sm font-medium text-foreground mt-1">{c.label}</div>
            <div className="text-xs text-muted-foreground">{c.sub}</div>
          </div>
        ))}
      </div>

      {profile && (
        <div className="glass-card rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-grotesk font-semibold text-foreground">Your SARS Compliance Score</h2>
            <span className="text-2xl font-bold font-grotesk text-primary">{score}%</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${score}%` }} />
          </div>
          {vatRegistered && <p className="text-xs text-muted-foreground mt-2">VAT Registered: Yes ({profile.vat_number || 'No VAT number on file'})</p>}
          {!vatRegistered && <p className="text-xs text-muted-foreground mt-2">VAT Registered: No</p>}
        </div>
      )}

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4 flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> 2026 Key SARS Deadlines</h2>
        <div className="space-y-2">
          <DeadlineBadge label="EMP201 — Monthly Payroll Submission" date="7th of each month" urgent />
          <DeadlineBadge label="IRP6 — 1st Provisional Tax" date="31 August 2026" />
          <DeadlineBadge label="IRP6 — 2nd Provisional Tax" date="28 February 2026" urgent />
          <DeadlineBadge label="VAT201 — Bi-Monthly Return" date="25th of month after period" />
          <DeadlineBadge label="ITR12 — Individual Income Tax" date="Mid-October 2026" />
          <DeadlineBadge label="ITR14 — Company Income Tax" date="12 months after year-end" />
          <DeadlineBadge label="EMP501 — Annual Reconciliation" date="31 May 2026" />
          <DeadlineBadge label="EMP501 — Interim Reconciliation" date="31 October 2026" />
        </div>
      </div>

      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">Compliance Checklist</h2>
        <div className="space-y-2">
          <ChecklistItem label="Registered as taxpayer with SARS (IT number)" status={st(20)} />
          <ChecklistItem label="eFiling profile active and verified" status={st(30)} />
          <ChecklistItem label="EMP201 submitted this month" status={st(50)} detail="PAYE + SDL + UIF" />
          <ChecklistItem label="Provisional tax estimates calculated" status={st(60)} detail="Based on actual income YTD" />
          <ChecklistItem label="VAT201 current" status={vatRegistered ? st(50) : 'done'} detail={vatRegistered ? `VAT No: ${profile.vat_number || 'Not available'}` : 'Not VAT registered'} />
          <ChecklistItem label="Tax clearance certificate up to date" status={hasDoc('SARS') || hasDoc('Tax') ? st(40) : 'pending'} />
          <ChecklistItem label="PAYE reconciliation (EMP501) on schedule" status={st(55)} />
          <ChecklistItem label="IRP5 certificates issued to employees" status={st(65)} />
          <ChecklistItem label="Section 12E (SBC) criteria reviewed" status={st(70)} detail="Tax benefit if qualifying" />
        </div>
      </div>

      <ExpandableSection title="Provisional Tax (IRP6) — Calculations" defaultOpen>
        <p className="text-sm text-muted-foreground mb-3">Two payments annually (August & February). Calculated on estimated taxable income for the year.</p>
        <div className="bg-secondary/30 rounded-lg p-4 font-mono text-xs text-primary mb-3">
          <p>1st Payment (Aug): 50% of estimated annual tax - PAYE paid</p>
          <p>2nd Payment (Feb): Full estimated annual tax - 1st payment - PAYE</p>
          <p>Penalty: 20% if underpaid by more than basic amount</p>
        </div>
        <ChecklistItem label="Estimate total taxable income for year" status="pending" />
        <ChecklistItem label="Deduct all allowable expenses and deductions" status="pending" />
        <ChecklistItem label="Apply correct tax table (individual or company)" status="pending" />
        <ChecklistItem label="Subtract PAYE credits and prior provisional payments" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Value Added Tax (VAT)">
        <p className="text-sm text-muted-foreground mb-3">Compulsory registration if turnover exceeds R1.1M/year. Voluntary registration from R50,000.</p>
        <ChecklistItem label="Determine registration obligation" status={vatRegistered ? 'done' : 'pending'} />
        <ChecklistItem label="Register on eFiling (VAT101 form)" status={vatRegistered ? 'done' : 'pending'} />
        <ChecklistItem label="Issue valid tax invoices to clients" status="pending" detail="Must include VAT number, date, amount" />
        <ChecklistItem label="Maintain input tax records (purchases)" status="pending" />
        <ChecklistItem label="Submit VAT201 bi-monthly or monthly" status="pending" />
        <ChecklistItem label="Apply for VAT refund if input > output" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Payroll Taxes — PAYE, SDL, UIF">
        <ChecklistItem label="Registered as employer with SARS" status={profile?.employee_count ? 'done' : 'pending'} />
        <ChecklistItem label="Calculate PAYE on all employees monthly" status="pending" />
        <ChecklistItem label="Deduct & remit UIF (1% employer + 1% employee)" status="pending" />
        <ChecklistItem label="SDL: 1% of payroll if total payroll > R500,000/year" status="pending" />
        <ChecklistItem label="Submit EMP201 by 7th each month" status="pending" />
        <ChecklistItem label="Reconcile via EMP501 twice annually" status="pending" />
      </ExpandableSection>

      <ExpandableSection title="Small Business Corporation (SBC) Benefits">
        <p className="text-sm text-muted-foreground mb-3">Section 12E provides preferential rates for companies with gross income below R20M meeting qualifying criteria.</p>
        <ChecklistItem label="Turnover below R20M" status={profile?.turnover ? 'done' : 'pending'} />
        <ChecklistItem label="Not a personal service provider" status="pending" />
        <ChecklistItem label="No shareholder holds interest in another company" status="pending" detail="Check all director shareholdings" />
        <ChecklistItem label="Apply SBC tax table (0% - 28% tiered)" status="pending" />
      </ExpandableSection>
    </div>
  );
}