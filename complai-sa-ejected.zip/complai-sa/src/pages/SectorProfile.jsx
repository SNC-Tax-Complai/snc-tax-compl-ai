import { useState } from 'react';
import { CheckCircle, Clock, AlertTriangle, Building, Loader2, ChevronRight, Zap, RefreshCw } from 'lucide-react';
import { api } from '@/api/apiClient';

const SECTORS = [
  { id: 'retail', label: 'Retail & Wholesale', emoji: '🛒' },
  { id: 'construction', label: 'Construction', emoji: '🏗️' },
  { id: 'food_bev', label: 'Food & Beverage', emoji: '🍽️' },
  { id: 'healthcare', label: 'Healthcare', emoji: '⚕️' },
  { id: 'technology', label: 'Technology & ICT', emoji: '💻' },
  { id: 'transport', label: 'Transport & Logistics', emoji: '🚚' },
  { id: 'agriculture', label: 'Agriculture', emoji: '🌾' },
  { id: 'financial', label: 'Financial Services', emoji: '💰' },
  { id: 'property', label: 'Property & Real Estate', emoji: '🏘️' },
  { id: 'hospitality', label: 'Hospitality & Tourism', emoji: '🏨' },
  { id: 'manufacturing', label: 'Manufacturing', emoji: '🏭' },
  { id: 'professional', label: 'Professional Services', emoji: '💼' },
];

const statusIcon = { done: CheckCircle, pending: Clock, urgent: AlertTriangle };
const statusColor = { done: 'text-green-400', pending: 'text-yellow-400', urgent: 'text-red-400' };

function CheckItem({ label, status = 'pending', note }) {
  const Icon = statusIcon[status] || Clock;
  return (
    <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
      <Icon className={`w-4 h-4 mt-0.5 flex-shrink-0 ${statusColor[status] || 'text-yellow-400'}`} />
      <div>
        <p className="text-sm text-foreground">{label}</p>
        {note && <p className="text-xs text-muted-foreground mt-0.5">{note}</p>}
      </div>
    </div>
  );
}

export default function SectorProfile() {
  const [selected, setSelected] = useState(SECTORS[0]);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchProfile = async (sector) => {
    setLoading(true);
    setProfile(null);
    const result = await api.integrations.Core.InvokeLLM({
      prompt: `You are a South African compliance expert. Generate a complete compliance dashboard profile for the "${sector.label}" industry sector as of April 2026.

Return JSON:
{
  "summary": "2-sentence overview of key compliance obligations for this sector",
  "regulatory_bodies": ["body1", "body2"],
  "mandatory_registrations": [
    { "name": "Registration name", "authority": "Authority", "act": "Act + section", "urgency": "required|recommended" }
  ],
  "checklists": [
    {
      "category": "Category name (e.g. Tax & SARS, Labour Law, OHS, etc.)",
      "items": [
        { "label": "Checklist item", "status": "done|pending|urgent", "note": "brief note or Act ref" }
      ]
    }
  ],
  "sector_specific_licenses": ["License 1", "License 2"],
  "top_risks": ["Risk 1", "Risk 2", "Risk 3"],
  "quick_wins": ["Quick win 1", "Quick win 2"]
}

Provide 4-6 categories each with 3-5 checklist items. Be specific to South African law for the ${sector.label} sector.`,
      response_json_schema: {
        type: 'object',
        properties: {
          summary: { type: 'string' },
          regulatory_bodies: { type: 'array', items: { type: 'string' } },
          mandatory_registrations: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, authority: { type: 'string' }, act: { type: 'string' }, urgency: { type: 'string' } } } },
          checklists: { type: 'array', items: { type: 'object', properties: { category: { type: 'string' }, items: { type: 'array', items: { type: 'object', properties: { label: { type: 'string' }, status: { type: 'string' }, note: { type: 'string' } } } } } } },
          sector_specific_licenses: { type: 'array', items: { type: 'string' } },
          top_risks: { type: 'array', items: { type: 'string' } },
          quick_wins: { type: 'array', items: { type: 'string' } },
        }
      }
    });
    setProfile(result);
    setLoading(false);
  };

  const handleSelect = (sector) => {
    setSelected(sector);
    fetchProfile(sector);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <div className="relative">
          <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">🏭 Industry Sector Profiling</span>
          <h1 className="text-2xl font-bold font-grotesk text-foreground mb-1">Dynamic Sector Compliance Configurator</h1>
          <p className="text-sm text-muted-foreground">Select your industry — Emma-i™ automatically configures your compliance dashboard and regulatory checklists.</p>
        </div>
      </div>

      {/* Sector grid */}
      <div className="glass-card rounded-xl p-5 border border-primary/10">
        <p className="text-xs text-muted-foreground mb-3 font-medium uppercase tracking-wider">Select Your Industry Sector</p>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
          {SECTORS.map(s => (
            <button key={s.id} onClick={() => handleSelect(s)}
              className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border text-center transition-all text-xs font-medium ${selected.id === s.id ? 'border-primary bg-primary/10 text-primary neon-glow' : 'border-border bg-secondary/30 text-muted-foreground hover:border-primary/40 hover:text-foreground'}`}>
              <span className="text-xl">{s.emoji}</span>
              <span className="leading-tight">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      {!profile && !loading && (
        <div className="glass-card rounded-xl p-12 text-center border border-primary/10">
          <Building className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">Select an industry sector above to load your tailored compliance profile.</p>
          <button onClick={() => fetchProfile(selected)} className="mt-4 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium neon-glow hover:bg-primary/90 transition-colors">
            Load {selected.emoji} {selected.label} Profile
          </button>
        </div>
      )}

      {loading && (
        <div className="glass-card rounded-xl p-16 flex flex-col items-center gap-4 border border-primary/10">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <div className="text-center">
            <p className="text-foreground font-medium">Configuring {selected.emoji} {selected.label} compliance profile...</p>
            <p className="text-sm text-muted-foreground mt-1">Emma-i™ is loading sector-specific SA regulatory requirements</p>
          </div>
        </div>
      )}

      {profile && !loading && (
        <div className="space-y-5">
          {/* Summary banner */}
          <div className="glass-card rounded-xl p-5 border border-primary/20 bg-primary/5">
            <div className="flex items-start justify-between gap-3 mb-3">
              <h2 className="font-grotesk font-bold text-foreground text-lg">{selected.emoji} {selected.label} — Compliance Profile</h2>
              <button onClick={() => fetchProfile(selected)} className="p-1.5 text-muted-foreground hover:text-primary">
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-sm text-foreground leading-relaxed">{profile.summary}</p>
            {profile.regulatory_bodies?.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {profile.regulatory_bodies.map((b, i) => (
                  <span key={i} className="text-xs px-2 py-0.5 bg-primary/10 border border-primary/20 text-primary rounded-full">{b}</span>
                ))}
              </div>
            )}
          </div>

          <div className="grid lg:grid-cols-3 gap-5">
            {/* Main checklists — 2 cols */}
            <div className="lg:col-span-2 space-y-4">
              {profile.checklists?.map((cat, ci) => (
                <div key={ci} className="glass-card rounded-xl border border-primary/10 overflow-hidden">
                  <div className="px-4 py-3 border-b border-border bg-secondary/30">
                    <h3 className="font-semibold text-foreground text-sm">{cat.category}</h3>
                  </div>
                  <div className="p-4 space-y-2">
                    {cat.items?.map((item, ii) => (
                      <CheckItem key={ii} label={item.label} status={item.status} note={item.note} />
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Sidebar */}
            <div className="space-y-4">
              {/* Mandatory Registrations */}
              {profile.mandatory_registrations?.length > 0 && (
                <div className="glass-card rounded-xl p-4 border border-primary/10">
                  <h3 className="font-grotesk font-semibold text-foreground text-sm mb-3 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-primary" /> Mandatory Registrations
                  </h3>
                  <div className="space-y-2">
                    {profile.mandatory_registrations.map((r, i) => (
                      <div key={i} className={`p-3 rounded-lg border text-xs ${r.urgency === 'required' ? 'border-red-400/20 bg-red-400/5' : 'border-border bg-secondary/30'}`}>
                        <p className="font-medium text-foreground">{r.name}</p>
                        <p className="text-muted-foreground mt-0.5">{r.authority} · {r.act}</p>
                        <span className={`mt-1 inline-block px-1.5 py-0.5 rounded text-xs font-medium ${r.urgency === 'required' ? 'bg-red-400/10 text-red-400' : 'bg-primary/10 text-primary'}`}>
                          {r.urgency}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sector Licences */}
              {profile.sector_specific_licenses?.length > 0 && (
                <div className="glass-card rounded-xl p-4 border border-yellow-400/20">
                  <h3 className="font-grotesk font-semibold text-foreground text-sm mb-3 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-yellow-400" /> Sector-Specific Licences
                  </h3>
                  <div className="space-y-1.5">
                    {profile.sector_specific_licenses.map((l, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-foreground py-1.5 border-b border-border last:border-0">
                        <ChevronRight className="w-3 h-3 text-primary flex-shrink-0" /> {l}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Top Risks */}
              {profile.top_risks?.length > 0 && (
                <div className="glass-card rounded-xl p-4 border border-red-400/20">
                  <h3 className="font-grotesk font-semibold text-foreground text-sm mb-3 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-400" /> Top Sector Risks
                  </h3>
                  {profile.top_risks.map((r, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-foreground py-1.5 border-b border-border last:border-0">
                      <span className="w-4 h-4 rounded-full bg-red-400/20 text-red-400 text-xs flex items-center justify-center font-bold flex-shrink-0">{i + 1}</span>
                      {r}
                    </div>
                  ))}
                </div>
              )}

              {/* Quick Wins */}
              {profile.quick_wins?.length > 0 && (
                <div className="glass-card rounded-xl p-4 border border-green-400/20">
                  <h3 className="font-grotesk font-semibold text-foreground text-sm mb-3 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-green-400" /> Quick Wins
                  </h3>
                  {profile.quick_wins.map((w, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-foreground py-1.5 border-b border-border last:border-0">
                      <span className="w-4 h-4 rounded-full bg-green-400/20 text-green-400 text-xs flex items-center justify-center font-bold flex-shrink-0">{i + 1}</span>
                      {w}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}