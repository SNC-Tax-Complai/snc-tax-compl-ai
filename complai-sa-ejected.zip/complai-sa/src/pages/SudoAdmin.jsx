import { useState, useEffect } from 'react';
import {
  Shield, Users, Building, CreditCard, Power, PowerOff, Eye, EyeOff,
  Plus, Trash2, CheckCircle, AlertTriangle, Lock, FileText, ChevronDown,
  ChevronUp, Settings, LogOut, Bell, RefreshCw, Download, X, Loader2
} from 'lucide-react';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';

const LEGAL_DOCS = [
  {
    id: 'saas_agreement',
    title: 'SaaS Master Services Agreement',
    content: `SAAS MASTER SERVICES AGREEMENT

Between: SNC-TAX ("Provider") and the subscribing B2B Client ("Client")

1. SERVICES
The Provider grants the Client a non-exclusive, non-transferable licence to access and use the Compl-Ai™ SA white-label compliance platform ("the Platform") for internal business purposes and to provide compliance management services to the Client's own end-users.

2. WHITE-LABEL RIGHTS
Subject to payment of applicable subscription fees, the Client is permitted to rebrand the Platform with their own company name, logo, and colour scheme. The Platform may not be represented as the Client's own proprietary software.

3. SUBSCRIPTION & BILLING
Fees are payable monthly in advance. Failure to pay within 7 days of the due date entitles SNC-TAX to suspend access. All fees are quoted in ZAR and exclude VAT.

4. DATA PRIVACY & POPIA COMPLIANCE
Each party is independently responsible for compliance with POPIA in respect of personal information they process. SNC-TAX, as Platform Provider, will not access end-user data belonging to the Client's clients. The Client is the Responsible Party for their end-users' personal information.

5. CONFIDENTIALITY
Both parties agree to keep confidential all proprietary information disclosed in connection with this Agreement, including pricing, technical specifications, and client lists.

6. INTELLECTUAL PROPERTY
SNC-TAX retains all intellectual property rights in the Platform. No rights are transferred to the Client beyond the limited licence described herein.

7. LIMITATION OF LIABILITY
SNC-TAX's total liability to the Client shall not exceed the fees paid in the preceding 3 months.

8. TERMINATION
Either party may terminate with 30 days written notice. SNC-TAX may terminate immediately for material breach or non-payment.

9. GOVERNING LAW
This Agreement is governed by the laws of the Republic of South Africa.`,
  },
  {
    id: 'data_processing',
    title: 'Data Processing Agreement (DPA)',
    content: `DATA PROCESSING AGREEMENT

This DPA forms part of the Master Services Agreement between SNC-TAX and the Client.

SCOPE
This DPA governs the processing of personal information by SNC-TAX as Operator on behalf of the Client as Responsible Party, in accordance with POPIA (Act 4 of 2013).

POPIA COMPLIANCE OBLIGATIONS — SNC-TAX (Operator)
- Process personal information only on documented instructions from the Client.
- Implement appropriate technical and organisational security measures.
- Not engage sub-operators without prior written consent from the Client.
- Assist the Client in fulfilling data subject rights requests.
- Delete or return all personal information upon termination of services.
- Notify the Client within 72 hours of becoming aware of a security compromise.

POPIA COMPLIANCE OBLIGATIONS — CLIENT (Responsible Party)
- Ensure lawful basis for all personal information processing.
- Obtain valid consent from end-users where required.
- Maintain a POPIA compliance framework within their own organisation.
- Appoint a designated Information Officer.

DATA ISOLATION
SNC-TAX technical controls ensure complete data isolation between Client instances. SNC-TAX personnel will not access Client end-user data except as strictly required for technical support and only with Client consent.

SECURITY MEASURES
- Data encrypted at rest (AES-256) and in transit (TLS 1.3+)
- Access controls with least-privilege principles
- Regular security assessments and penetration testing
- South African data residency compliance`,
  },
  {
    id: 'reseller_terms',
    title: 'Reseller / White-Label Terms',
    content: `RESELLER & WHITE-LABEL TERMS

1. ELIGIBILITY
To become a White-Label Reseller of Compl-Ai™ SA, the Client must: (a) be a registered South African entity; (b) maintain a valid subscription; (c) agree to these Terms.

2. PERMITTED ACTIVITIES
Resellers may: (a) rebrand the Platform under their own name; (b) market and sell access to their own business clients; (c) set their own pricing to end-clients.

3. PROHIBITED ACTIVITIES
Resellers may NOT: (a) claim ownership of the underlying technology; (b) sublicense or assign their rights; (c) modify the Platform's core functionality; (d) use the Platform for illegal purposes.

4. BRANDING GUIDELINES
- The powered-by attribution ("Powered by Compl-Ai™ SA | SA-iLabs®™") must appear in the platform footer unless Enterprise plan.
- Resellers may use their own logo and brand colours.
- The Compl-Ai™ and Compl-i Assistant brand marks remain the property of SNC-TAX / SA-iLabs®™.

5. SUPPORT
SNC-TAX provides Tier-2 support to Resellers only. Resellers are responsible for Tier-1 support to their own end-clients.

6. COMMISSION & REVENUE
No commission is payable to SNC-TAX on the Reseller's end-client pricing. The Reseller pays the fixed platform subscription fee regardless of end-client revenue.

7. TERMINATION EFFECT
Upon termination, the Reseller must cease all use of SNC-TAX branding and provide 30 days notice to their end-clients.`,
  },
  {
    id: 'acceptable_use',
    title: 'Acceptable Use Policy (AUP)',
    content: `ACCEPTABLE USE POLICY

This AUP applies to all B2B Clients and their end-users of the Compl-Ai™ SA Platform.

PERMITTED USE
The Platform is provided solely for the purpose of South African statutory compliance management, including but not limited to: SARS filings, CIPC submissions, labour law compliance, B-BBEE tracking, and POPIA compliance management.

PROHIBITED CONDUCT
Users may not:
- Use the Platform to engage in any unlawful activity
- Attempt to gain unauthorised access to other users' accounts or data
- Reverse engineer, decompile, or attempt to extract source code
- Use automated scraping tools against the Platform
- Upload malware, ransomware, or malicious code
- Use the Platform to process personal information beyond its intended compliance purpose
- Share login credentials between multiple users
- Use a single licence for multiple business entities without authorisation

DATA UPLOAD RESTRICTIONS
- Maximum file size per upload: 50MB
- Permitted file types: PDF, DOCX, XLSX, PNG, JPG, JPEG
- No personal information of individuals unrelated to the subscribing business

ENFORCEMENT
Violations may result in: immediate account suspension; termination of subscription; reporting to relevant authorities where required by law.`,
  },
  {
    id: 'sla',
    title: 'Service Level Agreement (SLA)',
    content: `SERVICE LEVEL AGREEMENT

Provider: SNC-TAX (via SA-iLabs®™ infrastructure)
Applicable to: All active subscription tiers

UPTIME COMMITMENT
- Starter Plan: 99.0% monthly uptime
- Pro Plan: 99.5% monthly uptime
- Enterprise Plan: 99.9% monthly uptime

Uptime is calculated excluding scheduled maintenance windows (communicated with 48 hours advance notice) and force majeure events.

SUPPORT RESPONSE TIMES
- Critical (Platform down): 2 hours (Pro/Enterprise), 4 hours (Starter)
- High (Core feature unavailable): 4 hours (Pro/Enterprise), 8 hours (Starter)
- Medium (Feature degraded): 1 business day
- Low (General query): 3 business days

SUPPORT CHANNELS
- Email: support@snctax.co.za
- In-platform Compl-i Assistant chat
- Enterprise: Dedicated account manager

PLANNED MAINTENANCE
Scheduled between 01:00–04:00 SAST on Sundays. Advanced notice provided via in-platform notifications and email.

REMEDIES FOR BREACH
If uptime falls below the committed level, affected Clients may claim a service credit of 5% of monthly fees per percentage point below commitment (capped at 30%).

DATA BACKUP
Daily automated backups with 30-day retention. Point-in-time recovery available for Enterprise plans.`,
  },
];

const inputCls = "w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none";

// ── Sub-components ────────────────────────────────────────────────────────────
function LegalDocPanel() {
  const [open, setOpen] = useState(null);
  return (
    <div className="space-y-3">
      {LEGAL_DOCS.map(doc => (
        <div key={doc.id} className="glass-card rounded-xl border border-border overflow-hidden">
          <button onClick={() => setOpen(open === doc.id ? null : doc.id)}
            className="w-full flex items-center justify-between p-4 text-left hover:bg-secondary/30 transition-colors">
            <div className="flex items-center gap-3">
              <FileText className="w-4 h-4 text-primary" />
              <span className="font-semibold text-foreground text-sm">{doc.title}</span>
            </div>
            <div className="flex items-center gap-3">
              <button onClick={e => { e.stopPropagation(); const blob = new Blob([doc.content], {type:'text/plain'}); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `${doc.id}.txt`; a.click(); }}
                className="flex items-center gap-1 text-xs text-primary hover:underline">
                <Download className="w-3 h-3" /> Export
              </button>
              {open === doc.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>
          </button>
          {open === doc.id && (
            <div className="px-5 pb-5 border-t border-border">
              <pre className="mt-4 text-xs text-foreground leading-relaxed whitespace-pre-wrap font-sans max-h-80 overflow-y-auto">{doc.content}</pre>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function ClientRow({ client, onToggle, onDelete }) {
  const statusStyle = {
    active: 'bg-green-400/10 text-green-400',
    suspended: 'bg-red-400/10 text-red-400',
    pending: 'bg-yellow-400/10 text-yellow-400',
  };
  const status = client.onboarding_complete ? 'active' : 'pending';
  return (
    <tr className="hover:bg-secondary/30 transition-colors">
      <td className="py-3 px-4 font-medium text-foreground">{client.entity_name || 'Not specified'}</td>
      <td className="py-3 px-4 text-muted-foreground text-xs">{client.director_email || 'Not Available'}</td>
      <td className="py-3 px-4">
        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusStyle[status] || 'bg-secondary text-muted-foreground'}`}>{status}</span>
      </td>
      <td className="py-3 px-4 text-foreground text-sm">{client.compliance_score != null ? `${client.compliance_score}%` : 'Not Available'}</td>
      <td className="py-3 px-4 text-muted-foreground text-xs font-mono">
        {client.created_date ? new Date(client.created_date).toLocaleDateString('en-ZA') : '—'}
      </td>
      <td className="py-3 px-4">
        <div className="flex items-center gap-1">
          <button onClick={() => onToggle(client.id)}
            className={`p-1.5 rounded-lg transition-colors text-xs ${status === 'active' ? 'text-red-400 hover:bg-red-400/10' : 'text-green-400 hover:bg-green-400/10'}`}
            title={status === 'active' ? 'Suspend' : 'Activate'}>
            {status === 'active' ? <PowerOff className="w-3.5 h-3.5" /> : <Power className="w-3.5 h-3.5" />}
          </button>
          <button onClick={() => onDelete(client.id)} className="p-1.5 text-muted-foreground hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </td>
    </tr>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function SudoAdmin() {
  const { user } = useAuth();
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState('clients');
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [newClient, setNewClient] = useState({ company: '', contact: '', plan: 'Starter', billing: 'R1,499/mo' });

  // ── Auth gate (uses platform auth) ──
  useEffect(() => {
    const check = async () => {
      try {
        const me = await api.auth.me();
        if (!me) { setAuthed(false); return; }
        const domain = me.email?.split('@')[1]?.toLowerCase();
        const allowed = ['snctax.co.za', 'snatax.co.za', 'sa-ilabs.co.za'].includes(domain) || me.role === 'admin';
        setAuthed(allowed);
      } catch {
        setAuthed(false);
      }
    };
    check();
  }, []);

  // ── Load real clients from DB ──
  const loadClients = async () => {
    setLoading(true);
    try {
      const profiles = await api.entities.BusinessProfile.list('-created_date', 500);
      setClients(profiles);
    } catch (e) {
      console.error('Failed to load clients', e);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (authed) loadClients();
  }, [authed]);

  const toggleStatus = async (id) => {
    const client = clients.find(c => c.id === id);
    if (!client) return;
    const newStatus = !client.onboarding_complete;
    try {
      await api.entities.BusinessProfile.update(id, { onboarding_complete: newStatus });
      setClients(prev => prev.map(c => c.id === id ? { ...c, onboarding_complete: newStatus } : c));
    } catch (e) {
      console.error('Failed to toggle status', e);
    }
  };

  const deleteClient = async (id) => {
    try {
      await api.entities.BusinessProfile.delete(id);
      setClients(prev => prev.filter(c => c.id !== id));
    } catch (e) {
      console.error('Failed to delete client', e);
    }
  };

  const addClient = async () => {
    if (!newClient.company) return;
    try {
      const created = await api.entities.BusinessProfile.create({
        user_id: user?.id || '',
        entity_name: newClient.company,
        director_email: newClient.contact,
        onboarding_complete: false,
      });
      setClients(prev => [created, ...prev]);
      setNewClient({ company: '', contact: '', plan: 'Starter', billing: 'R1,499/mo' });
      setShowAdd(false);
    } catch (e) {
      console.error('Failed to add client', e);
    }
  };

  const stats = {
    total: clients.length,
    active: clients.filter(c => c.onboarding_complete).length,
    pending: clients.filter(c => !c.onboarding_complete).length,
    totalDocs: clients.reduce((a, c) => a + (c.pending_filings || 0), 0),
  };

  const TABS = [
    { key: 'clients', label: 'Client Management', icon: Building },
    { key: 'billing', label: 'Billing Overview', icon: CreditCard },
    { key: 'legal', label: 'Legal Documents', icon: FileText },
    { key: 'settings', label: 'Platform Settings', icon: Settings },
  ];

  // ── Access Denied Screen ──
  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-background">
        <div className="w-full max-w-sm glass-card rounded-2xl border border-primary/20 p-8 neon-glow animate-slide-up">
          <div className="text-center mb-8">
            <div className="w-14 h-14 bg-red-50 border border-red-200 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-7 h-7 text-red-500" />
            </div>
            <h1 className="text-xl font-bold font-grotesk text-foreground">Access Restricted</h1>
            <p className="text-xs text-muted-foreground mt-1">SaaS Management Console · Admin access required</p>
          </div>
          <p className="text-sm text-muted-foreground text-center mb-6">
            Only SNC-TAX staff with authorised email domains (@snctax.co.za) or users with the Admin role may access this portal.
          </p>
          <a href="/admin-login" className="block w-full text-center py-3 bg-primary text-primary-foreground rounded-lg font-semibold text-sm neon-glow hover:bg-primary/90 transition-colors">
            Go to Admin Login
          </a>
        </div>
      </div>
    );
  }

  // ── Admin Dashboard ──
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-6 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div>
            <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-2 border border-primary/30">
              🔐 Sudo Admin · SNC-TAX SaaS Management Portal
            </span>
            <h1 className="text-2xl font-bold font-grotesk text-foreground">White-Label SaaS Control Centre</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage B2B clients, billing, suspensions & platform settings. POPIA-compliant — no access to client end-user data.</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={loadClients} className="flex items-center gap-2 px-3 py-2 border border-border text-muted-foreground rounded-lg text-sm hover:text-primary hover:bg-primary/5 transition-colors">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
            </button>
            <button onClick={() => api.auth.logout('/admin-login')}
              className="flex items-center gap-2 px-4 py-2 border border-red-400/30 text-red-400 rounded-lg text-sm hover:bg-red-400/10 transition-colors">
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        </div>
      </div>

      {/* KPI Row — from real DB data */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total B2B Clients', value: stats.total, icon: Building, color: 'text-primary' },
          { label: 'Active (Onboarded)', value: stats.active, icon: CheckCircle, color: 'text-green-400' },
          { label: 'Pending Onboarding', value: stats.pending, icon: AlertTriangle, color: 'text-yellow-400' },
          { label: 'Total Pending Filings', value: stats.totalDocs, icon: FileText, color: 'text-purple-400' },
        ].map((k, i) => (
          <div key={i} className="glass-card rounded-xl p-4 border border-primary/10">
            <div className="flex items-center gap-2 mb-2">
              <k.icon className={`w-4 h-4 ${k.color}`} />
              <p className="text-xs text-muted-foreground">{k.label}</p>
            </div>
            <p className="text-2xl font-bold font-grotesk text-foreground">{k.value}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 glass-card rounded-xl p-1 border border-primary/10 flex-wrap">
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all ${tab === t.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
            <t.icon className="w-3.5 h-3.5" />{t.label}
          </button>
        ))}
      </div>

      {/* ── Clients Tab ── */}
      {tab === 'clients' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h2 className="font-grotesk font-semibold text-foreground">B2B Client Accounts</h2>
              <p className="text-xs text-muted-foreground mt-0.5">Activate, suspend or remove client accounts. No access to their end-user data (POPIA).</p>
            </div>
            <button onClick={() => setShowAdd(true)}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium neon-glow">
              <Plus className="w-4 h-4" /> Add Client
            </button>
          </div>

          {showAdd && (
            <div className="glass-card rounded-xl p-5 border border-primary/20 space-y-3">
              <h3 className="font-semibold text-foreground text-sm">New B2B Client</h3>
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Company Name</label>
                  <input value={newClient.company} onChange={e => setNewClient(p => ({ ...p, company: e.target.value }))} placeholder="Firm name" className={inputCls} />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Contact Email</label>
                  <input value={newClient.contact} onChange={e => setNewClient(p => ({ ...p, contact: e.target.value }))} placeholder="admin@firm.co.za" className={inputCls} />
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setShowAdd(false)} className="px-4 py-2 border border-border text-muted-foreground rounded-lg text-sm">Cancel</button>
                <button onClick={addClient} className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium">Add Client</button>
              </div>
            </div>
          )}

          <div className="overflow-x-auto glass-card rounded-xl border border-primary/10">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 text-primary animate-spin" />
              </div>
            ) : clients.length === 0 ? (
              <div className="py-12 text-center">
                <Building className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">No client profiles registered yet.</p>
              </div>
            ) : (
              <table className="w-full text-sm min-w-[700px]">
                <thead>
                  <tr className="border-b border-border">
                    {['Company', 'Contact', 'Status', 'Compliance Score', 'Registered', 'Actions'].map(h => (
                      <th key={h} className="text-left py-3 px-4 text-xs text-muted-foreground font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {clients.map(c => (
                    <ClientRow key={c.id} client={c} onToggle={toggleStatus} onDelete={deleteClient} />
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {/* ── Billing Tab ── */}
      {tab === 'billing' && (
        <div className="space-y-5">
          <h2 className="font-grotesk font-semibold text-foreground">Billing Overview</h2>
          <div className="overflow-x-auto glass-card rounded-xl border border-primary/10">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 text-primary animate-spin" />
              </div>
            ) : clients.length === 0 ? (
              <div className="py-12 text-center">
                <CreditCard className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">No billing data available — no clients registered.</p>
              </div>
            ) : (
              <table className="w-full text-sm min-w-[500px]">
                <thead>
                  <tr className="border-b border-border">
                    {['Client', 'Status', 'Compliance Score', 'Registered'].map(h => (
                      <th key={h} className="text-left py-3 px-4 text-xs text-muted-foreground font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {clients.map(c => (
                    <tr key={c.id} className="hover:bg-secondary/30">
                      <td className="py-3 px-4 font-medium text-foreground">{c.entity_name || 'Not specified'}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${c.onboarding_complete ? 'bg-green-400/10 text-green-400' : 'bg-yellow-400/10 text-yellow-400'}`}>
                          {c.onboarding_complete ? 'active' : 'pending'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-primary font-medium">{c.compliance_score != null ? `${c.compliance_score}%` : 'Not Available'}</td>
                      <td className="py-3 px-4 text-muted-foreground font-mono text-xs">
                        {c.created_date ? new Date(c.created_date).toLocaleDateString('en-ZA') : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
          <div className="glass-card rounded-xl border border-yellow-400/20 p-4 bg-yellow-400/5">
            <p className="text-xs text-yellow-600">⚠ Billing and subscription plan management requires a payment integration. No billing data is available until payment providers are configured.</p>
          </div>
        </div>
      )}

      {/* ── Legal Docs Tab ── */}
      {tab === 'legal' && (
        <div className="space-y-5">
          <div>
            <h2 className="font-grotesk font-semibold text-foreground">Legal Documents & Agreements</h2>
            <p className="text-xs text-muted-foreground mt-0.5">All SaaS, reseller, and compliance legal documents for SNC-TAX B2B operations.</p>
          </div>
          <LegalDocPanel />
        </div>
      )}

      {/* ── Settings Tab ── */}
      {tab === 'settings' && (
        <div className="space-y-5">
          <h2 className="font-grotesk font-semibold text-foreground">Platform Settings</h2>
          <div className="grid md:grid-cols-2 gap-5">
            <div className="glass-card rounded-xl border border-primary/10 p-5 space-y-3">
              <h3 className="font-semibold text-foreground text-sm flex items-center gap-2"><Bell className="w-4 h-4 text-primary" /> Notifications</h3>
              {[
                'Email alert on new client sign-up',
                'Email alert on payment failure',
                'Email alert on suspension trigger',
                'Weekly revenue summary email',
              ].map((n, i) => (
                <label key={i} className="flex items-center justify-between gap-3 py-2 border-b border-border last:border-0">
                  <span className="text-sm text-foreground">{n}</span>
                  <input type="checkbox" defaultChecked={i < 2} className="w-4 h-4 accent-primary" />
                </label>
              ))}
            </div>
            <div className="glass-card rounded-xl border border-primary/10 p-5 space-y-3">
              <h3 className="font-semibold text-foreground text-sm flex items-center gap-2"><Settings className="w-4 h-4 text-primary" /> Platform Controls</h3>
              {[
                { label: 'Allow new client registrations', defaultOn: true },
                { label: 'Enforce POPIA data isolation', defaultOn: true },
                { label: 'Auto-suspend on payment failure (7 days)', defaultOn: true },
                { label: 'White-label mode enabled', defaultOn: true },
              ].map((s, i) => (
                <label key={i} className="flex items-center justify-between gap-3 py-2 border-b border-border last:border-0">
                  <span className="text-sm text-foreground">{s.label}</span>
                  <input type="checkbox" defaultChecked={s.defaultOn} className="w-4 h-4 accent-primary" />
                </label>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="text-center text-xs text-muted-foreground pt-4 border-t border-border">
        <p>© {new Date().getFullYear()} <strong>SNC-TAX</strong> · SaaS Admin Portal · All access is logged and audited</p>
        <p className="mt-0.5 text-primary italic">Re-imagining Compliance Intelligence</p>
      </div>
    </div>
  );
}