import { useState } from 'react';
import { Calculator, TrendingUp, DollarSign, AlertTriangle } from 'lucide-react';

const taxBrackets2026 = [
  { from: 0, to: 237100, rate: 18, base: 0 },
  { from: 237101, to: 370500, rate: 26, base: 42678 },
  { from: 370501, to: 512800, rate: 31, base: 77362 },
  { from: 512801, to: 673000, rate: 36, base: 121475 },
  { from: 673001, to: 857900, rate: 39, base: 179147 },
  { from: 857901, to: 1817000, rate: 41, base: 251258 },
  { from: 1817001, to: Infinity, rate: 45, base: 644489 },
];

function calcTax(income) {
  const bracket = taxBrackets2026.findLast(b => income >= b.from);
  if (!bracket) return 0;
  return bracket.base + (income - bracket.from) * (bracket.rate / 100);
}

export default function TaxEngine() {
  const [income, setIncome] = useState('');
  const [expenses, setExpenses] = useState('');
  const [paye, setPaye] = useState('');
  const [entityType, setEntityType] = useState('individual');
  const [result, setResult] = useState(null);

  const calculate = () => {
    const inc = parseFloat(income) || 0;
    const exp = parseFloat(expenses) || 0;
    const payeCredits = parseFloat(paye) || 0;
    const taxableIncome = Math.max(0, inc - exp);

    let taxLiability = 0;
    if (entityType === 'individual') {
      taxLiability = Math.max(0, calcTax(taxableIncome) - 17235); // primary rebate 2026
    } else if (entityType === 'company') {
      taxLiability = taxableIncome * 0.27;
    } else if (entityType === 'sbc') {
      // SBC tiered rates
      if (taxableIncome <= 95750) taxLiability = 0;
      else if (taxableIncome <= 365000) taxLiability = (taxableIncome - 95750) * 0.07;
      else if (taxableIncome <= 550000) taxLiability = 18883 + (taxableIncome - 365000) * 0.21;
      else taxLiability = 57733 + (taxableIncome - 550000) * 0.27;
    }

    const netTaxDue = Math.max(0, taxLiability - payeCredits);
    const provisional1 = netTaxDue * 0.5;
    const provisional2 = netTaxDue * 0.5;
    const vat = inc * 0.15;
    const effectiveRate = taxableIncome > 0 ? (taxLiability / taxableIncome * 100).toFixed(1) : 0;

    setResult({ taxableIncome, taxLiability, netTaxDue, provisional1, provisional2, vat, effectiveRate });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">Automated Tax Engine</span>
        <h1 className="text-3xl font-bold font-grotesk text-foreground mb-2">Tax Calculator</h1>
        <p className="text-muted-foreground">Provisional tax, income tax, and VAT estimates for 2025/2026 tax year.</p>
      </div>

      <div className="glass-card rounded-xl p-6 space-y-4">
        <h2 className="font-grotesk font-semibold text-foreground">Tax Inputs</h2>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">Entity Type</label>
            <select value={entityType} onChange={e => setEntityType(e.target.value)}
              className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none">
              <option value="individual">Individual / Sole Proprietor</option>
              <option value="company">Company (27% flat rate)</option>
              <option value="sbc">Small Business Corporation (Section 12E)</option>
            </select>
          </div>
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">Annual Gross Income (R)</label>
            <input type="number" value={income} onChange={e => setIncome(e.target.value)} placeholder="e.g. 800000"
              className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
          </div>
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">Total Allowable Deductions (R)</label>
            <input type="number" value={expenses} onChange={e => setExpenses(e.target.value)} placeholder="e.g. 150000"
              className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
          </div>
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">PAYE Already Paid (R)</label>
            <input type="number" value={paye} onChange={e => setPaye(e.target.value)} placeholder="e.g. 50000"
              className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none" />
          </div>
        </div>

        <button onClick={calculate}
          className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold text-sm neon-glow hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
          <Calculator className="w-4 h-4" /> Calculate Tax Estimate
        </button>
      </div>

      {result && (
        <div className="glass-card rounded-xl p-6 space-y-4 animate-slide-up">
          <h2 className="font-grotesk font-semibold text-foreground flex items-center gap-2"><TrendingUp className="w-5 h-5 text-primary" /> Tax Estimate Results</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {[
              { label: 'Taxable Income', value: `R ${result.taxableIncome.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`, color: 'text-foreground' },
              { label: 'Gross Tax Liability', value: `R ${result.taxLiability.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`, color: 'text-yellow-400' },
              { label: 'Net Tax Due (after PAYE)', value: `R ${result.netTaxDue.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`, color: 'text-red-400' },
              { label: 'Effective Tax Rate', value: `${result.effectiveRate}%`, color: 'text-blue-400' },
              { label: '1st Provisional (August)', value: `R ${result.provisional1.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`, color: 'text-orange-400' },
              { label: '2nd Provisional (February)', value: `R ${result.provisional2.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`, color: 'text-orange-400' },
            ].map((r, i) => (
              <div key={i} className="bg-secondary/40 rounded-lg p-4 border border-border">
                <p className="text-xs text-muted-foreground">{r.label}</p>
                <p className={`text-xl font-bold font-grotesk ${r.color} mt-1`}>{r.value}</p>
              </div>
            ))}
          </div>
          <div className="bg-yellow-400/5 border border-yellow-400/20 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground">These are estimates only based on 2025/2026 SARS rates. Consult a registered tax practitioner for binding advice. Compl-Ai™ SA AI disclaimer applies.</p>
            </div>
          </div>
        </div>
      )}

      {/* Tax Brackets Table */}
      <div className="glass-card rounded-xl p-5">
        <h2 className="font-grotesk font-semibold text-foreground mb-4">2025/2026 Individual Tax Brackets</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-primary/20">
              <th className="text-left py-2 px-3 text-muted-foreground">Taxable Income</th>
              <th className="text-left py-2 px-3 text-muted-foreground">Rate</th>
              <th className="text-left py-2 px-3 text-muted-foreground">Base Tax</th>
            </tr></thead>
            <tbody className="divide-y divide-border">
              {taxBrackets2026.map((b, i) => (
                <tr key={i} className="hover:bg-secondary/30">
                  <td className="py-2 px-3 text-foreground text-xs">R {b.from.toLocaleString()} – {b.to === Infinity ? 'above' : `R ${b.to.toLocaleString()}`}</td>
                  <td className="py-2 px-3 text-primary font-medium">{b.rate}%</td>
                  <td className="py-2 px-3 text-muted-foreground text-xs">R {b.base.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}