import { useState, useEffect } from 'react';
import { MessageCircle, Bell, Send, CheckCircle, Loader2, Phone, Zap, Shield, AlertTriangle, Clock, Bot } from 'lucide-react';
import { api } from '@/api/apiClient';
import { useAuth } from '@/lib/AuthContext';
import { useDemo } from '@/lib/DemoContext';

export default function WhatsAppReminders() {
  const { user } = useAuth();
  const { isDemo, demoProfile } = useDemo();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [phone, setPhone] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [testMessage, setTestMessage] = useState('');

  useEffect(() => {
    if (isDemo) {
      setProfile(demoProfile);
      setPhone(demoProfile.whatsapp_number || '');
      setLoading(false);
      return;
    }
    if (!user?.id) { setLoading(false); return; }
    (async () => {
      try {
        const profiles = await api.entities.BusinessProfile.filter({ user_id: user.id });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          setPhone(profiles[0].whatsapp_number || '');
        }
      } catch (e) { console.error('WhatsApp page load error', e); }
      setLoading(false);
    })();
  }, [user?.id, isDemo]);

  const sendTest = async () => {
    if (!phone) return;
    setSending(true);
    setSent(false);
    try {
      await api.functions.invoke('sendWhatsAppNotification', {
        to: phone,
        messageText: testMessage || `🇿🇦 Compl-Ai™ SA — Test Notification\n\nHello ${profile?.director_name || profile?.entity_name || 'there'},\n\nThis is a test message from Compl-i Assistant™. Your WhatsApp notifications are now active.\n\nYou'll receive automated reminders for upcoming filing deadlines and document status updates.\n\n— Compl-i Assistant™`,
      });
      setSent(true);
    } catch (e) {
      console.error('WhatsApp send failed', e);
    }
    setSending(false);
  };

  let upcomingDeadlines = [];
  try { upcomingDeadlines = JSON.parse(profile?.upcoming_deadlines || '[]'); } catch (_) {}

  if (loading) {
    return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 border border-border" style={{ background: 'linear-gradient(135deg, #0d2a5e 0%, #0096b4 100%)' }}>
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center flex-shrink-0">
            <MessageCircle className="w-7 h-7 text-white" />
          </div>
          <div>
            <span className="inline-block px-3 py-1 bg-white/15 text-white text-xs font-semibold rounded-full mb-2">WhatsApp Compliance Reminders</span>
            <h1 className="text-2xl font-bold font-grotesk text-white">Automated WhatsApp Notifications</h1>
            <p className="text-white/70 text-sm mt-1">Receive real-time compliance alerts, deadline reminders, and document status updates directly to your verified WhatsApp number.</p>
          </div>
        </div>
      </div>

      {/* Automation Status */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Deadline Reminders */}
        <div className="glass-card rounded-2xl p-6 border border-border space-y-4">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Clock className="w-4 h-4 text-green-600" />
            </div>
            <h2 className="font-grotesk font-semibold text-foreground">Filing Deadline Reminders</h2>
          </div>
          <p className="text-sm text-muted-foreground">Automated daily check at 08:00. Sends WhatsApp alerts for any compliance deadlines due within 7 days.</p>
          <div className="flex items-center gap-2 p-2.5 rounded-lg bg-green-50 border border-green-200">
            <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
            <span className="text-xs font-medium text-green-700">Active — runs every day automatically</span>
          </div>
          {upcomingDeadlines.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-xs text-muted-foreground font-medium">Your tracked deadlines:</p>
              {upcomingDeadlines.slice(0, 4).map((d, i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-secondary/40 border border-border">
                  <span className="text-xs text-foreground truncate">{d.label}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0 ml-2 ${d.urgent ? 'bg-red-400/20 text-red-500' : 'bg-primary/20 text-primary'}`}>{d.date}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Document Status Updates */}
        <div className="glass-card rounded-2xl p-6 border border-border space-y-4">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary" />
            </div>
            <h2 className="font-grotesk font-semibold text-foreground">Document Status Updates</h2>
          </div>
          <p className="text-sm text-muted-foreground">When Compl-i Assistant™ finishes analysing your uploaded documents, you'll receive a WhatsApp notification with the result.</p>
          <div className="flex items-center gap-2 p-2.5 rounded-lg bg-green-50 border border-green-200">
            <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
            <span className="text-xs font-medium text-green-700">Active — triggers on document analysis completion</span>
          </div>
          <div className="space-y-2 pt-1">
            {[
              { icon: CheckCircle, text: 'Notification when a document is successfully analysed', color: 'text-green-600' },
              { icon: AlertTriangle, text: 'Alert if document analysis encounters an error', color: 'text-red-500' },
              { icon: Zap, text: 'Instant delivery — no waiting for email', color: 'text-yellow-600' },
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-3">
                <f.icon className={`w-4 h-4 flex-shrink-0 ${f.color}`} />
                <span className="text-sm text-foreground">{f.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Phone Number + Test Send */}
      <div className="glass-card rounded-2xl p-6 border border-border space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-8 h-8 rounded-lg bg-yellow-500/10 flex items-center justify-center">
            <Phone className="w-4 h-4 text-yellow-600" />
          </div>
          <h2 className="font-grotesk font-semibold text-foreground">Your WhatsApp Number & Test</h2>
        </div>

        {phone ? (
          <div className="flex items-center gap-2 p-2.5 rounded-lg bg-green-50 border border-green-200">
            <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
            <span className="text-xs font-medium text-green-700">WhatsApp number on file: <strong>{phone}</strong></span>
          </div>
        ) : (
          <div className="flex items-center gap-2 p-2.5 rounded-lg bg-yellow-50 border border-yellow-200">
            <AlertTriangle className="w-4 h-4 text-yellow-600 flex-shrink-0" />
            <span className="text-xs font-medium text-yellow-700">No WhatsApp number on file. Add one during onboarding to receive notifications.</span>
          </div>
        )}

        <div>
          <label className="text-xs text-muted-foreground mb-1.5 block">WhatsApp Number</label>
          <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="e.g. +27 82 123 4567"
            className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-border focus:border-primary/50 outline-none" />
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1.5 block">Custom Test Message (optional)</label>
          <textarea value={testMessage} onChange={e => setTestMessage(e.target.value)} rows={3} placeholder="Leave blank to send a default test notification"
            className="w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-border focus:border-primary/50 outline-none resize-none" />
        </div>

        {sent ? (
          <div className="flex items-center justify-center gap-2 py-3 bg-green-50 border border-green-200 rounded-xl text-sm text-green-700 font-medium">
            <CheckCircle className="w-4 h-4" /> WhatsApp notification sent successfully!
          </div>
        ) : (
          <button onClick={sendTest} disabled={sending || !phone}
            className="w-full py-3 text-white rounded-xl text-sm font-semibold transition-all hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
            style={{ background: 'linear-gradient(135deg, #25d366, #128c7e)' }}>
            {sending ? <><Loader2 className="w-4 h-4 animate-spin" /> Sending...</> : <><Send className="w-4 h-4" /> Send Test WhatsApp</>}
          </button>
        )}
      </div>

      {/* Reminder Schedule */}
      <div className="glass-card rounded-2xl p-6 border border-border">
        <h3 className="font-grotesk font-semibold text-foreground mb-4 flex items-center gap-2">
          <Bell className="w-4 h-4 text-primary" /> Automated Reminder Schedule
        </h3>
        <div className="space-y-2">
          {[
            { days: 7, label: '7 days before due date', desc: 'Urgent reminder — escalated priority' },
            { days: 1, label: '1 day before due date', desc: 'Final warning with one-tap resolve' },
            { days: 0, label: 'On due date', desc: 'Same-day critical alert' },
          ].map((r, i) => (
            <div key={i} className="flex items-center gap-4 p-3 rounded-xl bg-secondary/40 border border-border">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 font-bold text-sm ${r.days <= 1 ? 'bg-red-50 text-red-600' : 'bg-primary/10 text-primary'}`}>
                {r.days === 0 ? '!' : `${r.days}d`}
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{r.label}</p>
                <p className="text-xs text-muted-foreground">{r.desc}</p>
              </div>
              <CheckCircle className="w-4 h-4 text-green-500 ml-auto flex-shrink-0" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}