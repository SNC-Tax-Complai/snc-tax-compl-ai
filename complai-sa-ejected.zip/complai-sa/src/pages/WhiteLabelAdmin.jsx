import { useState } from 'react';
import { Palette, Upload, Save, Eye, Plus, Trash2, CheckCircle, Building, Globe, Tag, Image, Type, Layout } from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '@/api/apiClient';

const DEFAULT_THEME = {
  appName: 'Compl-Ai™ SA',
  tagline: 'Your SA Compliance Command Centre',
  primaryColor: '#0096b4',
  secondaryColor: '#0d2a5e',
  accentColor: '#13b5ea',
  backgroundColor: '#f0f4f8',
  fontFamily: 'Inter',
  logoUrl: '',
  faviconUrl: '',
  heroImageUrl: '',
  contactEmail: '',
  contactPhone: '',
  footerText: 'Powered by Compl-Ai™ SA — SA-iLabs®™',
};

const FONT_OPTIONS = ['Inter', 'Space Grotesk', 'Roboto', 'Open Sans', 'Poppins', 'Montserrat', 'Lato', 'Nunito'];

const PLANS = [
  { name: 'Starter', maxClients: 25, price: 'R1,499/mo', features: ['White-label branding', 'Up to 25 clients', 'Basic compliance modules', 'Email support'] },
  { name: 'Pro', maxClients: 100, price: 'R3,999/mo', features: ['Full white-label', 'Up to 100 clients', 'All compliance modules', 'Compl-i Assistant AI', 'Priority support', 'Custom domain'] },
  { name: 'Enterprise', maxClients: 999, price: 'Custom', features: ['Unlimited clients', 'Full API access', 'Dedicated onboarding', 'SLA guarantee', 'Custom integrations', 'Co-branded reports'] },
];

function Section({ title, icon: Icon, children }) {
  return (
    <div className="glass-card rounded-xl border border-primary/10 overflow-hidden">
      <div className="flex items-center gap-2 p-4 border-b border-border bg-secondary/30">
        <Icon className="w-4 h-4 text-primary" />
        <h3 className="font-grotesk font-semibold text-foreground text-sm">{title}</h3>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="text-xs text-muted-foreground mb-1.5 block">{label}</label>
      {children}
    </div>
  );
}

const inputCls = "w-full bg-secondary rounded-lg px-3 py-2.5 text-sm text-foreground border border-primary/20 focus:border-primary/50 outline-none";

export default function WhiteLabelAdmin() {
  const [theme, setTheme] = useState(DEFAULT_THEME);
  const [activeTab, setActiveTab] = useState('vendors');
  const [vendors, setVendors] = useState([]);
  const [saved, setSaved] = useState(false);
  const [showNewVendor, setShowNewVendor] = useState(false);
  const [newVendor, setNewVendor] = useState({ company: '', contact: '', plan: 'Starter' });

  const set = (k, v) => setTheme(p => ({ ...p, [k]: v }));

  const handleSave = () => {
    // In production: persist to entity / backend
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const addVendor = () => {
    if (!newVendor.company) return;
    setVendors(p => [...p, { id: Date.now(), ...newVendor, clients: 0, status: 'pending', since: new Date().toISOString().split('T')[0] }]);
    setNewVendor({ company: '', contact: '', plan: 'Starter' });
    setShowNewVendor(false);
  };

  const removeVendor = (id) => setVendors(p => p.filter(v => v.id !== id));

  const tabs = [
    { key: 'vendors', label: 'Vendor Partners', icon: Building },
    { key: 'theme', label: 'Brand Theme Editor', icon: Palette },
    { key: 'plans', label: 'Subscription Plans', icon: Tag },
    { key: 'preview', label: 'Live Preview', icon: Eye },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 neon-glow border border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
        <div className="relative">
          <span className="inline-block px-3 py-1 bg-primary/20 text-primary text-xs font-semibold rounded-full mb-3 border border-primary/30">
            ⚙️ Admin — White-Label Management
          </span>
          <h1 className="text-2xl font-bold font-grotesk text-foreground mb-1">White-Label Vendor Portal</h1>
          <p className="text-muted-foreground text-sm">SNC-TAX — Manage partner accounting firms, brand themes, and subscription tiers.</p>
          <p className="text-xs text-muted-foreground mt-2 opacity-70">© SNC-TAX — All Rights Reserved · Developed by SA-iLabs®™</p>
          <Link to="/sudo-admin" className="inline-flex items-center gap-1.5 mt-3 px-4 py-2 bg-primary/10 border border-primary/30 text-primary rounded-lg text-xs font-semibold hover:bg-primary/20 transition-colors">
            🔐 Access Sudo Admin Portal →
          </Link>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 glass-card rounded-xl p-1 border border-primary/10 flex-wrap">
        {tabs.map(t => (
          <button key={t.key} onClick={() => setActiveTab(t.key)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all ${activeTab === t.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
            <t.icon className="w-3.5 h-3.5" />{t.label}
          </button>
        ))}
      </div>

      {/* Vendors Tab */}
      {activeTab === 'vendors' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-grotesk font-semibold text-foreground">Partner Accounting Firms</h2>
              <p className="text-xs text-muted-foreground mt-0.5">{vendors.length} vendor partners</p>
            </div>
            <button onClick={() => setShowNewVendor(true)}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium neon-glow hover:bg-primary/90 transition-colors">
              <Plus className="w-4 h-4" /> Add Vendor
            </button>
          </div>

          {showNewVendor && (
            <div className="glass-card rounded-xl p-5 border border-primary/20 space-y-3">
              <h3 className="font-semibold text-foreground text-sm">New Vendor Partner</h3>
              <div className="grid sm:grid-cols-3 gap-3">
                <Field label="Company Name">
                  <input value={newVendor.company} onChange={e => setNewVendor(p => ({ ...p, company: e.target.value }))} className={inputCls} placeholder="Nexus Accounting" />
                </Field>
                <Field label="Contact Email">
                  <input value={newVendor.contact} onChange={e => setNewVendor(p => ({ ...p, contact: e.target.value }))} className={inputCls} placeholder="info@firm.co.za" />
                </Field>
                <Field label="Plan">
                  <select value={newVendor.plan} onChange={e => setNewVendor(p => ({ ...p, plan: e.target.value }))} className={inputCls}>
                    {PLANS.map(p => <option key={p.name} value={p.name}>{p.name}</option>)}
                  </select>
                </Field>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setShowNewVendor(false)} className="px-4 py-2 border border-border text-muted-foreground rounded-lg text-sm">Cancel</button>
                <button onClick={addVendor} className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium">Add Partner</button>
              </div>
            </div>
          )}

          <div className="overflow-x-auto glass-card rounded-xl border border-primary/10">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {['Company', 'Contact', 'Plan', 'Clients', 'Since', 'Status', ''].map(h => (
                    <th key={h} className="text-left py-3 px-4 text-xs text-muted-foreground font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {vendors.length === 0 ? (
                  <tr><td colSpan={7} className="py-8 text-center text-muted-foreground text-sm">No vendor partners registered yet. Click "Add Vendor" to create one.</td></tr>
                ) : vendors.map(v => (
                  <tr key={v.id} className="hover:bg-secondary/30 transition-colors">
                    <td className="py-3 px-4 font-medium text-foreground">{v.company}</td>
                    <td className="py-3 px-4 text-muted-foreground">{v.contact}</td>
                    <td className="py-3 px-4">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${v.plan === 'Enterprise' ? 'bg-purple-400/10 text-purple-400' : v.plan === 'Pro' ? 'bg-primary/10 text-primary' : 'bg-secondary text-muted-foreground'}`}>{v.plan}</span>
                    </td>
                    <td className="py-3 px-4 text-foreground">{v.clients}</td>
                    <td className="py-3 px-4 text-muted-foreground font-mono text-xs">{v.since}</td>
                    <td className="py-3 px-4">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${v.status === 'active' ? 'bg-green-400/10 text-green-400' : 'bg-yellow-400/10 text-yellow-400'}`}>{v.status}</span>
                    </td>
                    <td className="py-3 px-4">
                      <button onClick={() => removeVendor(v.id)} className="p-1.5 text-muted-foreground hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Theme Editor Tab */}
      {activeTab === 'theme' && (
        <div className="space-y-5">
          <div className="grid md:grid-cols-2 gap-5">
            <Section title="App Identity" icon={Type}>
              <div className="space-y-3">
                <Field label="App Name">
                  <input value={theme.appName} onChange={e => set('appName', e.target.value)} className={inputCls} />
                </Field>
                <Field label="Tagline">
                  <input value={theme.tagline} onChange={e => set('tagline', e.target.value)} className={inputCls} />
                </Field>
                <Field label="Contact Email">
                  <input value={theme.contactEmail} onChange={e => set('contactEmail', e.target.value)} className={inputCls} placeholder="hello@yourfirm.co.za" />
                </Field>
                <Field label="Contact Phone">
                  <input value={theme.contactPhone} onChange={e => set('contactPhone', e.target.value)} className={inputCls} placeholder="+27 11 000 0000" />
                </Field>
                <Field label="Footer Text">
                  <input value={theme.footerText} onChange={e => set('footerText', e.target.value)} className={inputCls} />
                </Field>
              </div>
            </Section>

            <Section title="Brand Colours" icon={Palette}>
              <div className="space-y-3">
                {[
                  { key: 'primaryColor', label: 'Primary Colour' },
                  { key: 'secondaryColor', label: 'Secondary / Navy' },
                  { key: 'accentColor', label: 'Accent / Glow' },
                  { key: 'backgroundColor', label: 'Background Colour' },
                ].map(c => (
                  <div key={c.key} className="flex items-center gap-3">
                    <input type="color" value={theme[c.key]} onChange={e => set(c.key, e.target.value)}
                      className="w-10 h-10 rounded-lg border border-border cursor-pointer bg-transparent" />
                    <div className="flex-1">
                      <p className="text-xs font-medium text-foreground">{c.label}</p>
                      <p className="text-xs text-muted-foreground font-mono">{theme[c.key]}</p>
                    </div>
                    <div className="w-8 h-8 rounded-full border border-border" style={{ background: theme[c.key] }} />
                  </div>
                ))}
              </div>
            </Section>

            <Section title="Typography & Font" icon={Type}>
              <Field label="Font Family">
                <select value={theme.fontFamily} onChange={e => set('fontFamily', e.target.value)} className={inputCls}>
                  {FONT_OPTIONS.map(f => <option key={f} value={f}>{f}</option>)}
                </select>
              </Field>
              <div className="mt-4 p-3 bg-secondary/40 rounded-lg border border-border">
                <p className="text-xs text-muted-foreground mb-1">Preview</p>
                <p className="text-lg font-bold text-foreground" style={{ fontFamily: theme.fontFamily }}>{theme.appName}</p>
                <p className="text-sm text-muted-foreground" style={{ fontFamily: theme.fontFamily }}>{theme.tagline}</p>
              </div>
            </Section>

            <Section title="Logos & Images" icon={Image}>
              <div className="space-y-3">
                <Field label="Logo URL">
                  <input value={theme.logoUrl} onChange={e => set('logoUrl', e.target.value)} className={inputCls} placeholder="https://..." />
                </Field>
                <Field label="Favicon URL">
                  <input value={theme.faviconUrl} onChange={e => set('faviconUrl', e.target.value)} className={inputCls} placeholder="https://..." />
                </Field>
                <Field label="Hero / Banner Image URL">
                  <input value={theme.heroImageUrl} onChange={e => set('heroImageUrl', e.target.value)} className={inputCls} placeholder="https://..." />
                </Field>
                {theme.logoUrl && <img src={theme.logoUrl} alt="Logo preview" className="h-12 object-contain rounded border border-border" />}
              </div>
            </Section>
          </div>

          <div className="flex justify-end">
            <button onClick={handleSave}
              className="flex items-center gap-2 px-6 py-2.5 bg-primary text-primary-foreground rounded-xl font-medium text-sm neon-glow hover:bg-primary/90 transition-colors">
              {saved ? <><CheckCircle className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" /> Save Theme</>}
            </button>
          </div>
        </div>
      )}

      {/* Plans Tab */}
      {activeTab === 'plans' && (
        <div className="grid md:grid-cols-3 gap-5">
          {PLANS.map((plan, i) => (
            <div key={plan.name} className={`glass-card rounded-xl p-6 border ${i === 1 ? 'border-primary/40 neon-glow' : 'border-primary/10'} relative`}>
              {i === 1 && <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-primary text-primary-foreground text-xs rounded-full font-medium">Most Popular</span>}
              <h3 className="font-grotesk font-bold text-foreground text-lg">{plan.name}</h3>
              <p className="text-2xl font-bold text-primary mt-1">{plan.price}</p>
              <p className="text-xs text-muted-foreground mt-0.5">Up to {plan.maxClients === 999 ? 'Unlimited' : plan.maxClients} end clients</p>
              <ul className="mt-5 space-y-2">
                {plan.features.map((f, fi) => (
                  <li key={fi} className="flex items-center gap-2 text-xs text-foreground">
                    <CheckCircle className="w-3.5 h-3.5 text-green-400 flex-shrink-0" /> {f}
                  </li>
                ))}
              </ul>
              <button className="mt-6 w-full py-2.5 border border-primary/30 text-primary rounded-lg text-sm font-medium hover:bg-primary/10 transition-colors">
                Configure Plan
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Preview Tab */}
      {activeTab === 'preview' && (
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground">Live preview of how a vendor-branded instance will appear to their clients.</p>
          <div className="rounded-2xl overflow-hidden border border-primary/20 shadow-lg">
            {/* Fake header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-border" style={{ background: theme.secondaryColor }}>
              <div className="flex items-center gap-2">
                {theme.logoUrl
                  ? <img src={theme.logoUrl} alt="logo" className="h-7 object-contain" />
                  : <div className="h-7 px-3 py-1 rounded text-white text-sm font-bold" style={{ background: theme.primaryColor }}>{theme.appName}</div>
                }
              </div>
              <div className="flex gap-4 text-xs text-white/70">
                <span>Dashboard</span><span>Compliance</span><span>Vault</span><span>Chat</span>
              </div>
            </div>
            {/* Fake hero */}
            <div className="p-8" style={{ background: theme.backgroundColor }}>
              <span className="inline-block px-3 py-1 text-white text-xs font-semibold rounded-full mb-3" style={{ background: theme.primaryColor }}>
                🇿🇦 Proudly South African
              </span>
              <h1 className="text-2xl font-bold mb-1" style={{ fontFamily: theme.fontFamily, color: theme.secondaryColor }}>
                Welcome to <span style={{ color: theme.primaryColor }}>{theme.appName}</span>
              </h1>
              <p className="text-sm text-gray-500 mb-4" style={{ fontFamily: theme.fontFamily }}>{theme.tagline}</p>
              <div className="flex gap-3">
                <div className="px-5 py-2 rounded-lg text-white text-sm font-medium" style={{ background: theme.primaryColor }}>Get Started</div>
                <div className="px-5 py-2 rounded-lg text-sm font-medium border" style={{ borderColor: theme.primaryColor, color: theme.primaryColor }}>View Calendar</div>
              </div>
            </div>
            {/* Fake footer */}
            <div className="px-6 py-3 border-t border-gray-200 text-center" style={{ background: '#f8f9fa' }}>
              <p className="text-xs text-gray-400">{theme.footerText}</p>
              <p className="text-xs text-gray-300 mt-0.5">© SNC-Tax | SNC-NPC — Powered by Compl-Ai™ SA · SA-iLabs®™</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}