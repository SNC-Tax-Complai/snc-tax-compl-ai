import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

// Self-hosted Vite config. No platform plugins: nothing here reports telemetry
// or contacts an external build service.
export default defineConfig({
  plugins: [react()],
  resolve: {
    // The plugin used to provide this alias; we now declare it explicitly.
    alias: { '@': path.resolve(__dirname, './src') },
  },
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: process.env.VITE_DEV_API_TARGET || 'http://localhost:5000',
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
    chunkSizeWarningLimit: 1200,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
          charts: ['recharts'],
          motion: ['framer-motion'],
        },
      },
    },
  },
});
