import axios from 'axios';
import BaseProvider from './baseProvider.js';

/**
 * OpenAI GPT-4 Provider
 */
export default class OpenAIProvider extends BaseProvider {
  constructor() {
    super('OpenAI GPT-4', 'OPENAI_API_KEY');
    this.baseUrl = 'https://api.openai.com/v1';
    this.model = process.env.OPENAI_MODEL || 'gpt-4';
  }

  async analyzeDocument(file, context) {
    if (!this.isConfigured) {
      return { provider: 'openai', status: 'unconfigured', message: 'Set OPENAI_API_KEY to enable' };
    }

    const prompt = `Analyze this document for South African compliance relevance.
Company type: ${context.companyType || 'Pty Ltd'}
Sector: ${context.sector || 'General'}
Filename: ${file.originalname || file.filename}
File type: ${file.mimetype}

Identify:
1. Which compliance module(s) this relates to (CIPC, SARS, Labour, OHS, POPIA, B-BBEE, FICA, Municipal, Industry)
2. Any deadlines or dates found
3. Risk level (low/medium/high/critical)
4. Recommended actions

Respond in JSON format.`;

    try {
      const response = await axios.post(`${this.baseUrl}/chat/completions`, {
        model: this.model,
        messages: [
          { role: 'system', content: this.getSystemPrompt() },
          { role: 'user', content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 1000,
      }, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: 60000,
      });

      const content = response.data.choices[0].message.content;
      return { provider: 'openai', status: 'success', analysis: JSON.parse(content) };
    } catch (error) {
      return { provider: 'openai', status: 'error', message: error.message };
    }
  }

  async generateRecommendations(companyData) {
    if (!this.isConfigured) {
      return [];
    }

    const prompt = `Generate compliance recommendations for this South African company:
Name: ${companyData.name}
Type: ${companyData.companyType}
Sector: ${companyData.sector}
Employees: ${companyData.employeeCount}
Turnover: R${companyData.annualTurnover}

Current compliance score: ${companyData.complianceScore}%
Overdue items: ${companyData.overdueCount}
Pending items: ${companyData.pendingCount}

Provide 3-5 prioritized recommendations in JSON array format with fields:
priority (high/medium/low), module, title, description, action, penalty, deadline`;

    try {
      const response = await axios.post(`${this.baseUrl}/chat/completions`, {
        model: this.model,
        messages: [
          { role: 'system', content: this.getSystemPrompt() },
          { role: 'user', content: prompt },
        ],
        temperature: 0.4,
        max_tokens: 1500,
      }, {
        headers: { 'Authorization': `Bearer ${this.apiKey}` },
        timeout: 60000,
      });

      return JSON.parse(response.data.choices[0].message.content);
    } catch (error) {
      return [];
    }
  }

  async chat(messages) {
    if (!this.isConfigured) {
      return { provider: 'openai', status: 'unconfigured', message: 'Set OPENAI_API_KEY in backend .env to enable AI chat' };
    }

    try {
      const response = await axios.post(`${this.baseUrl}/chat/completions`, {
        model: this.model,
        messages: [
          { role: 'system', content: this.getSystemPrompt() },
          ...messages.map(m => ({ role: m.role, content: m.content })),
        ],
        temperature: 0.5,
        max_tokens: 1500,
      }, {
        headers: { 'Authorization': `Bearer ${this.apiKey}` },
        timeout: 60000,
      });

      return {
        provider: 'openai',
        status: 'success',
        message: response.data.choices[0].message.content,
      };
    } catch (error) {
      return { provider: 'openai', status: 'error', message: error.response?.data?.error?.message || error.message };
    }
  }

  async classifyRequirement(text) {
    if (!this.isConfigured) {
      return { provider: 'openai', status: 'unconfigured' };
    }

    try {
      const response = await axios.post(`${this.baseUrl}/chat/completions`, {
        model: this.model,
        messages: [
          { role: 'system', content: 'Classify the following text into one SA compliance module. Respond with JSON: {module, confidence, reasoning}' },
          { role: 'user', content: text },
        ],
        temperature: 0.2,
        max_tokens: 200,
      }, {
        headers: { 'Authorization': `Bearer ${this.apiKey}` },
        timeout: 30000,
      });

      return { provider: 'openai', ...JSON.parse(response.data.choices[0].message.content) };
    } catch (error) {
      return { provider: 'openai', status: 'error', message: error.message };
    }
  }
}
